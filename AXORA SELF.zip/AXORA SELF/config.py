import os
from dataclasses import dataclass
from telethon import TelegramClient

@dataclass(frozen=True)
class Settings:
    API_ID: int = int(os.getenv("TG_API_ID", ""))
    API_HASH: str = os.getenv("TG_API_HASH", "")
    PHONE: str = os.getenv("TG_PHONE", "")
    SESSION: str = os.getenv("TG_SESSION", "MEGA_ANTI_FUCKING")

    DEVICE_MODEL: str = os.getenv("TG_DEVICE_MODEL", "Samsung Galaxy S26 Ultra")
    SYSTEM_VERSION: str = os.getenv("TG_SYSTEM_VERSION", "Android 26")
    APP_VERSION: str = os.getenv("TG_APP_VERSION", "13.13.13")
    SYSTEM_LANG: str = os.getenv("TG_SYSTEM_LANG", "fa")
    LANG: str = os.getenv("TG_LANG", "fa")

    REPORT_CHAT_ID_VIEWONCE: int = int(os.getenv("REPORT_VIEWONCE", ""))
    REPORT_CHAT_ID_PROFILE: int = int(os.getenv("REPORT_PROFILE", ""))
    REPORT_CHAT_ID_ANTI: int = int(os.getenv("REPORT_ANTI", ""))

    PHOTO_DIR: str = os.getenv("PHOTO_DIR", "downloaded_photos")

settings = Settings()

client = TelegramClient(
    session=settings.SESSION,
    api_id=settings.API_ID,
    api_hash=settings.API_HASH,
    device_model=settings.DEVICE_MODEL,
    system_version=settings.SYSTEM_VERSION,
    app_version=settings.APP_VERSION,
    system_lang_code=settings.SYSTEM_LANG,
    lang_code=settings.LANG,
)