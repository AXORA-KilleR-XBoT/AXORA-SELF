"""core/group_stats_state.py
-----------------------------------------------------------------------------
آمارِ پیام‌های گروه (عکس/ویدیو/ویس/ویدیو مسیج/پیام، به‌ازای هر کاربر) قبلاً
زیرِ کلیدِ "group_msg_stats" داخلِ همون panel_state.json ذخیره می‌شد که بینِ
~۱۹ ماژولِ دیگه هم مشترکه.

مشکل: این دقیقاً همون بخشیه که با هر پیامِ جدید توی گروه‌های زیرِ نظر بزرگ‌تر
می‌شه (فعلاً حدود ۹۲٪ از کلِ حجمِ panel_state.json فقط همینه) و هر ۵ ثانیه
(اگه چیزی عوض شده باشه) کاملِ همون فایلِ مشترک دوباره خونده و کاملِ دوباره
نوشته می‌شد. چون panel_state از یک asyncio.Lock مشترک بینِ همه‌ی اون ۱۹
ماژولِ دیگه استفاده می‌کنه، این یعنی هرچی این آمار بزرگ‌تر می‌شد (بیشتر
پیام/بیشتر گروه)، هر ۵ ثانیه بیشتر طول می‌کشید و بقیه‌ی ماژول‌ها هم بیشتر
پشتِ همون یک نوشتنِ سنگین معطل می‌موندن - even برای کارهایی که هیچ ربطی به
آمار نداشتن (تنظیماتِ اد اجباری، خوش‌آمد/ترک، اسپم، پنل، ...).

این فایل دقیقاً همون الگوی core/panel_state.py رو تکرار می‌کنه (یک قفلِ
asyncio.Lock + I/O روی ترد جدا) ولی روی یک فایلِ فیزیکیِ کاملاً جدا
(group_stats.json) با قفلِ مخصوصِ خودش. از این‌به‌بعد، رشدِ آمار فقط رویِ
خودش رو کند می‌کنه، نه رویِ ۱۹ ماژولِ دیگه‌ای که کارشون اصلاً به آمار
ربطی نداره.
"""

import asyncio
import json
from pathlib import Path

_STATS_FILE = Path(__file__).resolve().parent.parent / "group_stats.json"
_lock = asyncio.Lock()


def _read_sync() -> dict:
    try:
        if _STATS_FILE.exists():
            return json.loads(_STATS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _write_sync(data: dict) -> None:
    _STATS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _STATS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


async def load() -> dict:
    """فقط خواندنِ کل فایلِ آمار (async، پشتِ قفلِ مخصوصِ خودش)."""
    async with _lock:
        return await asyncio.to_thread(_read_sync)


async def save(data: dict) -> None:
    """نوشتنِ کل فایلِ آمار (async، پشتِ قفلِ مخصوصِ خودش)."""
    async with _lock:
        await asyncio.to_thread(_write_sync, data)


def load_sync() -> dict:
    """نسخه‌ی سنکرون - فقط برای لودِ یک‌بارِ اولیه، قبل از استارتِ حلقه‌ها
    (جایی که هنوز event loop شلوغ نشده)."""
    return _read_sync()


def save_sync(data: dict) -> None:
    """نسخه‌ی سنکرون - فقط برای نوشتنِ یک‌بارِ مهاجرت، قبل از استارتِ حلقه‌ها."""
    _write_sync(data)
