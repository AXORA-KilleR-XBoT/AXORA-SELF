import asyncio
import json
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"
_lock = asyncio.Lock()

def _read_sync(path: Path = _STATE_FILE) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def _write_sync(data: dict, path: Path = _STATE_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

async def load() -> dict:
    async with _lock:
        return await asyncio.to_thread(_read_sync)

async def save(data: dict) -> None:
    async with _lock:
        await asyncio.to_thread(_write_sync, data)

def _write_sync_atomic(data: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

async def load_for(folder) -> dict:
    path = Path(folder) / "panel_state.json"
    return await asyncio.to_thread(_read_sync, path)

async def save_for(folder, data: dict) -> None:
    path = Path(folder) / "panel_state.json"
    await asyncio.to_thread(_write_sync_atomic, data, path)

@asynccontextmanager
async def transaction_for(folder) -> AsyncIterator[dict]:
    path = Path(folder) / "panel_state.json"
    data = await asyncio.to_thread(_read_sync, path)
    yield data
    await asyncio.to_thread(_write_sync_atomic, data, path)