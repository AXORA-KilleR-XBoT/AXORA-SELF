from dataclasses import dataclass, field
from typing import Dict, Set, Any

@dataclass
class RuntimeState:
    # downloader saved media
    saved_voice_path: str | None = None
    saved_video_note_path: str | None = None

    # love mode
    user_modes: Dict[int, str] = field(default_factory=dict)  # user_id -> "idle"|"love"|"enemy"

    # sleep mode
    sleep_mode: bool = False
    sleep_replied_users: Set[int] = field(default_factory=set)

    # profile checker
    last_profile_photo_id: Dict[int, int] = field(default_factory=dict)

    # anti-delete/edit (private)
    saved_messages: Dict[int, Dict[str, Any]] = field(default_factory=dict)

    # media block
    blocked_types_private: Dict[int, Dict[str, bool]] = field(default_factory=dict)  # chat_id -> flags
    restricted_users_group: Dict[int, Dict[int, Dict[str, bool]]] = field(default_factory=dict)  # chat_id -> user_id -> flags

    # delete+undo
    last_deleted: Dict[int, Dict[str, Any]] = field(default_factory=dict)  # chat_id -> {msgs, time}

    # forbidden words
    forbidden_chats: Dict[int, Set[str]] = field(default_factory=dict)

    # silence
    timed_silence: Dict[int, tuple] = field(default_factory=dict)  # chat_id -> (start_time,end_time)
    manual_silence: Dict[int, Set[int]] = field(default_factory=dict)  # chat_id -> set(user_id)

state = RuntimeState()