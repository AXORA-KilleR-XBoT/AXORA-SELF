import re
from datetime import datetime

LINK_PATTERNS = [
    re.compile(r"https?://t\.me/(?:c/)?(\w+)/(\d+)"),
    re.compile(r"https?://t\.me/(\w+)/(\d+)"),
    re.compile(r"t\.me/(?:c/)?(\w+)/(\d+)"),
]

TIME_RANGE_RE = re.compile(r"از\s*(\d{1,2}:\d{2})\s*تا\s*(\d{1,2}:\d{2})")

def extract_link(text: str):
    for pattern in LINK_PATTERNS:
        m = pattern.search(text or "")
        if m:
            return m.group(0), m.group(1), int(m.group(2))
    return None, None, None

def default_flags():
    return {"gif": False, "sticker": False, "emoji": False, "voice": False, "video": False, "photo": False}

def is_only_emoji(text: str) -> bool:
    if not text:
        return False
    clean = re.sub(r"[\s\n\r\W]", "", text)
    # خیلی ساده: حداکثر ۱۲ کاراکتر ایموجی
    return len(clean) <= 12 and all(0x1F000 <= ord(c) <= 0x1FAFF for c in clean)

def parse_time_range(text: str):
    m = TIME_RANGE_RE.search(text or "")
    if not m:
        return None
    try:
        start = datetime.strptime(m.group(1), "%H:%M").time()
        end = datetime.strptime(m.group(2), "%H:%M").time()
        return start, end
    except:
        return None