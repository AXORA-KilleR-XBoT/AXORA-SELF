import os
import re
import shutil
import logging
import asyncio
import tempfile
import subprocess

import yt_dlp
from telethon import events, errors
from telethon.tl.types import DocumentAttributeAudio

# ============================================================================
# تنظیمات
# ============================================================================

MAX_FILE_SIZE_MB         = int(os.getenv("MAX_FILE_SIZE_MB", "500"))
MAX_DOWNLOAD_MB          = int(os.getenv("MAX_DOWNLOAD_MB", "2000"))
MAX_CONCURRENT_DOWNLOADS = int(os.getenv("MAX_CONCURRENT_DOWNLOADS", "3"))
CONCURRENT_FRAGMENTS     = int(os.getenv("CONCURRENT_FRAGMENTS", "8"))

_allowed_raw = os.getenv("ALLOWED_CHAT_IDS", "").strip()
ALLOWED_CHAT_IDS = {int(x.strip()) for x in _allowed_raw.split(",") if x.strip()} or None

IG_COOKIES_FILE      = os.getenv("IG_COOKIES_FILE") or None
TIKTOK_COOKIES_FILE  = os.getenv("TIKTOK_COOKIES_FILE") or None
TWITTER_COOKIES_FILE = os.getenv("TWITTER_COOKIES_FILE") or None

TRIGGER_WORDS = {"copy", "کپی", "/copy", "download", "دانلود"}

ARIA2C_PATH = shutil.which("aria2c")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("telethon").setLevel(logging.WARNING)
logger = logging.getLogger("media_userbot")

_client  = None        # توسط setup() پر می‌شه

# ============================================================================
# تشخیص لینک و کلمه‌ی تریگر
# ============================================================================

URL_PATTERNS = {
    "instagram": re.compile(r"https?://(?:www\.)?instagram\.com/\S+", re.IGNORECASE),
    "youtube":   re.compile(r"https?://(?:www\.)?(?:youtube\.com/\S+|youtu\.be/\S+)", re.IGNORECASE),
    "tiktok":    re.compile(r"https?://(?:[\w.]*\.)?tiktok\.com/\S+", re.IGNORECASE),
    "twitter":   re.compile(r"https?://(?:www\.)?(?:twitter\.com|x\.com)/\S+", re.IGNORECASE),
}
GENERIC_URL_PATTERN = re.compile(r"https?://\S+", re.IGNORECASE)
_TRAILING_CHARS = ").,!?\"'»«<>\u201c\u201d"


def extract_link(text: str):
    if not text:
        return None, None
    for platform, pattern in URL_PATTERNS.items():
        match = pattern.search(text)
        if match:
            return match.group(0).rstrip(_TRAILING_CHARS), platform
    match = GENERIC_URL_PATTERN.search(text)
    if match:
        return match.group(0).rstrip(_TRAILING_CHARS), "generic"
    return None, None


def is_trigger(text: str) -> bool:
    if not text:
        return False
    return text.strip().lower() in TRIGGER_WORDS


def get_file_size_mb(path: str) -> float:
    return os.path.getsize(path) / (1024 * 1024)


# ============================================================================
# دانلود با yt-dlp
# ============================================================================

class DownloadError(Exception):
    pass


def _cookies_for(platform: str):
    mapping = {
        "instagram": IG_COOKIES_FILE,
        "tiktok":    TIKTOK_COOKIES_FILE,
        "twitter":   TWITTER_COOKIES_FILE,
    }
    path = mapping.get(platform)
    return path if path and os.path.exists(path) else None

def _build_ytdlp_opts(platform: str, out_dir: str) -> dict:
    opts = {
        "outtmpl":                       os.path.join(out_dir, "%(id)s.%(ext)s"),
        # تغییر اصلی: فقط دانلود صدا با حجم بسیار کم جهت استخراج سریع
        "format":                        "ba/wa", 
        "max_filesize":                  MAX_DOWNLOAD_MB * 1024 * 1024,
        "concurrent_fragment_downloads": CONCURRENT_FRAGMENTS,
        "retries":                       5,
        "fragment_retries":              5,
        "socket_timeout":                15, # کاهش تایم‌اوت برای سرعت بیشتر
        "http_chunk_size":               5 * 1024 * 1024,
        "quiet":                         True,
        "no_warnings":                   True,
        "noprogress":                    True,
        "noplaylist":                    True,
    }
    if ARIA2C_PATH:
        opts["external_downloader"] = "aria2c"
        opts["external_downloader_args"] = {
            "aria2c": ["-x", "16", "-s", "16", "-k", "1M", "--min-split-size=1M"]
        }
    cookies = _cookies_for(platform)
    if cookies:
        opts["cookiefile"] = cookies
    return opts

def _locate_downloaded_file(expected_path: str) -> str:
    if os.path.exists(expected_path):
        return expected_path
    base, _ = os.path.splitext(expected_path)
    # اضافه کردن پسوندهای صوتی رایج m4a و mp3 و ogg در صدر لیست جستجو
    for ext in (".m4a", ".mp3", ".ogg", ".opus", ".mp4", ".mkv", ".webm"):
        candidate = base + ext
        if os.path.exists(candidate):
            return candidate
    raise DownloadError("فایل صوتی دانلودشده پیدا نشد.")

def _run_download(url: str, platform: str, out_dir: str) -> dict:
    opts = _build_ytdlp_opts(platform, out_dir)
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        if "entries" in info and info["entries"]:
            info = info["entries"][0]
        filepath = _locate_downloaded_file(ydl.prepare_filename(info))
        ext = os.path.splitext(filepath)[1].lstrip(".").lower()
        return {
            "filepath": filepath,
            "title":    (info.get("title") or "media")[:200],
            "uploader": info.get("uploader") or info.get("channel") or "",
            "is_image": ext in ("jpg", "jpeg", "png", "webp"),
            "duration": info.get("duration") or 0,
        }


async def download_media(url: str, platform: str, out_dir: str) -> dict:
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, _run_download, url, platform, out_dir)
    except DownloadError:
        raise
    except yt_dlp.utils.DownloadError as e:
        logger.warning(f"خطای yt-dlp برای {url}: {e}")
        raise DownloadError(str(e)) from e
    except Exception as e:
        logger.exception(f"خطای غیرمنتظره در دانلود {url}")
        raise DownloadError(str(e)) from e


# ============================================================================
# ffmpeg: استخراج صدا / نمونه‌گیری / فشرده‌سازی
# ============================================================================

def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def extract_audio_track(video_path: str, out_dir: str):
    audio_path = os.path.join(out_dir, "audio.mp3")
    cmd = ["ffmpeg", "-y", "-i", video_path, "-vn",
           "-acodec", "libmp3lame", "-q:a", "2", audio_path]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return audio_path if os.path.exists(audio_path) else None
    except Exception as e:
        logger.warning(f"استخراج صدا ناموفق بود: {e}")
        return None


def compress_video(video_path: str, target_mb: int):
    out_path = os.path.join(os.path.dirname(video_path), "compressed.mp4")
    try:
        duration = float(subprocess.check_output(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", video_path]
        ).decode().strip())
    except Exception as e:
        logger.warning(f"خواندن مدت‌زمان ویدیو ناموفق بود: {e}")
        return None
    if duration <= 0:
        return None

    target_video_bitrate = max(int((target_mb * 0.9 * 8192) / duration), 150)
    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-b:v", f"{target_video_bitrate}k",
        "-maxrate", f"{target_video_bitrate}k",
        "-bufsize", f"{target_video_bitrate * 2}k",
        "-b:a", "64k", "-preset", "fast", out_path,
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return out_path if os.path.exists(out_path) else None
    except Exception as e:
        logger.warning(f"فشرده‌سازی ویدیو ناموفق بود: {e}")
        return None


# ============================================================================
# ابزار قالب مونوپیس تیتان سلف
# ============================================================================
async def safe_edit_titan(msg, text: str) -> None:
    """ویرایش امن با قالب مونوپیس اختصاصی تیتان"""
    formatted_text = f"```\n{text}\n```\n\n**__AXoRA SelF__**"
    for attempt in range(3):
        try:
            await msg.edit(formatted_text, parse_mode='markdown')
            return
        except errors.FloodWaitError as e:
            await asyncio.sleep(e.seconds + 1)
        except Exception:
            return


# ============================================================================
# ارسال امن (با مدیریت FloodWait)
# ============================================================================

_DOWNLOAD_SEMAPHORE = asyncio.Semaphore(MAX_CONCURRENT_DOWNLOADS)


async def safe_send_file(chat_id, path, **kwargs):
    for attempt in range(3):
        try:
            return await _client.send_file(chat_id, path, **kwargs)
        except errors.FloodWaitError as e:
            wait_s = e.seconds + 2
            logger.warning(f"FloodWait - {wait_s} ثانیه صبر (تلاش {attempt + 1}/3)...")
            await asyncio.sleep(wait_s)
    raise RuntimeError("ارسال فایل بعد از چند بار تلاش با FloodWait مواجه شد.")


# ============================================================================
# لاجیک اصلی
# ============================================================================

async def handle_job(event, status, link, platform, job_dir):
    chat_id = event.chat_id
    try:
        async with _client.action(chat_id, "document"):
            result = await download_media(link, platform, job_dir)

        filepath = result["filepath"]
        size_mb = get_file_size_mb(filepath)

        if not result["is_image"] and size_mb > MAX_FILE_SIZE_MB:
            await safe_edit_titan(status, "🔧 فایل حجمش زیاده، در حال فشرده‌سازی...")
            compressed = await asyncio.get_running_loop().run_in_executor(
                None, compress_video, filepath, MAX_FILE_SIZE_MB
            )
            if compressed:
                filepath = compressed
                size_mb = get_file_size_mb(filepath)

        if not result["is_image"] and size_mb > MAX_FILE_SIZE_MB:
            await safe_edit_titan(
                status,
                f"⚠️ فایل حتی بعد از فشرده‌سازی حدود {size_mb:.1f}MB شد، "
                f"بیشتر از سقف تنظیم‌شده ({MAX_FILE_SIZE_MB}MB). نمی‌تونم بفرستمش.",
            )
            return

        caption = f"{'🖼' if result['is_image'] else '🎬'} {result['title']}"
        if result.get("uploader"):
            caption += f"\n👤 {result['uploader']}"

        await safe_send_file(
            chat_id, filepath,
            caption=caption, reply_to=event.id, supports_streaming=True,
        )

        if not result["is_image"]:
            await send_audio_parts(event, status, filepath, result, job_dir)

        try:
            await status.delete()
        except Exception:
            pass

    except DownloadError as e:
        logger.warning(f"دانلود ناموفق: {e}")
        # نمایش ارور واقعی سیستم برای عیب‌یابی دقیق‌تر
        error_msg = str(e)
        if "IncompleteRead" in error_msg or "Connection" in error_msg or "timed out" in error_msg:
            await safe_edit_titan(status, "❌ خطای اتصال به شبکه! فیلترشکن (حالت TUN) رو بررسی کن.")
        elif "Private" in error_msg or "login" in error_msg:
            await safe_edit_titan(status, "🔒 این پست خصوصی یا نیازمند لاگین (کوکی) هست.")
        else:
            await safe_edit_titan(status, f"❌ خطا در دانلود:\n{error_msg[:150]}")
    except Exception as e:
        logger.exception("خطای غیرمنتظره در پردازش لینک")
        await safe_edit_titan(status, f"❌ یه خطای غیرمنتظره پیش اومد:\n{str(e)[:150]}")

# ============================================================================
# setup — توسط فایل self.py صدا زده می‌شه
# ============================================================================

def setup(client):
    global _client
    _client = client

    if not ffmpeg_available():
        logger.warning(
            "ffmpeg/ffprobe پیدا نشد! استخراج صدا و فشرده‌سازی ویدیوها کار نمی‌کنن."
        )
    if not ARIA2C_PATH:
        logger.info("aria2c نصب نیست؛ برای سرعت دانلود بیشتر آن را نصب کنید.")

    @client.on(events.NewMessage(outgoing=True))
    async def on_message(event):
        try:
            if not event.is_reply or not is_trigger(event.raw_text):
                return

            source = await event.get_reply_message()
            source_text = (getattr(source, "raw_text", "") or "") if source else ""
            link, platform = extract_link(source_text)
            
            if not link:
                formatted_text = f"```\nتوی پیامی که ریپلای کردی لینک پشتیبانی‌شده‌ای پیدا نکردم 🤔\n```\n\n**__AXoRA SelF__**"
                await event.reply(formatted_text, parse_mode='markdown')
                return

            formatted_status = f"```\n⏳ در حال دانلود... چند لحظه صبر کن\n```\n\n**__AXoRA SelF__**"
            status = await event.reply(formatted_status, parse_mode='markdown')

            async with _DOWNLOAD_SEMAPHORE:
                with tempfile.TemporaryDirectory(prefix="tgjob_") as job_dir:
                    await handle_job(event, status, link, platform, job_dir)

        except Exception:
            logger.exception("خطای کلی در پردازش پیام")

    logger.info("ماژول music لود شد ✅")