"""
archive.py — بایگانی گروه‌ها و کانال‌ها
==========================================
مدیریت دسته‌جمعیِ پوشه‌ی آرشیو تلگرام برای گروه‌ها و کانال‌ها، به‌همراه یک
مکانیزم Undo تک‌سطحی («حالت قبل») که وضعیتِ دقیقِ قبل از آخرین عملیات رو
برمی‌گردونه - نه صرفاً یک خروجِ خامِ همه‌چیز از آرشیو.

کاملاً self-contained، دقیقاً مثل rotating_name.py؛ مستقیم با panel_state.json
مشترک کار می‌کنه. دکمه‌های پنل («بایگانی گروه‌ها»/«بایگانی کانال‌ها»/«حذف
بایگانی گروه‌ها»/«حذف بایگانی کانال‌ها»/«حالت قبل») یک درخواست توی state
می‌ذارن؛ این ماژول هر ۲ ثانیه پول می‌کنه، اجرا می‌کنه، نتیجه رو توی همون چت
گزارش می‌ده.

مدل داده (در panel_state.json → _global):
    archive_action_request : {"chat_id":..., "action": "archive_groups" |
                               "archive_channels" | "unarchive_groups" |
                               "unarchive_channels" | "restore_previous"}
                              یا None   - پنل می‌ذاره
    archive_undo_snapshot  : {"action":..., "timestamp":...,
                               "peers": {peer_id_str: prev_folder_id}}
                              یا None   - این ماژول می‌ذاره/می‌خونه

تشخیصِ گروه در برابر کانال:
    - «گروه» یعنی: Chat معمولی + سوپرگروه (Channel با megagroup=True)
    - «کانال» یعنی: Channel برادکستِ خالص (megagroup=False)
    از پراپرتیِ آماده‌ی dialog.is_group تلتون استفاده می‌کنیم (که خودش دقیقاً
    همین منطق رو داره)، نه پیاده‌سازیِ دستی - تا با رفتار خودِ کتابخونه هم‌راستا بمونه.

نکته‌ی سرعت/امنیت: هر تغییر پوشه با یک (یا چند تاییِ دسته‌ای، اگه تعداد خیلی
زیاد بود) درخواستِ EditPeerFoldersRequest انجام می‌شه - نه یکی‌یکی روی هر
دیالوگ - که هم بی‌نهایت سریع‌تره و هم ریسکِ FloodWait رو تقریباً صفر می‌کنه.
دیالوگ‌هایی که از قبل توی وضعیتِ هدف بودن اصلاً توی درخواست فرستاده نمی‌شن.
"""

import asyncio
import json
import time
from pathlib import Path

from telethon import functions
from telethon.errors import FloodWaitError
from telethon.tl.types import Channel, InputFolderPeer

from core import panel_state

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"
_SIGNATURE = "**__AXoRA SelF__**"


def _fmt(body: str) -> str:
    return f"```{body}```\n\n{_SIGNATURE}"


_CHUNK_SIZE       = 100   # حداکثر تعداد peer در هر درخواست (محافظتی، برای حجم‌های خیلی بزرگ)
_ARCHIVE_FOLDER   = 1
_UNARCHIVE_FOLDER = 0

_busy = False   # ✅ قفلِ ساده - جلوگیریِ تداخل دو عملیاتِ بایگانیِ همزمان


# ===================== STATE I/O (مستقیم از panel_state.json) =====================

async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


# ===================== تشخیص گروه/کانال =====================

def _classify(dialog) -> str:
    """گروه/سوپرگروه => 'group' ، کانالِ برادکستِ خالص => 'channel' ، بقیه (پیوی/بات) => None"""
    if dialog.is_group:
        return "group"
    if isinstance(dialog.entity, Channel):
        return "channel"
    return None


async def _get_dialogs_by_kind(client, kind: str) -> list:
    result = []
    async for d in client.iter_dialogs(limit=None):
        if _classify(d) == kind:
            result.append(d)
    return result


# ===================== عملیاتِ دسته‌ای روی پوشه =====================

async def _batch_edit_folder(client, peers_with_folder: list) -> None:
    """peers_with_folder: [(input_entity, folder_id), ...] - دسته‌دسته (برای
    سرعت + محافظت در برابر حجم‌های خیلی بزرگ) ست می‌کنه. روی FloodWait دوباره
    تلاش می‌کنه؛ خطاهای دیگه رو بالا پرتاب می‌کنه تا پیامِ خطا واقعی باشه."""
    for i in range(0, len(peers_with_folder), _CHUNK_SIZE):
        chunk = peers_with_folder[i:i + _CHUNK_SIZE]
        folder_peers = [InputFolderPeer(peer=ie, folder_id=fid) for ie, fid in chunk]
        while True:
            try:
                await client(functions.folders.EditPeerFoldersRequest(folder_peers=folder_peers))
                break
            except FloodWaitError as e:
                await asyncio.sleep(e.seconds + 1)


def _snapshot(dialogs: list) -> dict:
    """peer_id (str) -> folder_id فعلیِ هرکدوم، برای Undo"""
    return {str(d.id): (1 if d.archived else 0) for d in dialogs}


async def _do_bulk_set(client, kind: str, target_folder: int) -> tuple:
    """گروه‌ها یا کانال‌ها رو دسته‌جمعی به target_folder می‌بره؛ قبلش کل وضعیتِ
    فعلیِ همون دسته رو برای Undo ذخیره می‌کنه.
    خروجی: (تعداد کل دسته, تعداد موردی که واقعاً تغییر کرد)"""
    dialogs = await _get_dialogs_by_kind(client, kind)
    if not dialogs:
        return 0, 0

    snapshot = _snapshot(dialogs)

    g = await _load_global()
    g["archive_undo_snapshot"] = {
        "action":    f"{'archive' if target_folder == _ARCHIVE_FOLDER else 'unarchive'}_{kind}s",
        "timestamp": time.time(),
        "peers":     snapshot,
    }
    await _save_global(g)

    # فقط اونایی که الان توی وضعیتِ هدف نیستن رو واقعاً می‌فرستیم - سریع‌تر و بی‌نیاز
    to_change = [
        (d.input_entity, target_folder)
        for d in dialogs
        if snapshot.get(str(d.id), 0) != target_folder
    ]
    if to_change:
        await _batch_edit_folder(client, to_change)

    return len(dialogs), len(to_change)


async def _do_restore(client) -> int:
    """طبق آخرین اسنپ‌شات، هر دیالوگ رو دقیقاً به folder_id قبلِ خودش برمی‌گردونه.
    خروجی: تعداد موردی که تغییر کرد، یا -1 اگه هیچ اسنپ‌شاتی ثبت نشده"""
    g    = await _load_global()
    snap = g.get("archive_undo_snapshot")
    if not snap or not snap.get("peers"):
        return -1

    peers_map = snap["peers"]
    to_change = []
    async for d in client.iter_dialogs(limit=None):
        pid = str(d.id)
        if pid in peers_map:
            wanted  = peers_map[pid]
            current = 1 if d.archived else 0
            if current != wanted:
                to_change.append((d.input_entity, wanted))

    if to_change:
        await _batch_edit_folder(client, to_change)

    g = await _load_global()
    g["archive_undo_snapshot"] = None
    await _save_global(g)
    return len(to_change)


# ===================== پردازشِ درخواست (از پنل) =====================

_KIND_LABEL_FA = {"group": "گروه‌", "channel": "کانال‌"}


async def _process_request(client, req: dict) -> None:
    global _busy
    chat_id = req.get("chat_id")
    action  = req.get("action")
    try:
        if action == "restore_previous":
            n = await _do_restore(client)
            if n == -1:
                msg = "⏪ چیزی برای بازگردانی به حالت قبل ثبت نشده."
            else:
                msg = f"⏪ حالت قبل بازگردانده شد ({n} مورد تغییر کرد)."

        elif action in ("archive_groups", "archive_channels", "unarchive_groups", "unarchive_channels"):
            kind          = "group" if "groups" in action else "channel"
            target_folder = _ARCHIVE_FOLDER if action.startswith("archive") else _UNARCHIVE_FOLDER
            total, changed = await _do_bulk_set(client, kind, target_folder)
            verb    = "بایگانی" if target_folder == _ARCHIVE_FOLDER else "خارج از بایگانی"
            kind_fa = _KIND_LABEL_FA[kind] + "ها"
            msg = f"🗄 {changed} {kind_fa} {verb} شدند (از مجموع {total} مورد)."

        else:
            msg = "⚠️ عملیات نامعتبر."

        if chat_id:
            await client.send_message(chat_id, _fmt(msg))

    except Exception as e:
        if chat_id:
            try:
                await client.send_message(chat_id, _fmt(f"❌ خطا در عملیات بایگانی: {e}"))
            except Exception:
                pass
    finally:
        _busy = False


async def _request_loop(client) -> None:
    global _busy
    while True:
        try:
            g   = await _load_global()
            req = g.get("archive_action_request")
            if req and not _busy:
                _busy = True
                g.pop("archive_action_request", None)
                await _save_global(g)
                asyncio.get_event_loop().create_task(_process_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(2)


def setup(client):
    asyncio.get_event_loop().create_task(_request_loop(client))