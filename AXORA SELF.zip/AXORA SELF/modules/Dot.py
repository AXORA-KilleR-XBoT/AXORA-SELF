"""
Dot Art (نقطه / Dot) — Unicode Braille image/text-to-art converter
==========================================================
Telethon userbot module, two modes, two trigger words:

  - "/نقطه ..." (or .نقطه, !نقطه)  -> Persian replies
  - "/Dot ..."   (or .Dot, !Dot, case-insensitive, "Dot." also works) -> English replies

  Both trigger words support the same two modes:
  1. Image mode (reply to a photo): renders real Unicode Braille art
     (U+2800-U+28FF), optionally "/نقطه 60" / "/Dot 60" for a custom width.
  2. Text mode (no image reply, text follows the command, e.g.
     "/نقطه سلام" or "/Dot HELLO"): renders the word/phrase, runs it
     through the exact same image pipeline, then rotates the resulting
     dot-bitmap 90 deg clockwise so it reads as a vertical banner.
     Supports English (LTR) and Persian (RTL, properly shaped).

  Every user-facing string lives in the _MESSAGES table further down,
  keyed by the same short codes the pipeline functions raise — the
  pipeline itself never contains language-specific text.

Wiring:
    This file only defines setup(client). Your module loader is expected
    to import it and call setup(existing_client) once; it never creates
    or starts a TelegramClient itself.

Image pipeline (see comments on each function for the "why"):
    download (in-memory bytes, no temp files)
      -> EXIF-correct orientation, flatten transparency onto white
      -> downscale huge sources, then resize to an exact 2x4-per-cell grid
      -> histogram equalize + autocontrast (fixes "solid black blob" on
         dark photos — see USE_EQUALIZE comment below)
      -> unsharp mask (protects edges/detail before we throw away tone)
      -> Floyd-Steinberg dither to 1 bit
      -> pack each 2x4 pixel block into one Braille codepoint
    All Pillow work runs inside asyncio.to_thread() so the event loop
    is never blocked, and a semaphore caps how many conversions run
    at once so a burst of requests can't thrash the CPU.

Text pipeline reuses every step above unchanged (see
_text_to_rotated_braille for exactly where rotation is inserted, and why
it has to happen before Braille characters are chosen, not after).
"""

import io
import os
import logging
import asyncio
from typing import Tuple

from PIL import Image, ImageOps, ImageFilter, ImageDraw, ImageFont, UnidentifiedImageError
from telethon import events

# Arabic/Persian text shaping + bidi reordering. Pillow has no complex-text-
# layout engine of its own, so rendering Persian correctly (joined letter
# forms, right-to-left order) needs these two small, pure-Python libraries —
# this is the standard, widely-used workaround for the same gap in
# matplotlib, reportlab, etc. Neither is a computer-vision framework; they
# only touch text, never pixels.
import arabic_reshaper
from bidi.algorithm import get_display

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tunables — change these to reshape the look, size, or performance profile.
# ---------------------------------------------------------------------------
COMMAND_PATTERN = r'^[./!]?(نقطه|(?i:dot)\.?)(?:\s+(.+))?$'   # group1 = which trigger word (-> reply language), group2 = width or text

DEFAULT_CELLS_WIDE = 10      # default output width, in Braille characters
MIN_CELLS_WIDE      = 20
MAX_CELLS_WIDE       = 140
MAX_CELLS_TALL        = 140     # safety clamp for pathological aspect ratios
MAX_OUTPUT_CHARS       = 3900   # keep comfortably under Telegram's 4096 cap

FONT_ASPECT = 0.33           # monospace glyph width/height ratio (~typical)

MAX_SOURCE_DIM      = 1600    # pre-shrink safeguard for huge uploads
MAX_DOWNLOAD_BYTES  = 20 * 1024 * 1024   # refuse to even fetch anything bigger

USE_EQUALIZE          = True    # histogram-equalize before autocontrast
AUTOCONTRAST_CUTOFF   = 1       # % of extreme pixels clipped on each end
SHARPEN_RADIUS, SHARPEN_PERCENT, SHARPEN_THRESHOLD = 1.4, 150, 2
GAMMA = 1.0                     # 1.0 = off; <1 brightens, >1 darkens

PROCESS_TIMEOUT = 10.0          # hard ceiling per the spec

# Cap how many conversions can run in worker threads at the same time, so a
# burst of requests degrades gracefully (queues) instead of fighting the CPU.
_CONVERSION_SEMAPHORE = asyncio.Semaphore(3)

# ---------------------------------------------------------------------------
# Text-mode tunables (new feature; nothing above this point was changed)
# ---------------------------------------------------------------------------
TEXT_THICKNESS_ROWS = 6     # pre-rotation row count -> controls stroke thickness, see _text_to_rotated_braille
MAX_TEXT_LENGTH = 60        # keep banners compact; longer input is rejected rather than silently truncated

# Bundled fonts are looked for next to this file first (fonts/<name>.ttf),
# falling back to common system paths so the module still works if only
# Dot.py itself gets copied onto a server that happens to have these fonts
# installed already.
_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_LATIN_FONT_CANDIDATES = [
    os.path.join(_MODULE_DIR, "fonts", "DejaVuSans.ttf"),
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]
_ARABIC_FONT_CANDIDATES = [
    os.path.join(_MODULE_DIR, "fonts", "NotoSansArabic-Bold.ttf"),
    "/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf",
    "/usr/share/fonts/truetype/noto/NotoNaskhArabic-Bold.ttf",
]


def _resolve_font(candidates) -> "str | None":
    return next((p for p in candidates if os.path.isfile(p)), None)


_LATIN_FONT_PATH = _resolve_font(_LATIN_FONT_CANDIDATES)
_ARABIC_FONT_PATH = _resolve_font(_ARABIC_FONT_CANDIDATES)

# ---------------------------------------------------------------------------
# Braille encoding
# ---------------------------------------------------------------------------
# Unicode Braille Patterns (U+2800-U+28FF) address a 2-wide x 4-tall dot
# cell. The codepoint is 0x2800 + an 8-bit mask, where each bit corresponds
# to one of the eight standardised dot positions:
#
#       dot 1 (bit 0x01) | dot 4 (bit 0x08)
#       dot 2 (bit 0x02) | dot 5 (bit 0x10)
#       dot 3 (bit 0x04) | dot 6 (bit 0x20)
#       dot 7 (bit 0x40) | dot 8 (bit 0x80)
#
# i.e. column 0 gets dots {1,2,3,7} top-to-bottom, column 1 gets {4,5,6,8}.
# This ordering is fixed by the Unicode standard, not arbitrary.
BRAILLE_BASE = 0x2800
_BRAILLE_CHARS = [chr(BRAILLE_BASE + i) for i in range(256)]   # precomputed, avoids 256*N chr() calls


def _compute_grid(width: int, height: int, target_cols: int) -> Tuple[int, int]:
    """
    Decide how many Braille cells (cols x rows) to render.

    A cell's dot matrix is 2 dots wide by 4 tall — an intrinsic 1:2 ratio.
    A monospace glyph is typically about twice as tall as it is wide
    (FONT_ASPECT ~ 0.5) — also ~1:2. Those two ratios are what make the
    on-screen result look proportionally correct:

        rows = cols * FONT_ASPECT * (source_height / source_width)

    which is just "pick enough rows that cols-many glyphs, each
    FONT_ASPECT as wide as they are tall, reproduce the source's aspect
    ratio". We then shrink cols/rows together (never independently, so
    the ratio above still holds) until the rendered text — one line per
    row, plus its newline — fits Telegram's message-length limit.
    """
    cols = max(MIN_CELLS_WIDE, min(MAX_CELLS_WIDE, target_cols))

    def rows_for(c: int) -> int:
        return max(1, round(c * FONT_ASPECT * (height / width)))

    rows = rows_for(cols)
    while cols > MIN_CELLS_WIDE and (cols * rows + rows) > MAX_OUTPUT_CHARS:
        cols -= 2
        rows = rows_for(cols)

    return cols, min(rows, MAX_CELLS_TALL)


def _load_and_normalise(source) -> Image.Image:
    """Open the image, fix camera rotation, and flatten transparency onto white."""
    img = Image.open(source)
    img.load()  # force decode now (inside the worker thread) so bad files fail here, predictably

    img = ImageOps.exif_transpose(img)  # respect phone-camera orientation metadata

    has_alpha = img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info)
    if has_alpha:
        # Transparent pixels (common in stickers/PNGs) must not be treated as
        # "dark" by the grayscale step below, or they'd wrongly render as
        # dots. Compositing onto white makes them read as blank background.
        img = img.convert("RGBA")
        flattened = Image.new("RGB", img.size, (255, 255, 255))
        flattened.paste(img, mask=img.split()[-1])
        img = flattened
    elif img.mode != "RGB":
        img = img.convert("RGB")

    return img


def _prepare_bilevel_image(img: Image.Image, cols: int, rows: int) -> Image.Image:
    """Resize + enhance + dither down to a 1-bit image sized exactly cols*2 x rows*4."""
    # Large uploads are shrunk with a cheap filter first; the precise resize
    # below is then working from a much smaller source, which is what
    # actually keeps this fast regardless of the original photo's size.
    if max(img.size) > MAX_SOURCE_DIM:
        img.thumbnail((MAX_SOURCE_DIM, MAX_SOURCE_DIM), Image.Resampling.BILINEAR)

    working_width, working_height = cols * 2, rows * 4

    # Resize BEFORE enhancing: it's cheap (small target), and it means the
    # contrast/sharpen/dither steps that follow are tuned to the actual
    # pixel grid that becomes Braille dots, not detail that gets thrown
    # away by a later downscale anyway.
    gray = img.convert("L").resize((working_width, working_height), Image.Resampling.LANCZOS)

    # Plain autocontrast only rescales min/max — it does nothing for a
    # photo whose histogram is *skewed* (e.g. mostly dark hair/shadow with
    # a small bright highlight), which is exactly the case that produces a
    # near-solid wall of filled Braille cells. Equalizing first redistributes
    # the actual tonal distribution across the full 0-255 range so dithering
    # has real separation to work with everywhere, not just in the
    # brightest slice of the image.
    if USE_EQUALIZE:
        gray = ImageOps.equalize(gray)
    gray = ImageOps.autocontrast(gray, cutoff=AUTOCONTRAST_CUTOFF)

    if GAMMA != 1.0:
        lut = [min(255, max(0, int(255 * ((i / 255) ** (1 / GAMMA))))) for i in range(256)]
        gray = gray.point(lut)  # single vectorised pass, no manual pixel loop

    # Unsharp mask brings back edge definition (eyes, hair strands, jawlines)
    # right before we throw away 7/8 of the tonal information via dithering.
    gray = gray.filter(ImageFilter.UnsharpMask(
        radius=SHARPEN_RADIUS, percent=SHARPEN_PERCENT, threshold=SHARPEN_THRESHOLD
    ))

    # Floyd-Steinberg error-diffusion dithering, implemented in C inside
    # Pillow — this is what actually preserves detail: instead of a hard
    # per-pixel threshold (which flattens whole midtone regions to solid
    # black or solid white), FS spreads each pixel's quantization error to
    # its neighbours, so a region's *density* of dots tracks its brightness.
    return gray.convert("1", dither=Image.Dither.FLOYDSTEINBERG)


def _bilevel_to_braille(bilevel: Image.Image, cols: int, rows: int, invert: bool = False) -> str:
    """
    Pack each 2x4 pixel block into one Braille codepoint.

    bilevel pixels are 0 (black) or 255 (white) after convert("1"). Black
    (the darker / detail-carrying part of the source) maps to a filled dot
    by default — set invert=True to flip that for a photo where the
    important content is the bright area instead.

    Performance note: we flatten to a single `bytes` object once via
    tobytes() so the hot loop indexes plain integers (fast) instead of
    calling the 2D PixelAccess object ~8x per cell; the 2x4 lookup itself
    is manually unrolled rather than looped, which avoids per-dot function
    call overhead. No numpy needed — for the grid sizes this produces
    (at most 140x140 cells), this comfortably finishes in well under a
    second in pure Python.
    """
    width = cols * 2
    data = bilevel.convert("L").tobytes()
    on = 255 if invert else 0

    lines = []
    for row in range(rows):
        y0 = row * 4
        r0, r1, r2, r3 = y0 * width, (y0 + 1) * width, (y0 + 2) * width, (y0 + 3) * width
        chars = []
        for col in range(cols):
            x0 = col * 2
            bits = 0
            if data[r0 + x0]     == on: bits |= 0x01   # dot 1
            if data[r1 + x0]     == on: bits |= 0x02   # dot 2
            if data[r2 + x0]     == on: bits |= 0x04   # dot 3
            if data[r0 + x0 + 1] == on: bits |= 0x08   # dot 4
            if data[r1 + x0 + 1] == on: bits |= 0x10   # dot 5
            if data[r2 + x0 + 1] == on: bits |= 0x20   # dot 6
            if data[r3 + x0]     == on: bits |= 0x40   # dot 7
            if data[r3 + x0 + 1] == on: bits |= 0x80   # dot 8
            chars.append(_BRAILLE_CHARS[bits])          # bits == 0 -> U+2800, the real "blank" Braille char
        lines.append("".join(chars))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Text mode: render a word/phrase, run it through the SAME pipeline as a
# photo (_prepare_bilevel_image, _bilevel_to_braille above — neither is
# touched by any of this), then rotate the dot-bitmap 90 deg clockwise.
# ---------------------------------------------------------------------------
def _is_rtl_script(text: str) -> bool:
    """True if `text` contains Arabic-script characters (this also covers Persian)."""
    for ch in text:
        cp = ord(ch)
        if (0x0600 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F      # Arabic, Arabic Supplement
                or 0xFB50 <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF):  # Arabic Presentation Forms A/B
            return True
    return False


def _render_text_bitmap(text: str, font_size: int = 120, padding: int = 12) -> Image.Image:
    """
    Rasterise `text` as black-on-white, handling Persian correctly.

    PIL's ImageDraw has no complex-text-layout engine: given raw Persian/
    Arabic codepoints it draws each letter in its isolated form, disconnected,
    in the wrong (logical, not visual) order. arabic_reshaper fixes the
    letterforms (initial/medial/final/isolated joining), and get_display
    reorders the result into the left-to-right sequence PIL needs to draw it
    so it *appears* right-to-left. English needs neither step.
    """
    rtl = _is_rtl_script(text)
    font_path = _ARABIC_FONT_PATH if rtl else _LATIN_FONT_PATH
    if not font_path:
        raise RuntimeError("no_font")

    display_text = get_display(arabic_reshaper.reshape(text)) if rtl else text
    font = ImageFont.truetype(font_path, font_size)

    probe = ImageDraw.Draw(Image.new("L", (10, 10)))
    l, t, r, b = probe.textbbox((0, 0), display_text, font=font)
    width, height = (r - l) + padding * 2, (b - t) + padding * 2

    img = Image.new("RGB", (width, height), (255, 255, 255))
    ImageDraw.Draw(img).text((padding - l, padding - t), display_text, font=font, fill=(0, 0, 0))
    return img


def _text_to_rotated_braille(text: str, thickness_rows: int = TEXT_THICKNESS_ROWS) -> str:
    """
    Render text -> dither it with the exact same _prepare_bilevel_image used
    for photos -> rotate that dot-bitmap 90 deg clockwise -> pack with the
    exact same _bilevel_to_braille used for photos.

    Rotation happens on the plain 1-bit pixel grid, BEFORE any Unicode
    Braille character is chosen for it — not after. A Braille cell is a
    fixed 2-wide x 4-tall dot matrix; there is no 4-wide x 2-tall Braille
    character, so "rotating" already-chosen glyphs 90 deg has no valid
    Braille representation — each glyph's internal dots would still face
    their original orientation while only its grid position moved, which
    reads as noise, not a rotated word. Rotating the dots first and only
    then packing them is the only way to get a genuinely rotated result.

    `thickness_rows` is fixed rather than reusing a fixed column count like
    the image pipeline does, because after rotation, the pre-rotation ROW
    count becomes the output's WIDTH (i.e. stroke thickness/legibility).
    Fixing columns instead would make longer phrases render thinner and
    thinner (more characters -> wider bitmap -> fewer rows for the same
    height) — fixing rows keeps every word equally legible and simply lets
    the banner run longer or shorter vertically instead.
    """
    text = text.strip()
    if not text:
        raise ValueError("empty_text")
    if len(text) > MAX_TEXT_LENGTH:
        raise ValueError("text_too_long")

    bitmap = _render_text_bitmap(text)
    width, height = bitmap.size

    # Solve _compute_grid's rows = cols * FONT_ASPECT * (h/w) backwards for
    # the cols value that yields our target thickness in rows.
    target_cols = round(thickness_rows * width / (FONT_ASPECT * height))
    target_cols += target_cols % 2  # must stay even for the post-rotation cell math below to line up

    cols, rows = _compute_grid(width, height, target_cols)   # unchanged existing function
    if cols % 2:  # belt-and-braces: guarantee evenness no matter how _compute_grid's own clamps landed
        cols -= 1
        rows = max(1, round(cols * FONT_ASPECT * (height / width)))

    bilevel = _prepare_bilevel_image(bitmap, cols, rows)          # unchanged existing function
    rotated = bilevel.transpose(Image.Transpose.ROTATE_270)        # 90 deg CLOCKWISE (verified empirically)

    # Rotating swaps the pixel dimensions (was cols*2 x rows*4, now rows*4 x
    # cols*2), so the cell counts fed to the packer swap and rescale to match.
    new_cols, new_rows = rows * 2, cols // 2
    return _bilevel_to_braille(rotated, new_cols, new_rows)        # unchanged existing function


def _convert_image_to_braille(image_bytes: bytes, target_cols: int = DEFAULT_CELLS_WIDE,
                               invert: bool = False) -> str:
    """
    Full pipeline entry point. Synchronous and CPU-bound by design — the
    caller is expected to run this via asyncio.to_thread().
    """
    img = _load_and_normalise(io.BytesIO(image_bytes))

    width, height = img.size
    if width < 4 or height < 4:
        raise ValueError("image_too_small")

    cols, rows = _compute_grid(width, height, target_cols)
    bilevel = _prepare_bilevel_image(img, cols, rows)
    return _bilevel_to_braille(bilevel, cols, rows, invert=invert)


def _is_supported_image(message) -> bool:
    """True for compressed photos and for documents sent as raw image files."""
    if getattr(message, "photo", None):
        return True
    doc = getattr(message, "document", None)
    if doc and doc.mime_type:
        return doc.mime_type.startswith("image/") and doc.mime_type != "image/svg+xml"
    return False


# ---------------------------------------------------------------------------
# User-facing text. Every message the bot ever sends lives here, in both
# languages, keyed by the same short codes the pipeline functions raise
# (e.g. ValueError("image_too_small")). Nothing above this line contains a
# single user-facing string — that keeps the actual algorithm free of any
# language concern, and means adding a third language later only means
# adding a third value here, not touching the pipeline.
# ---------------------------------------------------------------------------
_MESSAGES = {
    "need_input": {
        "fa": "⚠️ باید به یه عکس ریپلای کنی یا جلوی دستور یه متن بنویسی — مثلاً: /نقطه سلام",
        "en": "⚠️ Reply to an image, or put some text after the command — e.g. /Dot HELLO",
    },
    "image_too_large": {
        "fa": "⚠️ حجم عکس خیلی زیاده (حداکثر ۲۰ مگابایت).",
        "en": "⚠️ Image is too large (20MB max).",
    },
    "processing_image": {
        "fa": "🎨 دارم عکس رو به نقطه تبدیل می‌کنم...",
        "en": "🎨 Converting the image to dots...",
    },
    "download_failed": {
        "fa": "❌ نتونستم عکس رو دانلود کنم.",
        "en": "❌ Couldn't download the image.",
    },
    "timeout": {
        "fa": "⏱️ پردازش خیلی طول کشید، یه چیز ساده‌تر امتحان کن.",
        "en": "⏱️ Processing took too long — try something simpler.",
    },
    "bad_image": {
        "fa": "⚠️ فایلی که فرستادی عکس معتبری نیست.",
        "en": "⚠️ That file isn't a valid image.",
    },
    "bomb": {
        "fa": "⚠️ ابعاد عکس اونقدر بزرگه که پردازشش امن نیست.",
        "en": "⚠️ Image dimensions are unsafely large to process.",
    },
    "image_too_small": {
        "fa": "⚠️ عکس خیلی کوچیکه، نمیشه تبدیلش کرد.",
        "en": "⚠️ Image is too small to convert.",
    },
    "unexpected_image": {
        "fa": "❌ یه خطای غیرمنتظره حین پردازش عکس پیش اومد.",
        "en": "❌ An unexpected error occurred while processing the image.",
    },
    "processing_text": {
        "fa": "🎨 دارم متن رو به نقطه تبدیل می‌کنم...",
        "en": "🎨 Converting the text to dots...",
    },
    "empty_text": {
        "fa": "⚠️ متنی برای نمایش دادن نیست.",
        "en": "⚠️ There's no text to render.",
    },
    "text_too_long": {
        "fa": f"⚠️ متن خیلی طولانیه (حداکثر {MAX_TEXT_LENGTH} حرف).",
        "en": f"⚠️ Text is too long ({MAX_TEXT_LENGTH} characters max).",
    },
    "no_font": {
        "fa": "⚠️ روی سرور فونت مناسبی برای نمایش این متن نصب نیست.",
        "en": "⚠️ No suitable font is installed on the server to render this text.",
    },
    "unexpected_text": {
        "fa": "❌ یه خطای غیرمنتظره حین پردازش متن پیش اومد.",
        "en": "❌ An unexpected error occurred while processing the text.",
    },
}


def _t(code: str, lang: str) -> str:
    """Look up a user-facing message by code and language, falling back safely."""
    entry = _MESSAGES.get(code, _MESSAGES["unexpected_image"])
    return f"**{entry.get(lang, entry['en'])}**"


# ---------------------------------------------------------------------------
# Telethon wiring
# ---------------------------------------------------------------------------
def setup(client):
    """
    Register /نقطه (Persian replies) and /Dot (English replies) on an
    already-running Telethon client. Does not create, start, or run a
    client — that's the host bot's job.
    """

    @client.on(events.NewMessage(pattern=COMMAND_PATTERN, outgoing=True))
    async def _dot_art_handler(event: events.NewMessage.Event):
        keyword = event.pattern_match.group(1)
        lang = "fa" if keyword == "نقطه" else "en"          # نقطه -> Persian replies, Dot/Dot./DOT/... -> English
        argument = (event.pattern_match.group(2) or "").strip()

        reply = await event.get_reply_message()
        has_image = bool(reply) and _is_supported_image(reply)

        # --- Mode 1: reply to an image ---
        if has_image:
            size = getattr(reply.file, "size", None) if reply.file else None
            if size and size > MAX_DOWNLOAD_BYTES:
                await event.edit(_t("image_too_large", lang))
                return

            target_cols = DEFAULT_CELLS_WIDE
            if argument.isdigit():
                target_cols = int(argument)

            await event.edit(_t("processing_image", lang))

            try:
                # Downloaded straight into memory — file=bytes tells Telethon to
                # hand back a `bytes` object instead of writing to disk, so
                # there is no temp file to clean up afterwards.
                image_bytes = await reply.download_media(file=bytes)
                if not image_bytes:
                    await event.edit(_t("download_failed", lang))
                    return

                async with _CONVERSION_SEMAPHORE:
                    art = await asyncio.wait_for(
                        asyncio.to_thread(_convert_image_to_braille, image_bytes, target_cols),
                        timeout=PROCESS_TIMEOUT,
                    )

                result = f"```\n{art}\n```"
                if len(result) > 4096:              # final safety net regardless of MAX_OUTPUT_CHARS tuning
                    result = result[:4090] + "\n```"
                await event.edit(result)

            except asyncio.TimeoutError:
                await event.edit(_t("timeout", lang))
            except UnidentifiedImageError:
                await event.edit(_t("bad_image", lang))
            except Image.DecompressionBombError:
                await event.edit(_t("bomb", lang))
            except ValueError as exc:
                await event.edit(_t(str(exc), lang))        # exc's message is a code, e.g. "image_too_small"
            except Exception:
                logger.exception("Dot-art conversion failed")
                await event.edit(_t("unexpected_image", lang))
            return

        # --- Mode 2: no image reply, but text was given — rotated text banner ---
        if argument:
            await event.edit(_t("processing_text", lang))
            try:
                async with _CONVERSION_SEMAPHORE:
                    art = await asyncio.wait_for(
                        asyncio.to_thread(_text_to_rotated_braille, argument),
                        timeout=PROCESS_TIMEOUT,
                    )

                result = f"```\n{art}\n```"
                if len(result) > 4096:
                    result = result[:4090] + "\n```"
                await event.edit(result)

            except asyncio.TimeoutError:
                await event.edit(_t("timeout", lang))
            except (ValueError, RuntimeError) as exc:
                await event.edit(_t(str(exc), lang))         # exc's message is a code, e.g. "empty_text", "no_font"
            except Exception:
                logger.exception("Dot-art text conversion failed")
                await event.edit(_t("unexpected_text", lang))
            return

        # --- Neither an image reply nor any text ---
        await event.edit(_t("need_input", lang))

    logger.info("Dot Art (نقطه / Dot) module loaded")