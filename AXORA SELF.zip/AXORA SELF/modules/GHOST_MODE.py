"""
GHOST_MODE.py — حالت روح (شبیه‌سازی اکشن آنلاین)
===================================================
منطق این فایل عیناً همون کدِ اکشن‌هاست که قبلاً تست شده و درست کار می‌کنه؛
هیچ خط از منطقِ اصلی (ACTION_MAP، dedicated_action_loop، smart_chat_trigger،
keep_online) تغییر نکرده. تنها دو تغییر:
    ۱. هندلر دستور متنیِ «اکشن ...» حذف شد.
    ۲. یک حلقه‌ی پول‌کننده (_panel_sync_loop) اضافه شد که هر ۲ ثانیه
       panel_state.json رو می‌خونه و _current_action رو با دکمه‌ی انتخاب‌شده
       توی «حالت روح» پنل هماهنگ نگه می‌داره - دقیقاً همون
       request-relay pattern که بقیه‌ی ماژول‌ها (rotating_name.py و ...) دارن.

کلید state: ghost_action_type  (None یا یکی از: ویس/عکس/ویدیو/بازی/تایپ/استیکر)
این کلید دقیقاً همون کلیدهای ACTION_MAP هست، بدون هیچ لایه‌ی ترجمه‌ای.
"""

import asyncio
import json
import logging
from pathlib import Path
from telethon import events, errors, functions
from telethon.tl.functions.messages import SetTypingRequest
from telethon.tl.types import (
    SendMessageTypingAction,
    SendMessageRecordAudioAction,
    SendMessageUploadPhotoAction,
    SendMessageUploadVideoAction,
    SendMessageGamePlayAction,
    SendMessageChooseStickerAction
)

from core import panel_state

logger = logging.getLogger("GHOST_MODE")

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

# ============================================================================
# وضعیت‌های سراسری
# ============================================================================
_current_action = None
# برای ذخیره تسک‌های فعال هر چت تا تداخلی پیش نیاد
_active_chat_tasks = {}

ACTION_MAP = {
    "ویس": SendMessageRecordAudioAction(),
    "عکس": SendMessageUploadPhotoAction(progress=0),
    "ویدیو": SendMessageUploadVideoAction(progress=0),
    "بازی": SendMessageGamePlayAction(),
    "تایپ": SendMessageTypingAction(),
    "استیکر": SendMessageChooseStickerAction()
}

# ============================================================================
# STATE I/O (مستقیم از panel_state.json - همون الگوی بقیه‌ی ماژول‌ها)
# ============================================================================
async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


async def dedicated_action_loop(client, chat_id):
    """حلقه مداوم ارسال اکشن برای یک چت خاص تا زمانی که اکشن سراسری فعال است"""
    global _current_action
    while _current_action:
        try:
            await client(SetTypingRequest(
                peer=chat_id,
                action=ACTION_MAP[_current_action]
            ))
        except errors.FloodWaitError as e:
            await asyncio.sleep(e.seconds)
        except Exception:
            # اگر دسترسی نداشتیم یا چت نامعتبر بود حلقه رو برای این چت می‌بندیم
            break
        
        # تمدید دقیق هر ۴.۵ ثانیه یکبار تا اکشن هرگز قطع نشود
        await asyncio.sleep(4.5)


# ============================================================================
# ✅ جدید: هماهنگ‌سازی با دکمه‌های «حالت روح» توی پنل
# ============================================================================
async def _panel_sync_loop(client):
    """هر ۲ ثانیه panel_state.json رو می‌خونه؛ اگه ghost_action_type از پنل عوض
    شده باشه (یکی از دکمه‌های اکشن زده شده یا با زدنِ دوباره‌ی همون دکمه خاموش
    شده)، _current_action رو با همون مقدار هماهنگ می‌کنه و تسک‌های قبلی رو
    می‌بنده تا تغییر فوراً روی چت‌های فعال اعمال بشه."""
    global _current_action, _active_chat_tasks
    last_seen = "__unset__"
    while True:
        try:
            g = await _load_global()
            desired = g.get("ghost_action_type")
            if desired != last_seen:
                last_seen = desired
                _current_action = desired if desired in ACTION_MAP else None
                for task in list(_active_chat_tasks.values()):
                    task.cancel()
                _active_chat_tasks.clear()
        except Exception:
            pass
        await asyncio.sleep(2)


# ============================================================================
# setup
# ============================================================================
def setup(client):
    global _current_action

    # هندلر هوشمند: رصد پیام‌های ورودی و خروجی برای فعال‌سازی اکشن روی آن چت خاص
    @client.on(events.NewMessage())
    async def smart_chat_trigger(event):
        global _current_action, _active_chat_tasks
        # اگر هیچ اکشنی فعال نیست کاری نکن
        if not _current_action:
            return
            
        chat_id = event.chat_id
        
        # اگر کانال عمومی بود اسکیپ کن
        if event.is_channel and not event.is_group:
            return
            
        # اگر برای این چت از قبل حلقه ارسال اکشن نساختیم، براش یه تسک اختصاصی می‌سازیم
        if chat_id not in _active_chat_tasks or _active_chat_tasks[chat_id].done():
            _active_chat_tasks[chat_id] = asyncio.create_task(
                dedicated_action_loop(client, chat_id)
            )
    # 🟢 کد جدید: حلقه موازی برای آنلاین نگه داشتن دائمی اکانت برای همه #
    async def keep_online():
        while True:
            try:
                await client(functions.account.UpdateStatusRequest(offline=False))
            except Exception:
                pass
            await asyncio.sleep(10)

    # استارت زدن تسک آنلاین ماندن به محض لود شدن ماژول #
    asyncio.create_task(keep_online())
    # ✅ استارت زدن حلقه‌ی هماهنگ‌سازی با پنل
    asyncio.get_event_loop().create_task(_panel_sync_loop(client))