"""
POKER -- Telethon UserBot plugin
=================================

Auto-reroll Telegram "dice" mini-game -- Ghost / Stealth version.
"""

import asyncio
import logging
import re
import time
from typing import Optional, Tuple

from telethon import TelegramClient, events
from telethon.errors import FloodWaitError, MessageDeleteForbiddenError
from telethon.tl.types import InputMediaDice, Message

__all__ = ["POKER", "setup"]

logger = logging.getLogger("poker")

_DICE_EMOJI = "🎲"
_COMMAND_RE = re.compile(r"^[/.!](?:dice|تاس)\s*([1-6])?\s*$", re.IGNORECASE)

_MAX_ATTEMPTS = 100
_ROLL_DELAY_SECONDS = 0.25   # کمی سریع‌تر
_TIMEOUT_SECONDS = 90


class POKER:
    """Namespace for the /dice mini-game plugin."""

    _registered_clients: set[TelegramClient] = set()

    @classmethod
    def setup(cls, client: TelegramClient) -> TelegramClient:
        if client in cls._registered_clients:
            logger.debug("POKER: client already registered")
            return client

        @client.on(events.NewMessage(pattern=_COMMAND_RE, outgoing=True))
        async def _dice_command(event: events.NewMessage.Event) -> None:
            # فقط دستوراتی که خودت فرستادی اجرا بشه
            try:
                await cls._handle(event)
            except Exception:
                logger.exception("POKER: unhandled error in /dice command")

        cls._registered_clients.add(client)
        logger.info("POKER module loaded successfully (/dice, تاس)")
        return client

    @staticmethod
    async def _send_one(event: events.NewMessage.Event) -> Tuple[Optional[Message], Optional[int]]:
        try:
            sent: Message = await event.client.send_file(
                event.chat_id,
                InputMediaDice(emoticon=_DICE_EMOJI),
            )
            value: Optional[int] = getattr(getattr(sent, "media", None), "value", None)
            return sent, value
        except FloodWaitError as exc:
            logger.warning("POKER: flood wait %d seconds", exc.seconds)
            await asyncio.sleep(exc.seconds)
            return None, None
        except Exception:
            logger.exception("POKER: failed to send dice")
            return None, None

    @staticmethod
    async def _handle(event: events.NewMessage.Event) -> None:
        guess_raw: Optional[str] = event.pattern_match.group(1)
        guess: Optional[int] = int(guess_raw) if guess_raw else None

        if guess is None:
            await POKER._send_one(event)
            return

        # حذف پیام دستور (با مدیریت خطا)
        try:
            await event.delete()
        except (MessageDeleteForbiddenError, Exception):
            logger.debug("POKER: could not delete command message (normal in some chats)")

        start = time.monotonic()
        attempt = 0

        while attempt < _MAX_ATTEMPTS:
            if time.monotonic() - start > _TIMEOUT_SECONDS:
                logger.info("POKER: timeout for guess %d", guess)
                return

            attempt += 1
            sent_msg, value = await POKER._send_one(event)

            if sent_msg is None or value is None:
                await asyncio.sleep(1.0)
                continue

            if value == guess:
                logger.info("POKER: ✅ Success! Got %d in %d attempts", value, attempt)
                return

            try:
                await sent_msg.delete()
            except Exception:
                pass  # حذف نشد، ادامه بده

            await asyncio.sleep(_ROLL_DELAY_SECONDS)

        logger.warning("POKER: max attempts reached for guess %d", guess)


# Module-level alias
setup = POKER.setup