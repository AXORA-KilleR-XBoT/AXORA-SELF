"""
QR.py -- QR Code Generator & Analyzer module for a Telethon User Bot.

Commands
--------
.qr <text|url|...> [-s SIZE]
    Generate a high-quality QR code image from arbitrary UTF-8 text: plain
    text, a URL, an email (mailto:), a phone number (tel:), an SMS link,
    a geo: coordinate, a WiFi connection string, a vCard, a Bitcoin URI, or
    any other payload a scanner might reasonably encounter. SIZE is an
    optional output width/height in pixels (default: 512, range: 128-2000),
    supplied as ``-s SIZE`` / ``--size SIZE`` anywhere in the command.

.scanqr
    Reply to any message containing a photo or image file with this
    command. Every QR code found in the image is decoded, classified, and
    -- for QR codes containing a URL -- enriched with basic, publicly
    available metadata (final URL, title, meta description, content type,
    size, etc.) plus a handful of informational, non-judgmental risk
    observations (HTTPS/HTTP, redirects, shorteners, direct IPs, suspicious
    ports/extensions, and so on). Known services (YouTube incl. Shorts,
    Instagram, TikTok, Twitter/X, Telegram, GitHub) get extra, more
    reliable metadata (title/author/description) via each service's own
    official API instead of fragile HTML scraping.

Dependencies
------------
Required:
    pip install --upgrade telethon "qrcode[pil]" Pillow httpx beautifulsoup4

Optional (QR *scanning* only -- generating QR codes never needs these; at
least one of the two is required to decode QR codes out of an image, but
the module still loads and `.qr` generation still works with neither
installed):
    pip install --upgrade pyzbar          # small, recommended
    pip install --upgrade opencv-python-headless numpy   # heavier fallback/second-opinion decoder

Prefer ``opencv-python-headless`` over plain ``opencv-python`` on a server
-- the plain package pulls in GUI (Qt/GTK) dependencies this bot never
uses, which matters on a small VPS. pyzbar additionally needs the system
"zbar" shared library:
    Debian/Ubuntu : sudo apt-get install libzbar0
    Fedora/RHEL   : sudo dnf install zbar
    macOS         : brew install zbar
    Windows       : bundled automatically with the pyzbar wheel

Integration
-----------
    from modules import QR
    QR.setup(client)
"""

from __future__ import annotations

import asyncio
import base64
import html
import io
import ipaddress
import logging
import os
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
from urllib.parse import ParseResult, parse_qsl, quote, unquote, urlparse

import httpx
import qrcode
from bs4 import BeautifulSoup
from PIL import Image, ImageOps
from qrcode.constants import ERROR_CORRECT_L, ERROR_CORRECT_M
from qrcode.exceptions import DataOverflowError
from telethon import TelegramClient, events
from telethon.tl.custom.message import Message
from telethon.tl.types import MessageMediaDocument, MessageMediaPhoto

logger = logging.getLogger(__name__)

__all__ = ["setup"]

# QR *scanning* needs at least one decode backend, but neither is needed to
# *generate* QR codes -- so both are imported defensively. A missing/broken
# optional dependency should never take down the whole module (which would
# also kill unrelated features like `.qr` generation); it should just
# disable the specific decode pass that depended on it. See docstring above
# for install instructions and why opencv-python-headless is recommended.
try:
    from pyzbar.pyzbar import ZBarSymbol
    from pyzbar.pyzbar import decode as pyzbar_decode
    HAS_PYZBAR = True
except (ImportError, OSError):
    # OSError covers the common "libzbar.so not found" case when the
    # Python package is installed but the system zbar library isn't.
    logger.warning("pyzbar unavailable -- QR scanning will rely on OpenCV only, if installed.")
    ZBarSymbol = None
    pyzbar_decode = None
    HAS_PYZBAR = False

try:
    import cv2
    import numpy as np
    HAS_CV2 = True
except ImportError:
    logger.warning("OpenCV unavailable -- QR scanning will rely on pyzbar only, if installed.")
    cv2 = None
    np = None
    HAS_CV2 = False

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------

COMMAND_PREFIX = "/"

DEFAULT_QR_SIZE = 512
MIN_QR_SIZE = 128
MAX_QR_SIZE = 2000
# The real ceiling for byte-mode data at error-correction level M (what
# this module always uses) is 2331 bytes at version 40 -- the previous
# 4000-byte limit here let content pass the up-front "too long" check and
# then still fail later inside qrcode with a less friendly error. Kept a
# little under the hard 2331-byte ceiling as a safety margin.
MAX_QR_PAYLOAD_BYTES = 2300

# QR pixel size is controlled *only* via box_size (see _generate_qr_image);
# QR_BORDER is the standard quiet-zone width in modules, and MIN_BOX_SIZE
# is a floor on pixels-per-module so very data-heavy payloads never render
# so densely that a phone camera struggles to resolve individual modules,
# even if that means the final image ends up bigger than the requested size.
QR_BORDER = 4
MIN_BOX_SIZE = 4

MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_QR_CODES_PER_IMAGE = 10
MIN_UPSCALE_DIMENSION = 600
# Scanned photos (esp. straight off a modern phone) can be 4K+ for no
# benefit to QR *detection* -- downscaling before handing them to the
# decoders keeps CPU/RAM bounded on a small VPS without hurting real-world
# scan reliability (a QR's finder patterns don't need 4K to be resolved).
SCAN_MAX_DIMENSION = 1800

# "Embed this image in a QR code" fallback (used when /qr replies to an
# image that contains no scannable QR of its own). A raw data-URI QR only
# opens in dedicated QR-reader apps -- standard phone camera scanners only
# auto-act on recognized schemes (http/https, tel, mailto, sms, wifi, geo)
# and do not render "data:" as an image. So the image is NEVER recompressed
# or shrunk to make it fit -- the PRIMARY strategy is always to upload the
# *original, untouched* bytes to a public host and embed that plain
# https:// link instead, which every scanner recognizes and which serves
# the image back at full original quality. Two independent, no-signup
# anonymous hosts are tried in order for resilience (either one being
# blocked, rate-limited, or temporarily down doesn't break the feature).
# (Telegra.ph's own /upload endpoint was used here previously, but Telegram
# permanently disabled uploads on Telegraph in September 2024, so it no
# longer works at all -- this is why the earlier version always silently
# fell back to the local method. Free anonymous hosts do change over time;
# if both of these ever stop working, swap in a replacement here.)
CATBOX_UPLOAD_URL = "https://catbox.moe/user/api.php"
ZEROXZERO_UPLOAD_URL = "https://0x0.st/"
ENVS_UPLOAD_URL = "https://envs.sh/"
UPLOAD_TIMEOUT = 20.0

# Only reached if BOTH uploads above fail. Never applied to large/
# high-resolution images (see _DIRECT_EMBED_MAX_* below) -- a QR code
# cannot realistically hold a real photo, and mangling a large original
# down to a handful of recognizable pixels just to force *something* into
# the code destroys it for no real benefit. This path exists only so a
# genuinely small image (an icon, a sticker, a tiny logo) can still be
# embedded directly when hosting is unavailable.
_DIRECT_EMBED_MAX_DIMENSION = 300
_DIRECT_EMBED_MAX_SOURCE_BYTES = 100 * 1024
_IMAGE_QR_BYTE_BUDGET = 1500
_EMBED_THUMBNAIL_SIDES = (300, 200, 150, 128, 96, 64)
_EMBED_JPEG_QUALITIES = (85, 70, 55, 40)

# Absolute last resort, reached only when *every* upload host failed AND
# the image is too large/high-res even for the normal embed above. Uses a
# larger byte budget (this path renders at ERROR_CORRECT_L instead of the
# usual M, trading some real-world scan resilience for ~27% more raw data
# capacity -- confirmed empirically: 2953 bytes max at L vs 2331 at M,
# both for version-40 byte-mode data) and a heavier compression cascade,
# purely so the command still produces *something* scannable instead of a
# hard failure -- always paired with an explicit, honest "this is a
# low-quality fallback" caption, never silently substituted for the real
# thing.
_EMERGENCY_EMBED_BYTE_BUDGET = 2900
_EMERGENCY_THUMBNAIL_SIDES = (320, 256, 192, 128)
_EMERGENCY_JPEG_QUALITIES = (75, 60, 45, 30)

HTTP_TIMEOUT = httpx.Timeout(10.0, connect=5.0)
MAX_REDIRECTS = 10
MAX_BODY_PEEK_BYTES = 131_072
DNS_RESOLVE_TIMEOUT = 5.0
USER_AGENT = "Mozilla/5.0 (compatible; TelegramQRAnalyzer/1.0; +https://t.me)"

LONG_URL_THRESHOLD = 100


KNOWN_SHORTENERS = frozenset({
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "adf.ly", "bit.do", "mcaf.ee", "cutt.ly", "rebrand.ly", "shorturl.at",
    "tiny.cc", "lnkd.in", "s.id", "v.gd", "rb.gy", "shrtco.de", "soo.gd",
    "clck.ru", "qr.ae", "tr.im", "u.to", "x.co", "rotf.lol", "shorte.st",
})

SUSPICIOUS_EXTENSIONS = frozenset({
    ".exe", ".bat", ".cmd", ".scr", ".msi", ".msix", ".appx", ".apk",
    ".ipa", ".jar", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh",
    ".pif", ".gadget", ".com", ".hta", ".lnk", ".reg", ".cpl", ".dll",
    ".ps1", ".ps1xml", ".psc1", ".msc",
})

# --------------------------------------------------------------------------
# Known-service detection (for richer, more reliable URL metadata)
# --------------------------------------------------------------------------
# Hostnames are matched with a leading "www." stripped (see _strip_www), so
# only the bare registrable/subdomain form needs listing here.

YOUTUBE_HOSTS = frozenset({
    "youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com",
})
YOUTU_BE_HOSTS = frozenset({"youtu.be"})
INSTAGRAM_HOSTS = frozenset({"instagram.com"})
TIKTOK_HOSTS = frozenset({"tiktok.com", "vm.tiktok.com", "vt.tiktok.com", "m.tiktok.com"})
TWITTER_HOSTS = frozenset({"twitter.com", "mobile.twitter.com", "x.com"})
TELEGRAM_HOSTS = frozenset({"t.me", "telegram.me", "telegram.dog"})
GITHUB_HOSTS = frozenset({"github.com"})

# Official, documented, key-free metadata endpoints -- used instead of
# scraping HTML for these services, since JS-heavy pages, consent walls,
# and UA-sniffing make plain HTML fetching unreliable for them in practice
# (this is specifically what previously made YouTube links fail while
# simpler sites like Instagram's server-rendered OG tags kept working).
YOUTUBE_OEMBED_URL = "https://www.youtube.com/oembed"
TIKTOK_OEMBED_URL = "https://www.tiktok.com/oembed"
TWITTER_OEMBED_URL = "https://publish.twitter.com/oembed"
GITHUB_API_BASE = "https://api.github.com/repos"

_TELEGRAM_TEXT_LIMIT = 4096
_TELEGRAM_CAPTION_LIMIT = 1024

# Command words accepted for each action. Persian aliases let the exact same
# handlers be triggered with native-script commands (e.g. "/کیوآر", "/اسکن").
QR_COMMAND_WORDS = ("qr", "کیوآر")
SCAN_COMMAND_WORDS = ("scan", "scanqr", "اسکن")

_QR_ALTERNATION = "|".join(re.escape(w) for w in QR_COMMAND_WORDS)
_SCAN_ALTERNATION = "|".join(re.escape(w) for w in SCAN_COMMAND_WORDS)

# Named groups let handlers recover exactly which command word was used
# (so the reply language can match it) without disturbing the existing
# positional "content" capture used throughout the .qr handler.
QR_PATTERN = (
    rf"(?i)^{re.escape(COMMAND_PREFIX)}(?P<cmd>{_QR_ALTERNATION})"
    rf"(?:\s+(?P<content>[\s\S]+))?$"
)
SCANQR_PATTERN = (
    rf"(?i)^{re.escape(COMMAND_PREFIX)}(?P<cmd>{_SCAN_ALTERNATION})"
    rf"(?:\s+[\s\S]*)?$"
)

_URL_FINDER_PATTERN = re.compile(
    r"""(https?://[^\s<>"'\u200c]+|www\.[^\s<>"'\u200c]+\.[a-zA-Z]{2,}[^\s<>"'\u200c]*)""",
    re.IGNORECASE,
)

_SIZE_FLAG_PATTERN = re.compile(
    r"(?:^|\s)(?:-s|--size)(?:[=\s]+)(\d{1,4})(?:\s|$)", re.IGNORECASE
)
_WIFI_FIELD_PATTERN = re.compile(r"([A-Za-z]+):((?:\\.|[^;\\])*)")
_EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
_PHONE_PATTERN = re.compile(r"^\+?[\d\s\-().]{7,20}$")
_WWW_PATTERN = re.compile(r"^www\.[^\s]+\.[a-zA-Z]{2,}", re.IGNORECASE)
_BTC_LEGACY_PATTERN = re.compile(r"^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$")
_BTC_BECH32_PATTERN = re.compile(r"^(bc1|tb1)[a-z0-9]{25,59}$", re.IGNORECASE)
_FILENAME_PATTERN = re.compile(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)\"?", re.IGNORECASE)
_DESCRIPTION_META_PATTERN = re.compile("^description$", re.IGNORECASE)
_OG_DESCRIPTION_META_PATTERN = re.compile("^og:description$", re.IGNORECASE)
_DATA_IMAGE_URI_PATTERN = re.compile(
    r"^data:image/(?P<subtype>[a-zA-Z0-9.+-]+);base64,(?P<payload>[A-Za-z0-9+/=]+)$"
)


# --------------------------------------------------------------------------
# Internationalization (English / Persian)
# --------------------------------------------------------------------------
# Every user-facing string lives here as {"en": ..., "fa": ...}. Nothing in
# the detection/parsing/decoding/URL-analysis logic below reads this table;
# it is consulted only when building text to display, so translating or
# adding a language never touches how QR content is classified or analyzed.

_STRINGS: dict[str, dict[str, str]] = {
    "qr_usage": {
        "en": (
            "<b>QR Code Generator</b>\n"
            "Usage: <code>{prefix}qr &lt;text or URL&gt; [-s SIZE]</code> "
            "(Persian: <code>{prefix}کیوآر</code>)\n\n"
            "Examples:\n"
            "<code>{prefix}qr Hello World</code>\n"
            "<code>{prefix}qr https://example.com</code>\n"
            "<code>{prefix}qr https://example.com -s 700</code>\n\n"
            "Reply to an image with just <code>{prefix}qr</code> (no text) "
            "to turn that image itself into a new QR code (uploads it and "
            "embeds a public link, or embeds it directly if it's small). "
            "This never reads/shows an existing QR code's content — for "
            "that, reply with <code>{prefix}scan</code> instead.\n\n"
            "Size range: {min_size}-{max_size}px (default {default_size}px)."
        ),
        "fa": (
            "<b>تولید کد QR</b>\n"
            "استفاده: <code>{prefix}کیوآر &lt;متن یا لینک&gt; [-s SIZE]</code> "
            "(English: <code>{prefix}qr</code>)\n\n"
            "مثال:\n"
            "<code>{prefix}کیوآر سلام دنیا</code>\n"
            "<code>{prefix}کیوآر https://example.com</code>\n"
            "<code>{prefix}کیوآر https://example.com -s 700</code>\n\n"
            "اگه بدون متن، روی یه عکس ریپلای کنی و فقط <code>{prefix}کیوآر</code> "
            "بفرستی، همون عکس رو تبدیل به یه QR جدید می‌کنم (آپلودش می‌کنم و "
            "لینکش رو می‌ذارم توی QR، یا اگه عکس کوچیک باشه مستقیم جاسازیش "
            "می‌کنم). این دستور هیچ‌وقت محتوای یه QR موجود توی عکس رو "
            "نشون نمی‌ده — برای اون از <code>{prefix}اسکن</code> استفاده کن.\n\n"
            "بازه‌ی سایز: {min_size} تا {max_size} پیکسل (پیش‌فرض {default_size}px)."
        ),
    },
    "scan_usage": {
        "en": (
            "<b>QR &amp; Link Scanner</b>\n"
            "Reply to a photo/image containing one or more QR codes, or reply "
            "to a message that contains a link, then send "
            "<code>{prefix}scan</code> (Persian: <code>{prefix}اسکن</code>) "
            "to decode and analyze it."
        ),
        "fa": (
            "<b>اسکنر QR و لینک</b>\n"
            "روی یه عکس که QR کد داره، یا روی پیامی که لینک داره ریپلای کن و "
            "بعد <code>{prefix}اسکن</code> (English: <code>{prefix}scan</code>) "
            "رو بفرست تا براش تحلیل کامل بفرستم."
        ),
    },
    "status_generating": {
        "en": "🔄 Generating QR code…",
        "fa": "🔄 در حال ساخت کد QR…",
    },
    "status_scanning_image": {
        "en": "🔍 Downloading and scanning image…",
        "fa": "🔍 در حال دانلود و اسکن عکس…",
    },
    "status_analyzing": {
        "en": "🔗 Analyzing content…",
        "fa": "🔗 در حال تحلیل محتوا…",
    },
    "status_analyzing_link": {
        "en": "🔗 Analyzing link content…",
        "fa": "🔗 در حال تحلیل لینک…",
    },
    "content_too_long": {
        "en": "⚠️ Content is too long to encode (max {max_bytes} bytes).",
        "fa": "⚠️ این متن برای تبدیل به QR خیلی طولانیه (حداکثر {max_bytes} بایت).",
    },
    "image_too_large": {
        "en": "⚠️ Image is too large ({size}). Maximum supported size is {max_size}.",
        "fa": "⚠️ حجم عکس زیاده ({size}). حداکثر حجم مجاز {max_size} هست.",
    },
    "download_failed": {
        "en": "⚠️ Failed to download the image ({reason}).",
        "fa": "⚠️ دانلود عکس با خطا مواجه شد ({reason}).",
    },
    "download_failed_generic": {
        "en": "⚠️ Failed to download the image.",
        "fa": "⚠️ دانلود عکس ناموفق بود.",
    },
    "no_qr_found": {
        "en": "❌ No QR code was detected in this image.",
        "fa": "❌ هیچ کد QR ای توی این عکس پیدا نشد.",
    },
    "status_encoding_image_as_qr": {
        "en": "🔄 Encoding this image into a QR code…",
        "fa": "🔄 در حال تبدیل این عکس به کد QR…",
    },
    "status_upload_failed_fallback": {
        "en": "⚠️ Public upload failed ({detail}) — falling back to the local (more limited) method…",
        "fa": "⚠️ آپلود عمومی ناموفق بود ({detail}) — روش محلی (محدودتر) رو امتحان می‌کنم…",
    },
    "upload_failure_note": {
        "en": "<i>(Public upload attempt failed: {detail} — send this to your bot admin to diagnose.)</i>",
        "fa": "<i>(تلاش برای آپلود عمومی ناموفق بود: {detail} — همینو برای بررسی بفرست.)</i>",
    },
    "image_too_complex_for_qr": {
        "en": (
            "❌ This image can't be compressed small enough to fit in a QR "
            "code, even at minimum quality."
        ),
        "fa": (
            "❌ حتی با کمترین کیفیت هم نشد این عکس رو اونقدر کوچیک کرد که "
            "توی یه کد QR جا بشه."
        ),
    },
    "image_to_qr_link_caption": {
        "en": (
            "✅ Image uploaded &amp; embedded as a QR code\n"
            "Hosted on Catbox.moe (a free public file host): {url}\n"
            "Any phone camera or QR app can open this — since it's now "
            "public, anyone with the link (or who scans this code) can "
            "view the image."
        ),
        "fa": (
            "✅ عکس آپلود شد و توی QR جا گرفت\n"
            "میزبانی‌شده روی Catbox.moe (یه سرویس عمومی رایگان هاست فایل): {url}\n"
            "هر دوربین گوشی یا اپ QR می‌تونه بازش کنه — چون الان عمومیه، "
            "هرکسی این لینک رو داشته باشه (یا این کد رو اسکن کنه) عکس رو "
            "می‌بینه."
        ),
    },
    "image_to_qr_caption": {
        "en": (
            "✅ Image embedded directly in the QR code (as a data-URI)\n"
            "Public upload wasn't available, but this image was already "
            "small to begin with — not a shrunk-down copy of a larger "
            "photo — and fits in ~{size_kb}KB as-is. Note: many standard "
            "camera apps won't preview a data-URI QR; a dedicated "
            "QR-reader app is more likely to render it."
        ),
        "fa": (
            "✅ عکس مستقیم توی کد QR جاسازی شد (data-URI)\n"
            "آپلود عمومی در دسترس نبود، ولی این عکس از اول کوچیک بود — "
            "نسخه‌ی کوچیک‌شده‌ی یه عکس بزرگ‌تر نیست — و توی حدود "
            "{size_kb} کیلوبایت جا شد. توجه: خیلی از اپ‌های دوربین "
            "معمولی این نوع QR رو به‌صورت عکس نشون نمی‌دن؛ یه اپ "
            "QR-reader اختصاصی احتمال بیشتری داره نشونش بده."
        ),
    },
    "error_prefix": {
        "en": "❌ <b>Error:</b> {message}",
        "fa": "❌ <b>خطا:</b> {message}",
    },
    "qr_overflow": {
        "en": "This content is too large to encode in a single QR code.",
        "fa": "این متن برای یک کد QR خیلی زیاده.",
    },
    "qr_gen_failed": {
        "en": "Failed to generate QR code: {detail}",
        "fa": "ساخت کد QR ناموفق بود: {detail}",
    },
    "qr_decode_failed": {
        "en": "Could not read this image file ({detail}).",
        "fa": "نتونستم این فایل تصویری رو بخونم ({detail}).",
    },
    "type_url": {"en": "URL", "fa": "لینک (URL)"},
    "type_text": {"en": "Text", "fa": "متن"},
    "type_email": {"en": "Email", "fa": "ایمیل"},
    "type_tel": {"en": "Telephone", "fa": "شماره تلفن"},
    "type_sms": {"en": "SMS", "fa": "پیامک (SMS)"},
    "type_geo": {"en": "Geo Location", "fa": "موقعیت مکانی"},
    "type_wifi": {"en": "WiFi", "fa": "وای‌فای"},
    "type_vcard": {"en": "Contact (vCard)", "fa": "مخاطب (vCard)"},
    "type_bitcoin": {"en": "Bitcoin", "fa": "بیت‌کوین"},
    "type_event": {"en": "Event", "fa": "رویداد"},
    "type_unknown": {"en": "Unknown", "fa": "نامشخص"},
    "type_image": {"en": "Embedded Image", "fa": "عکس جاسازی‌شده"},
    "lbl_qr_num": {"en": "QR #{n}", "fa": "کد QR شماره {n}"},
    "lbl_type": {"en": "Type", "fa": "نوع"},
    "lbl_content": {"en": "Content", "fa": "محتوا"},
    "lbl_characters": {"en": "Characters", "fa": "تعداد کاراکتر"},
    "lbl_encoding": {"en": "Encoding", "fa": "کدگذاری"},
    "lbl_ssid": {"en": "SSID", "fa": "نام شبکه (SSID)"},
    "lbl_encryption": {"en": "Encryption", "fa": "نوع رمزنگاری"},
    "lbl_password": {"en": "Password", "fa": "رمز عبور"},
    "lbl_hidden": {"en": "Hidden", "fa": "مخفی"},
    "yes": {"en": "Yes", "fa": "بله"},
    "no": {"en": "No", "fa": "خیر"},
    "lbl_name": {"en": "Name", "fa": "نام"},
    "lbl_organization": {"en": "Organization", "fa": "سازمان"},
    "lbl_title": {"en": "Title", "fa": "عنوان"},
    "lbl_phone": {"en": "Phone", "fa": "تلفن"},
    "lbl_email": {"en": "Email", "fa": "ایمیل"},
    "lbl_address": {"en": "Address", "fa": "آدرس"},
    "lbl_website": {"en": "Website", "fa": "وبسایت"},
    "lbl_subject": {"en": "Subject", "fa": "موضوع"},
    "lbl_body": {"en": "Body", "fa": "متن پیام"},
    "lbl_number": {"en": "Number", "fa": "شماره"},
    "lbl_message": {"en": "Message", "fa": "پیام"},
    "lbl_latitude": {"en": "Latitude", "fa": "عرض جغرافیایی"},
    "lbl_longitude": {"en": "Longitude", "fa": "طول جغرافیایی"},
    "lbl_altitude": {"en": "Altitude", "fa": "ارتفاع"},
    "lbl_map": {"en": "Map", "fa": "نقشه"},
    "lbl_amount": {"en": "Amount", "fa": "مبلغ"},
    "lbl_label": {"en": "Label", "fa": "برچسب"},
    "lbl_summary": {"en": "Summary", "fa": "خلاصه"},
    "lbl_start": {"en": "Start", "fa": "شروع"},
    "lbl_end": {"en": "End", "fa": "پایان"},
    "lbl_location": {"en": "Location", "fa": "مکان"},
    "lbl_description": {"en": "Description", "fa": "توضیحات"},
    "lbl_analysis_header": {"en": "— QR Analysis —", "fa": "— تحلیل لینک —"},
    "lbl_protocol": {"en": "Protocol", "fa": "پروتکل"},
    "lbl_domain": {"en": "Domain", "fa": "دامنه"},
    "lbl_status": {"en": "Status", "fa": "وضعیت"},
    "lbl_http_status": {"en": "HTTP Status", "fa": "وضعیت HTTP"},
    "lbl_redirects": {"en": "Redirects", "fa": "ریدایرکت‌ها"},
    "lbl_final_url": {"en": "Final URL", "fa": "لینک نهایی"},
    "lbl_content_type": {"en": "Content-Type", "fa": "نوع محتوا"},
    "lbl_content_length": {"en": "Content-Length", "fa": "حجم محتوا"},
    "lbl_downloadable": {"en": "Downloadable File", "fa": "فایل قابل دانلود"},
    "lbl_filename": {"en": "Filename", "fa": "نام فایل"},
    "lbl_observations": {"en": "Observations", "fa": "نکات قابل توجه"},
    "scan_header": {
        "en": "🔍 QR Scan Complete — {count} code{plural} found",
        "fa": "🔍 اسکن انجام شد — {count} کد پیدا شد",
    },
    "scan_header_truncated": {
        "en": " (showing first {n})",
        "fa": " (فقط {n} مورد اول نمایش داده شد)",
    },
    "lbl_qr_generated": {"en": "✅ QR Code Generated", "fa": "✅ کد QR ساخته شد"},
    "lbl_size": {"en": "Size", "fa": "سایز"},
    "lbl_format": {"en": "Format", "fa": "فرمت"},
    "image_content_placeholder": {
        "en": "(embedded image — sent as a photo below)",
        "fa": "(عکس جاسازی‌شده — پایین‌تر به‌صورت عکس فرستاده می‌شه)",
    },
    "embedded_image_note": {
        "en": "🖼 The reconstructed image is sent as a separate photo below.",
        "fa": "🖼 خودِ عکسِ بازسازی‌شده رو جدا، پایین‌تر به‌صورت عکس می‌فرستم.",
    },
    "linked_image_note": {
        "en": "🖼 This links directly to an image — the original is sent as a separate photo below, at full quality.",
        "fa": "🖼 این لینک مستقیماً به یه عکس اشاره می‌کنه — خودِ تصویر اصلی رو با کیفیت کامل، جدا پایین‌تر می‌فرستم.",
    },
    "embedded_image_caption": {
        "en": "🖼 QR #{n} — reconstructed embedded image",
        "fa": "🖼 کد QR شماره {n} — عکس جاسازی‌شده‌ی بازسازی‌شده",
    },
    "linked_image_caption": {
        "en": "🖼 QR #{n} — original image at full quality",
        "fa": "🖼 کد QR شماره {n} — تصویر اصلی با کیفیت کامل",
    },
    "obs_https": {"en": "Uses HTTPS", "fa": "از HTTPS استفاده می‌کنه"},
    "obs_http": {"en": "Plain HTTP (unencrypted)", "fa": "HTTP ساده (رمزنگاری‌نشده)"},
    "obs_redirect": {
        "en": "Redirect detected ({count} {hop_word})",
        "fa": "ریدایرکت پیدا شد ({count} مرحله)",
    },
    "obs_long_url": {"en": "Very long URL", "fa": "لینک خیلی طولانیه"},
    "obs_ip_address": {
        "en": "IP address used instead of a domain name",
        "fa": "به‌جای دامنه، از آدرس IP استفاده شده",
    },
    "obs_shortener": {
        "en": "Known URL shortener",
        "fa": "کوتاه‌کننده‌ی لینک شناخته‌شده",
    },
    "obs_suspicious_ext": {
        "en": "Suspicious file extension ({ext})",
        "fa": "پسوند فایل مشکوک ({ext})",
    },
    "obs_at_symbol": {
        "en": "Contains '@' in the URL (possible masking)",
        "fa": "توی لینک علامت '@' هست (احتمال مخفی‌کاری مقصد)",
    },
    "obs_nonstandard_port": {
        "en": "Non-standard port ({port})",
        "fa": "پورت غیرمعمول ({port})",
    },
    "obs_none": {"en": "No notable indicators", "fa": "نکته‌ی خاصی مشاهده نشد"},
    "err_not_fetchable": {
        "en": "Not a fetchable HTTP(S) link.",
        "fa": "این یک لینک قابل‌بررسی HTTP(S) نیست.",
    },
    "err_blocked_private": {
        "en": "Blocked: this host resolves to a private/internal address ({ip}). If this is a well-known public site, your network's DNS may be intercepting/filtering it.",
        "fa": "مسدود شد: این آدرس به یک شبکه‌ی داخلی/خصوصی اشاره می‌کنه ({ip}). اگه این یه سایت عمومی و شناخته‌شده‌ست، احتمالاً DNS شبکه‌ت داره فیلترش می‌کنه.",
    },
    "err_timeout": {
        "en": "Request timed out.",
        "fa": "درخواست به دلیل تایم‌اوت انجام نشد.",
    },
    "err_too_many_redirects": {
        "en": "Too many redirects.",
        "fa": "تعداد ریدایرکت‌ها بیش از حد مجاز بود.",
    },
    "err_connect_failed": {
        "en": "Could not connect to the host.",
        "fa": "اتصال به سرور برقرار نشد.",
    },
    "err_network": {
        "en": "Network error: {detail}",
        "fa": "خطای شبکه: {detail}",
    },
    "err_unexpected": {
        "en": "Unexpected error while fetching the URL.",
        "fa": "هنگام دریافت لینک خطای غیرمنتظره‌ای رخ داد.",
    },
    "svc_youtube": {"en": "YouTube", "fa": "یوتیوب"},
    "svc_instagram": {"en": "Instagram", "fa": "اینستاگرام"},
    "svc_tiktok": {"en": "TikTok", "fa": "تیک‌تاک"},
    "svc_twitter": {"en": "Twitter/X", "fa": "توییتر/ایکس"},
    "svc_telegram": {"en": "Telegram", "fa": "تلگرام"},
    "svc_github": {"en": "GitHub", "fa": "گیت‌هاب"},
    "svc_generic": {"en": "Website", "fa": "وبسایت"},
    "svc_shorts_suffix": {"en": "(Shorts)", "fa": "(شورتز)"},
    "lbl_service": {"en": "Service", "fa": "سرویس"},
    "lbl_author": {"en": "By", "fa": "توسط"},
    "lbl_repo_stats": {"en": "Repo Stats", "fa": "آمار مخزن"},
    "lbl_thumbnail": {"en": "Thumbnail", "fa": "بندانگشتی"},
    "lbl_redirect_path": {"en": "Redirect Path", "fa": "مسیر ریدایرکت"},
    "obs_redirect_multi_domain": {
        "en": "Redirect chain crosses multiple different domains",
        "fa": "زنجیره‌ی ریدایرکت از چند دامنه‌ی مختلف رد می‌شه",
    },
    "image_upload_failed_and_too_large": {
        "en": (
            "❌ Couldn't upload this image publicly ({detail}), and it's too "
            "large/high-resolution to embed directly in a QR code without "
            "destroying its quality. Please try again later, or send a "
            "smaller image."
        ),
        "fa": (
            "❌ نشد این عکس رو به‌صورت عمومی آپلود کنم ({detail})، و برای "
            "جاسازی مستقیم توی QR هم خیلی بزرگ/باکیفیته — این کار کیفیتشو "
            "نابود می‌کنه. لطفاً بعداً دوباره امتحان کن یا یه عکس کوچیک‌تر بفرست."
        ),
    },
    "image_emergency_embed_caption": {
        "en": (
            "⚠️ Embedded as a heavily compressed last-resort thumbnail (~{size_kb}KB)\n"
            "Public upload failed AND this image is too large for a "
            "faithful embed, so quality here is genuinely low — this is "
            "not the original. Fix the upload connectivity (see below) "
            "and try again for full quality."
        ),
        "fa": (
            "⚠️ به‌صورت یه بندانگشتیِ خیلی فشرده و آخرین‌راه‌حل جاسازی شد (~{size_kb} کیلوبایت)\n"
            "آپلود عمومی شکست خورد و این عکس هم برای جاسازیِ باکیفیت خیلی "
            "بزرگه، پس کیفیتِ اینجا واقعاً پایینه — این خودِ عکس اصلی نیست. "
            "برای کیفیت کامل، مشکل اتصال آپلود رو حل کن (پایین‌تر) و دوباره امتحان کن."
        ),
    },
}


def t(key: str, lang: str, **kwargs: Any) -> str:
    """Resolve a translation key to display text, formatting with kwargs.

    Falls back to English if the key exists but not for `lang`, and to the
    raw key itself if the key is entirely unknown (so a typo never crashes
    a handler, it just surfaces an ugly-but-harmless string)."""
    entry = _STRINGS.get(key)
    if not entry:
        return key
    template = entry.get(lang) or entry.get("en") or key
    if not kwargs:
        return template
    try:
        return template.format(**kwargs)
    except (KeyError, IndexError):
        return template


def _detect_lang(matched_word: str) -> str:
    """Infer the reply language from which command alias the user typed."""
    return "fa" if matched_word and not matched_word.isascii() else "en"


# --------------------------------------------------------------------------
# Small generic helpers
# --------------------------------------------------------------------------

def esc(value: Any) -> str:
    """HTML-escape a value for safe inclusion in a Telegram HTML message."""
    return html.escape(str(value), quote=False)


def _truncate(text: str, limit: int) -> str:
    """Shorten text to at most `limit` characters, appending an ellipsis."""
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)] + "…"


def _human_size(num_bytes: int) -> str:
    """Format a byte count as a short human-readable string."""
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{num_bytes} B"


# --------------------------------------------------------------------------
# Enums
# --------------------------------------------------------------------------

class QRType(str, Enum):
    """Recognized QR code content categories."""

    URL = "URL"
    TEXT = "Text"
    EMAIL = "Email"
    TEL = "Telephone"
    SMS = "SMS"
    GEO = "Geo Location"
    WIFI = "WiFi"
    VCARD = "Contact (vCard)"
    BITCOIN = "Bitcoin"
    EVENT = "Event"
    IMAGE = "Embedded Image"
    UNKNOWN = "Unknown"


class ServiceType(Enum):
    """A recognized web service, detected from a URL's hostname, used to
    pick a richer/more reliable metadata-fetch strategy than generic HTML
    scraping (see `_detect_service` and `_SERVICE_METADATA_FETCHERS`)."""

    YOUTUBE = "youtube"
    INSTAGRAM = "instagram"
    TIKTOK = "tiktok"
    TWITTER = "twitter"
    TELEGRAM = "telegram"
    GITHUB = "github"
    GENERIC = "generic"


class ObservationLevel(Enum):
    """Severity level for a risk/observation entry (informational only)."""

    GOOD = "good"
    WARNING = "warning"
    NEUTRAL = "neutral"


_OBSERVATION_SYMBOLS: dict[ObservationLevel, str] = {
    ObservationLevel.GOOD: "✓",
    ObservationLevel.WARNING: "⚠",
    ObservationLevel.NEUTRAL: "ℹ",
}

_QRTYPE_KEYS: dict[QRType, str] = {
    QRType.URL: "type_url",
    QRType.TEXT: "type_text",
    QRType.EMAIL: "type_email",
    QRType.TEL: "type_tel",
    QRType.SMS: "type_sms",
    QRType.GEO: "type_geo",
    QRType.WIFI: "type_wifi",
    QRType.VCARD: "type_vcard",
    QRType.BITCOIN: "type_bitcoin",
    QRType.EVENT: "type_event",
    QRType.IMAGE: "type_image",
    QRType.UNKNOWN: "type_unknown",
}


def _qtype_label(qtype: QRType, lang: str) -> str:
    return t(_QRTYPE_KEYS.get(qtype, "type_unknown"), lang)


_SERVICE_KEYS: dict[ServiceType, str] = {
    ServiceType.YOUTUBE: "svc_youtube",
    ServiceType.INSTAGRAM: "svc_instagram",
    ServiceType.TIKTOK: "svc_tiktok",
    ServiceType.TWITTER: "svc_twitter",
    ServiceType.TELEGRAM: "svc_telegram",
    ServiceType.GITHUB: "svc_github",
    ServiceType.GENERIC: "svc_generic",
}


def _service_label(analysis: "URLAnalysis", lang: str) -> str:
    label = t(_SERVICE_KEYS.get(analysis.service, "svc_generic"), lang)
    if analysis.service == ServiceType.YOUTUBE and analysis.extra.get("is_short"):
        label = f"{label} {t('svc_shorts_suffix', lang)}"
    return label


# --------------------------------------------------------------------------
# Exceptions
# --------------------------------------------------------------------------

class QRGenerationError(Exception):
    """Raised when a QR code image cannot be generated. Carries a
    translation `key` (+ `params`) so handlers can localize the message;
    `str(exc)` still gives a sensible English fallback for logs."""

    def __init__(self, message: str, key: str = "qr_gen_failed", **params: Any) -> None:
        super().__init__(message)
        self.key = key
        self.params = params


class QRDecodeError(Exception):
    """Raised when an uploaded image cannot be read/decoded at all. Carries
    a translation `key` (+ `params`) so handlers can localize the message."""

    def __init__(self, message: str, key: str = "qr_decode_failed", **params: Any) -> None:
        super().__init__(message)
        self.key = key
        self.params = params


# --------------------------------------------------------------------------
# Data classes
# --------------------------------------------------------------------------

@dataclass(slots=True)
class Observation:
    """A single informational observation about a URL (stored as a
    translation key + params so it can be rendered in any language)."""

    key: str
    level: ObservationLevel
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DecodedQR:
    """Raw bytes decoded from one QR code found in an image."""

    data: bytes


@dataclass(slots=True)
class URLAnalysis:
    """Publicly available metadata gathered about a URL."""

    url: str
    domain: str
    protocol: str
    final_url: str
    redirect_count: int = 0
    redirect_chain: list[str] = field(default_factory=list)
    status_code: int | None = None
    content_type: str | None = None
    content_length: int | None = None
    title: str | None = None
    description: str | None = None
    author: str | None = None
    service: ServiceType = ServiceType.GENERIC
    extra: dict[str, Any] = field(default_factory=dict)
    is_downloadable_file: bool = False
    is_image_file: bool = False
    image_bytes: bytes | None = None
    filename: str | None = None
    observations: list[Observation] = field(default_factory=list)
    error: str | None = None
    error_params: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class QRResult:
    """Fully processed result for a single decoded QR code."""

    index: int
    qr_type: QRType
    raw_content: str
    char_count: int
    encoding: str
    parsed: dict[str, Any] = field(default_factory=dict)
    url_analysis: URLAnalysis | None = None


# --------------------------------------------------------------------------
# QR type detection
# --------------------------------------------------------------------------

def _looks_like_btc_address(text: str) -> bool:
    return bool(_BTC_LEGACY_PATTERN.match(text) or _BTC_BECH32_PATTERN.match(text))


def detect_qr_type(content: str) -> QRType:
    """Classify raw QR code text into one of the supported QRType categories."""
    text = content.strip()
    lower = text.lower()

    if not text:
        return QRType.UNKNOWN
    if lower.startswith("data:image/") and ";base64," in lower:
        return QRType.IMAGE
    if lower.startswith("wifi:"):
        return QRType.WIFI
    if lower.startswith("begin:vcard"):
        return QRType.VCARD
    if lower.startswith("begin:vevent") or lower.startswith("begin:vcalendar"):
        return QRType.EVENT
    if lower.startswith("bitcoin:"):
        return QRType.BITCOIN
    if lower.startswith("mailto:"):
        return QRType.EMAIL
    if lower.startswith("smsto:") or lower.startswith("sms:"):
        return QRType.SMS
    if lower.startswith("tel:"):
        return QRType.TEL
    if lower.startswith("geo:"):
        return QRType.GEO
    if lower.startswith("http://") or lower.startswith("https://"):
        return QRType.URL
    if _WWW_PATTERN.match(text):
        return QRType.URL
    if _looks_like_btc_address(text):
        return QRType.BITCOIN
    if _EMAIL_PATTERN.match(text):
        return QRType.EMAIL
    if _PHONE_PATTERN.match(text) and any(ch.isdigit() for ch in text):
        return QRType.TEL
    return QRType.TEXT


# --------------------------------------------------------------------------
# Per-type content parsing
# --------------------------------------------------------------------------

def _parse_wifi(text: str) -> dict[str, Any]:
    body = text[5:] if text.lower().startswith("wifi:") else text
    fields: dict[str, str] = {}
    for match in _WIFI_FIELD_PATTERN.finditer(body):
        key = match.group(1).upper()
        value = re.sub(r"\\(.)", r"\1", match.group(2))
        fields[key] = value

    encryption_map = {
        "WPA": "WPA/WPA2",
        "WPA2": "WPA/WPA2",
        "WPA3": "WPA3",
        "WEP": "WEP",
        "NOPASS": "Open (no password)",
        "": "Unknown",
    }
    enc_raw = fields.get("T", "").upper()
    return {
        "ssid": fields.get("S", ""),
        "encryption": encryption_map.get(enc_raw, enc_raw or "Unknown"),
        "password": fields.get("P", ""),
        "hidden": fields.get("H", "false").strip().lower() == "true",
    }


def _parse_vcard(text: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    phones: list[str] = []
    emails: list[str] = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or ":" not in line:
            continue
        key_part, _, value = line.partition(":")
        key = key_part.split(";")[0].upper()
        value = value.strip()

        if key == "FN":
            result["name"] = value
        elif key == "N" and "name" not in result:
            result["name"] = value.replace(";", " ").strip()
        elif key == "TEL":
            phones.append(value)
        elif key == "EMAIL":
            emails.append(value)
        elif key == "ORG":
            result["organization"] = value
        elif key == "TITLE":
            result["title"] = value
        elif key == "ADR":
            result["address"] = value.replace(";", ", ").strip(", ")
        elif key == "URL":
            result["url"] = value

    if phones:
        result["phones"] = phones
    if emails:
        result["emails"] = emails
    return result


def _parse_bitcoin(text: str) -> dict[str, Any]:
    body = text[8:] if text.lower().startswith("bitcoin:") else text
    address, _, query = body.partition("?")
    result: dict[str, Any] = {"address": address.strip()}
    if query:
        params = dict(parse_qsl(query))
        for key in ("amount", "label", "message"):
            if key in params:
                result[key] = params[key]
    return result


def _parse_geo(text: str) -> dict[str, Any]:
    body = text[4:] if text.lower().startswith("geo:") else text
    coords, _, _query = body.partition("?")
    parts = [p.strip() for p in coords.split(",")]
    result: dict[str, Any] = {}
    if len(parts) >= 1 and parts[0]:
        result["latitude"] = parts[0]
    if len(parts) >= 2 and parts[1]:
        result["longitude"] = parts[1]
    if len(parts) >= 3 and parts[2]:
        result["altitude"] = parts[2]
    return result


def _parse_mailto(text: str) -> dict[str, Any]:
    body = text[7:] if text.lower().startswith("mailto:") else text
    address, _, query = body.partition("?")
    result: dict[str, Any] = {"email": address.strip()}
    if query:
        params = dict(parse_qsl(query))
        if "subject" in params:
            result["subject"] = params["subject"]
        if "body" in params:
            result["body"] = params["body"]
        if "cc" in params:
            result["cc"] = params["cc"]
    return result


def _parse_tel(text: str) -> dict[str, Any]:
    body = text
    if body.lower().startswith("tel:"):
        body = body[4:]
    return {"number": body.strip()}


def _parse_sms(text: str) -> dict[str, Any]:
    body = text
    for prefix in ("smsto:", "sms:"):
        if body.lower().startswith(prefix):
            body = body[len(prefix):]
            break

    if "?" in body:
        number, _, query = body.partition("?")
        params = dict(parse_qsl(query))
        message = params.get("body", "")
    elif ":" in body:
        number, _, message = body.partition(":")
    else:
        number, message = body, ""

    return {"number": number.strip(), "message": message.strip()}


def _parse_event(text: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or ":" not in line:
            continue
        key_part, _, value = line.partition(":")
        key = key_part.split(";")[0].upper()
        value = value.strip()
        if key == "SUMMARY":
            result["summary"] = value
        elif key == "DTSTART":
            result["start"] = value
        elif key == "DTEND":
            result["end"] = value
        elif key == "LOCATION":
            result["location"] = value
        elif key == "DESCRIPTION":
            result["description"] = value
    return result


def _decode_data_image_bytes(text: str) -> bytes | None:
    """Decode a `data:image/...;base64,...` URI back into raw image bytes,
    or None if it doesn't match / doesn't decode. Kept separate from
    `_parse_data_image` (which is for display fields only) so the
    orchestration layer can fetch the actual bytes without re-parsing."""
    match = _DATA_IMAGE_URI_PATTERN.match(text.strip())
    if not match:
        return None
    try:
        return base64.b64decode(match.group("payload"), validate=False)
    except Exception:
        return None


def _parse_data_image(text: str) -> dict[str, Any]:
    match = _DATA_IMAGE_URI_PATTERN.match(text.strip())
    if not match:
        return {}
    result: dict[str, Any] = {"mime_subtype": match.group("subtype").upper()}
    raw_bytes = _decode_data_image_bytes(text)
    if raw_bytes is not None:
        result["byte_size"] = len(raw_bytes)
    return result


_CONTENT_PARSERS: dict[QRType, Callable[[str], dict[str, Any]]] = {
    QRType.WIFI: _parse_wifi,
    QRType.VCARD: _parse_vcard,
    QRType.BITCOIN: _parse_bitcoin,
    QRType.GEO: _parse_geo,
    QRType.EMAIL: _parse_mailto,
    QRType.TEL: _parse_tel,
    QRType.SMS: _parse_sms,
    QRType.EVENT: _parse_event,
    QRType.IMAGE: _parse_data_image,
}


def _parse_content(qtype: QRType, text: str) -> dict[str, Any]:
    parser = _CONTENT_PARSERS.get(qtype)
    if parser is None:
        return {}
    try:
        return parser(text)
    except Exception:
        logger.debug("Failed to parse %s content", qtype, exc_info=True)
        return {}


# --------------------------------------------------------------------------
# Image decoding
# --------------------------------------------------------------------------

def _decode_bytes(data: bytes) -> tuple[str, str]:
    """Decode raw QR bytes into text, returning (text, encoding_name)."""
    try:
        return data.decode("utf-8"), "UTF-8"
    except UnicodeDecodeError:
        pass
    try:
        return data.decode("iso-8859-1"), "ISO-8859-1"
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace"), "UNKNOWN"


def _scale_to_dimension(image: Image.Image, target: int, *, upscale: bool) -> Image.Image:
    """Resize `image` (preserving aspect ratio) so its longest side hits
    `target` -- shrinking if it's currently bigger (upscale=False) or
    growing if it's currently smaller (upscale=True). No-op otherwise."""
    largest = max(image.size)
    if (upscale and largest >= target) or (not upscale and largest <= target):
        return image
    factor = target / largest
    new_size = (max(1, int(image.width * factor)), max(1, int(image.height * factor)))
    return image.resize(new_size, Image.LANCZOS)


def _decode_qr_codes(image_bytes: bytes) -> list[DecodedQR]:
    """Decode every QR code in an image. Synchronous; call via a thread."""
    if not HAS_PYZBAR and not HAS_CV2:
        raise QRDecodeError(
            "No QR decode backend is installed (need pyzbar and/or OpenCV).",
            key="qr_decode_failed",
            detail="no decode backend installed",
        )

    try:
        image = Image.open(io.BytesIO(image_bytes))
        image.load()
        image = ImageOps.exif_transpose(image) or image
        if image.mode not in ("RGB", "L"):
            image = image.convert("RGB")
    except Exception as exc:
        raise QRDecodeError(
            f"Could not read this image file ({exc.__class__.__name__}).",
            key="qr_decode_failed",
            detail=exc.__class__.__name__,
        ) from exc

    # Downscale oversized photos (a modern phone camera easily produces
    # 4000px+ images) before running either decoder -- QR finder patterns
    # don't need native resolution to be detected, and this keeps CPU/RAM
    # bounded on a small VPS regardless of how large the source photo was.
    image = _scale_to_dimension(image, SCAN_MAX_DIMENSION, upscale=False)

    seen: set[bytes] = set()
    results: list[DecodedQR] = []

    if HAS_PYZBAR:
        try:
            for obj in _pyzbar_decode_qr(image):
                if obj.data and obj.data not in seen:
                    seen.add(obj.data)
                    results.append(DecodedQR(data=obj.data))
        except Exception:
            logger.debug("pyzbar decoding pass failed", exc_info=True)

    if HAS_CV2:
        try:
            cv_image = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)
            detector = cv2.QRCodeDetector()
            ok, decoded_texts, _points, _straight = detector.detectAndDecodeMulti(cv_image)
            if ok:
                for text in decoded_texts:
                    if not text:
                        continue
                    data = text.encode("utf-8")
                    if data not in seen:
                        seen.add(data)
                        results.append(DecodedQR(data=data))
        except Exception:
            logger.debug("OpenCV decoding pass failed", exc_info=True)

    if not results and HAS_PYZBAR:
        try:
            gray = _scale_to_dimension(image.convert("L"), MIN_UPSCALE_DIMENSION, upscale=True)
            for obj in _pyzbar_decode_qr(gray):
                if obj.data and obj.data not in seen:
                    seen.add(obj.data)
                    results.append(DecodedQR(data=obj.data))
        except Exception:
            logger.debug("Enhanced decoding pass failed", exc_info=True)

    return results


def _pyzbar_decode_qr(image: Image.Image) -> list[Any]:
    """Call pyzbar for QR codes, tolerating pyzbar builds whose `decode()`
    does not accept the `symbols` keyword argument (older/newer releases
    have differed here). Falls back to decoding all symbologies and
    filtering to QR codes manually if the keyword is rejected."""
    try:
        return list(pyzbar_decode(image, symbols=[ZBarSymbol.QRCODE]))
    except TypeError:
        logger.debug("pyzbar rejected 'symbols' kwarg; retrying without it", exc_info=True)
        return [obj for obj in pyzbar_decode(image) if obj.type == "QRCODE"]


# --------------------------------------------------------------------------
# URL safety & metadata analysis
# --------------------------------------------------------------------------

def _find_urls_in_text(text: str) -> list[str]:
    """Extract unique, plausible URLs from free-form message text."""
    if not text:
        return []
    found = _URL_FINDER_PATTERN.findall(text)
    seen: set[str] = set()
    unique: list[str] = []
    for url in found:
        cleaned = url.rstrip(").,;!?\u200c")
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            unique.append(cleaned)
    return unique[:MAX_QR_CODES_PER_IMAGE]


def _is_ip_literal(host: str) -> bool:
    if not host:
        return False
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _is_public_ip(ip_str: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return not (
        ip_obj.is_private
        or ip_obj.is_loopback
        or ip_obj.is_link_local
        or ip_obj.is_reserved
        or ip_obj.is_multicast
        or ip_obj.is_unspecified
    )


# The AWS/GCP/Azure/etc. instance-metadata endpoint -- the single most
# dangerous SSRF target there is, since it can expose cloud credentials.
# A legitimate public website's DNS has no legitimate reason to ever
# include this address, so its mere presence is blocked outright,
# independent of the public/private majority check below.
_CLOUD_METADATA_IPS = frozenset({"169.254.169.254", "fd00:ec2::254"})


DOH_RESOLVER_URL = "https://cloudflare-dns.com/dns-query"


async def _doh_resolve(hostname: str, http_client: httpx.AsyncClient) -> list[str]:
    """Resolve a hostname via DNS-over-HTTPS (Cloudflare) instead of the
    system resolver. Only ever used as a fallback inside `_is_safe_host`,
    after the local resolver has already come back with no public address
    -- some networks intercept/filter plain DNS for specific domains or
    content categories and substitute a bogus (often private-looking)
    address, which a local-only check has no way to see past. A DoH
    lookup is a plain HTTPS request to a public resolver, so it isn't
    subject to that same local interception."""
    ips: list[str] = []
    for record_type in ("A", "AAAA"):
        try:
            resp = await http_client.get(
                DOH_RESOLVER_URL,
                params={"name": hostname, "type": record_type},
                headers={"Accept": "application/dns-json"},
                timeout=5.0,
            )
            resp.raise_for_status()
            for answer in resp.json().get("Answer", []):
                if answer.get("type") in (1, 28) and answer.get("data"):  # A / AAAA
                    ips.append(answer["data"])
        except Exception:
            logger.debug("DoH resolution failed for %s (%s)", hostname, record_type, exc_info=True)
    return ips


async def _is_safe_host(hostname: str, http_client: httpx.AsyncClient) -> tuple[bool, list[str]]:
    """Reject hosts that are entirely private/loopback/reserved, or that
    resolve to a cloud instance-metadata address at all. Returns
    (is_safe, resolved_ips) -- the IPs are returned even on failure so
    the caller can show *what* was resolved instead of just "blocked",
    which matters here since a filtered/interfering network substituting
    a bogus address looks identical to a real SSRF attempt from the
    inside; showing the IP lets a human tell the two apart.

    Large, genuinely multi-homed services (major CDNs, dual-stack
    platforms) can have a getaddrinfo() result many entries long, so this
    only requires *at least one* public address rather than *all* of
    them -- a real SSRF attempt realistically points a domain entirely at
    the internal target, since mixing in a decoy public address only
    hurts an attacker's reliability."""
    if not hostname:
        return False, []

    if _is_ip_literal(hostname):
        safe = hostname not in _CLOUD_METADATA_IPS and _is_public_ip(hostname)
        return safe, [hostname]

    try:
        loop = asyncio.get_running_loop()
        infos = await asyncio.wait_for(
            loop.getaddrinfo(hostname, None), timeout=DNS_RESOLVE_TIMEOUT
        )
        resolved_ips = [info[4][0] for info in infos]
    except Exception:
        logger.debug("DNS resolution failed for host: %s", hostname, exc_info=True)
        resolved_ips = []

    if any(ip in _CLOUD_METADATA_IPS for ip in resolved_ips):
        return False, resolved_ips
    if any(_is_public_ip(ip) for ip in resolved_ips):
        return True, resolved_ips

    doh_ips = await _doh_resolve(hostname, http_client)
    if doh_ips:
        if any(ip in _CLOUD_METADATA_IPS for ip in doh_ips):
            return False, doh_ips
        if any(_is_public_ip(ip) for ip in doh_ips):
            return True, doh_ips
        resolved_ips = doh_ips or resolved_ips

    return False, resolved_ips


# If this bot's network can't reach Catbox/0x0.st/etc. directly -- common
# in countries or on providers that filter/block these specific hosts at
# the DNS or connection level, which the repeated inconsistent failures
# here (HTTP 412 from Catbox, alternating 503/connection-refused from
# 0x0.st, DNS resolution failures for envs.sh) are consistent with -- set
# a proxy for this process and every client below will route through it
# automatically: either the standard HTTP_PROXY/HTTPS_PROXY/ALL_PROXY
# environment variables (httpx honors these by default), or QR_PROXY
# specifically for just this module, e.g.:
#     export QR_PROXY="socks5://127.0.0.1:1080"
#     export QR_PROXY="http://127.0.0.1:8080"
PROXY_URL = os.environ.get("QR_PROXY") or None


def _build_http_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=HTTP_TIMEOUT,
        follow_redirects=True,
        max_redirects=MAX_REDIRECTS,
        proxy=PROXY_URL,
        headers={
            "User-Agent": USER_AGENT,
            # Without this, Google/YouTube properties often redirect
            # cookie-less requests to an EU consent-wall page instead of
            # the real content, so title/description extraction gets
            # nothing useful. This is the same cookie clicking "I agree"
            # sets -- it isn't bypassing any real access control, just
            # skipping the interactive banner for an automated reader.
            "Cookie": "CONSENT=YES+cb",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )


def _build_upload_http_client() -> httpx.AsyncClient:
    """A separate, header-free client for image uploads (Catbox/0x0.st).
    httpx merges a client's default headers into every request unless a
    per-call header overrides that exact key -- so sharing _build_http_client
    (whose defaults include a YouTube-specific consent Cookie and a pinned
    Accept-Language meant only for scraping) would silently attach those to
    upload requests too. Each uploader below already sets its own complete,
    purpose-built headers per call; this client just avoids contaminating
    them with unrelated defaults that could look suspicious to the host."""
    return httpx.AsyncClient(timeout=UPLOAD_TIMEOUT, follow_redirects=True, proxy=PROXY_URL)


def _extract_filename(disposition: str) -> str | None:
    if not disposition:
        return None
    match = _FILENAME_PATTERN.search(disposition)
    if not match:
        return None
    return unquote(match.group(1).strip())


def _parse_html_metadata(body: bytes) -> tuple[str | None, str | None]:
    try:
        soup = BeautifulSoup(body, "html.parser")

        title: str | None = None
        if soup.title:
            title_text = soup.title.get_text(strip=True)
            title = title_text or None

        description: str | None = None
        meta_desc = soup.find("meta", attrs={"name": _DESCRIPTION_META_PATTERN})
        if meta_desc and meta_desc.get("content"):
            description = meta_desc["content"].strip()
        else:
            meta_og = soup.find("meta", attrs={"property": _OG_DESCRIPTION_META_PATTERN})
            if meta_og and meta_og.get("content"):
                description = meta_og["content"].strip()

        if title:
            title = _truncate(title, 200)
        if description:
            description = _truncate(description, 300)

        return title, description
    except Exception:
        logger.debug("Failed to parse HTML metadata", exc_info=True)
        return None, None


def _extract_extension(path_or_name: str | None) -> str:
    if not path_or_name:
        return ""
    tail = path_or_name.rsplit("/", 1)[-1]
    if "." not in tail:
        return ""
    return "." + tail.rsplit(".", 1)[-1].lower()


def _build_observations(analysis: URLAnalysis, parsed: ParseResult) -> list[Observation]:
    obs: list[Observation] = []
    scheme = parsed.scheme.lower()

    if scheme == "https":
        obs.append(Observation("obs_https", ObservationLevel.GOOD))
    elif scheme == "http":
        obs.append(Observation("obs_http", ObservationLevel.WARNING))

    if analysis.redirect_count > 0:
        hop_word = "hop" if analysis.redirect_count == 1 else "hops"
        obs.append(Observation(
            "obs_redirect",
            ObservationLevel.WARNING,
            {"count": analysis.redirect_count, "hop_word": hop_word},
        ))
        distinct_hosts = {h for h in analysis.redirect_chain if h}
        if len(distinct_hosts) > 2:
            obs.append(Observation("obs_redirect_multi_domain", ObservationLevel.WARNING))

    if len(analysis.url) > LONG_URL_THRESHOLD:
        obs.append(Observation("obs_long_url", ObservationLevel.WARNING))

    if _is_ip_literal(analysis.domain):
        obs.append(Observation("obs_ip_address", ObservationLevel.WARNING))

    if analysis.domain.lower() in KNOWN_SHORTENERS:
        obs.append(Observation("obs_shortener", ObservationLevel.WARNING))

    ext = _extract_extension(analysis.filename or parsed.path)
    if ext in SUSPICIOUS_EXTENSIONS:
        obs.append(Observation("obs_suspicious_ext", ObservationLevel.WARNING, {"ext": ext}))

    if parsed.username or parsed.password or "@" in parsed.netloc:
        obs.append(Observation("obs_at_symbol", ObservationLevel.WARNING))

    try:
        port = parsed.port
    except ValueError:
        port = None
    if port and port not in (80, 443):
        obs.append(Observation("obs_nonstandard_port", ObservationLevel.NEUTRAL, {"port": port}))

    if not obs:
        obs.append(Observation("obs_none", ObservationLevel.NEUTRAL))

    return obs


def _strip_www(host: str) -> str:
    host = (host or "").lower()
    return host[4:] if host.startswith("www.") else host


def _detect_service(parsed: ParseResult) -> ServiceType:
    """Classify a URL's hostname into a known service, if any."""
    host = _strip_www(parsed.hostname or "")
    if host in YOUTUBE_HOSTS or host in YOUTU_BE_HOSTS:
        return ServiceType.YOUTUBE
    if host in INSTAGRAM_HOSTS:
        return ServiceType.INSTAGRAM
    if host in TIKTOK_HOSTS:
        return ServiceType.TIKTOK
    if host in TWITTER_HOSTS:
        return ServiceType.TWITTER
    if host in TELEGRAM_HOSTS:
        return ServiceType.TELEGRAM
    if host in GITHUB_HOSTS:
        return ServiceType.GITHUB
    return ServiceType.GENERIC


def _extract_youtube_id(parsed: ParseResult) -> tuple[str | None, bool]:
    """Pull a video ID out of any common YouTube URL shape. Returns
    (video_id, is_short). Supports youtube.com/watch?v=, youtu.be/<id>
    (incl. Shorts sharing links), /shorts/<id>, /embed/<id>, /live/<id>."""
    host = _strip_www(parsed.hostname or "")
    path = parsed.path or ""

    if host in YOUTU_BE_HOSTS:
        vid = path.strip("/").split("/")[0]
        return (vid or None), False

    if host in YOUTUBE_HOSTS:
        for prefix, is_short in (("/shorts/", True), ("/embed/", False), ("/live/", False)):
            if path.startswith(prefix):
                vid = path[len(prefix):].split("/")[0]
                return (vid or None), is_short
        if path == "/watch":
            qs = dict(parse_qsl(parsed.query))
            return qs.get("v"), False

    return None, False


async def _fetch_youtube_metadata(
    url: str, parsed: ParseResult, http_client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """YouTube's watch pages are JS-heavy and can land on an EU consent
    interstitial for cookie-less/non-browser requests, which is what made
    plain HTML fetching for YouTube unreliable. oEmbed is YouTube's own
    documented, key-free JSON metadata endpoint and sidesteps all of that
    -- it works identically for youtube.com, youtu.be, and Shorts links."""
    video_id, is_short = _extract_youtube_id(parsed)
    target = f"https://www.youtube.com/watch?v={video_id}" if video_id else url
    try:
        resp = await http_client.get(
            YOUTUBE_OEMBED_URL, params={"url": target, "format": "json"}, timeout=HTTP_TIMEOUT
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        logger.debug("YouTube oEmbed lookup failed for %s", url, exc_info=True)
        return None

    result: dict[str, Any] = {"title": data.get("title"), "author": data.get("author_name")}
    if data.get("thumbnail_url"):
        result["thumbnail"] = data["thumbnail_url"]
    if is_short:
        result["is_short"] = True
    return result


async def _fetch_tiktok_metadata(
    url: str, parsed: ParseResult, http_client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """TikTok's pages are almost entirely client-side-rendered, so a plain
    HTML fetch reliably gets nothing useful. TikTok's own oEmbed endpoint
    returns title/author directly as JSON."""
    try:
        resp = await http_client.get(TIKTOK_OEMBED_URL, params={"url": url}, timeout=HTTP_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        logger.debug("TikTok oEmbed lookup failed for %s", url, exc_info=True)
        return None

    result: dict[str, Any] = {"title": data.get("title"), "author": data.get("author_name")}
    if data.get("thumbnail_url"):
        result["thumbnail"] = data["thumbnail_url"]
    return result


def _normalize_twitter_url(url: str) -> str:
    """publish.twitter.com's oEmbed historically expects a twitter.com
    URL; normalize x.com links to that form before calling it."""
    parsed = urlparse(url)
    if _strip_www(parsed.hostname or "") == "x.com":
        parsed = parsed._replace(netloc="twitter.com")
        return parsed.geturl()
    return url


def _extract_tweet_text(html_blob: str) -> str | None:
    """Pull the plain tweet text out of the <blockquote> HTML fragment
    returned by Twitter/X's oEmbed endpoint."""
    if not html_blob:
        return None
    try:
        soup = BeautifulSoup(html_blob, "html.parser")
        p_tag = soup.find("p")
        text = p_tag.get_text(" ", strip=True) if p_tag else None
    except Exception:
        return None
    return _truncate(text, 300) if text else None


async def _fetch_twitter_metadata(
    url: str, parsed: ParseResult, http_client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """Twitter/X requires a logged-in session for most HTML scraping to see
    real content; publish.twitter.com/oembed is the public, key-free path
    Twitter itself provides for embedding a tweet's author and text."""
    normalized = _normalize_twitter_url(url)
    try:
        resp = await http_client.get(
            TWITTER_OEMBED_URL,
            params={"url": normalized, "omit_script": "true"},
            timeout=HTTP_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        logger.debug("Twitter/X oEmbed lookup failed for %s", url, exc_info=True)
        return None

    result: dict[str, Any] = {}
    author = data.get("author_name")
    if author:
        result["title"] = author
        result["author"] = author
    tweet_text = _extract_tweet_text(data.get("html") or "")
    if tweet_text:
        result["description"] = tweet_text
    return result or None


async def _fetch_github_metadata(
    url: str, parsed: ParseResult, http_client: httpx.AsyncClient
) -> dict[str, Any] | None:
    """Use GitHub's public REST API (no auth needed for public repos) for
    reliable structured metadata instead of scraping the repo page's HTML.
    Only handles owner/repo-shaped URLs; anything else (gists, user
    profiles, issue/PR pages, ...) falls through to the generic scraper."""
    parts = [p for p in (parsed.path or "").split("/") if p]
    if len(parts) < 2:
        return None
    owner, repo = parts[0], re.sub(r"\.git$", "", parts[1])
    api_url = f"{GITHUB_API_BASE}/{quote(owner)}/{quote(repo)}"
    try:
        resp = await http_client.get(
            api_url, headers={"Accept": "application/vnd.github+json"}, timeout=HTTP_TIMEOUT
        )
        if resp.status_code in (404, 403):
            # 403 is most often GitHub's unauthenticated rate limit
            # (60 req/hr/IP) rather than a real error -- either way, fall
            # back to the generic scraper instead of surfacing an error.
            return None
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        logger.debug("GitHub API lookup failed for %s", url, exc_info=True)
        return None

    result: dict[str, Any] = {"title": data.get("full_name"), "description": data.get("description")}
    if data.get("stargazers_count") is not None:
        result["stars"] = data["stargazers_count"]
    if data.get("language"):
        result["language"] = data["language"]
    if data.get("forks_count") is not None:
        result["forks"] = data["forks_count"]
    return result


# Instagram and Telegram deliberately have no entry here -- both are
# left on the generic HTML/OG-tag scraping path further down, which
# already works reasonably well for them (no official key-free JSON API
# exists for either). "Unknown websites" also fall through to that same
# generic path automatically, simply by not appearing in this mapping.
_SERVICE_METADATA_FETCHERS: dict[
    ServiceType, Callable[[str, ParseResult, httpx.AsyncClient], Any]
] = {
    ServiceType.YOUTUBE: _fetch_youtube_metadata,
    ServiceType.TIKTOK: _fetch_tiktok_metadata,
    ServiceType.TWITTER: _fetch_twitter_metadata,
    ServiceType.GITHUB: _fetch_github_metadata,
}


def _redirect_chain_hosts(response: httpx.Response, original_domain: str) -> list[str]:
    """Distinct, consecutive-deduplicated hostnames the request actually
    passed through, from the original host to the final one."""
    hosts: list[str] = []
    for hop in response.history:
        h = urlparse(str(hop.url)).hostname or ""
        if not hosts or hosts[-1] != h:
            hosts.append(h)
    final_host = urlparse(str(response.url)).hostname or ""
    if not hosts or hosts[-1] != final_host:
        hosts.append(final_host)
    return hosts or [original_domain]


async def _fallback_generic_scrape(
    url: str, http_client: httpx.AsyncClient
) -> tuple[str | None, str | None] | None:
    """One-shot best-effort generic title/description scrape, used only
    when a dedicated service fetcher above didn't come through (private/
    deleted content, rate limit, API change, ...) so the user still gets
    *something* rather than nothing."""
    try:
        async with http_client.stream("GET", url) as response:
            content_type_header = response.headers.get("content-type", "")
            if "text/html" not in content_type_header.lower():
                return None
            body = bytearray()
            async for chunk in response.aiter_bytes():
                body.extend(chunk)
                if len(body) >= MAX_BODY_PEEK_BYTES:
                    break
        return _parse_html_metadata(bytes(body))
    except Exception:
        logger.debug("Fallback generic scrape failed for %s", url, exc_info=True)
        return None


async def _analyze_url(url: str, http_client: httpx.AsyncClient) -> URLAnalysis:
    """Safely gather basic, publicly available metadata about a URL."""
    parsed = urlparse(url)
    domain = parsed.hostname or ""
    protocol = parsed.scheme.upper() or "UNKNOWN"

    analysis = URLAnalysis(url=url, domain=domain, protocol=protocol, final_url=url)
    analysis.service = _detect_service(parsed)

    if parsed.scheme not in ("http", "https"):
        analysis.error = "err_not_fetchable"
        analysis.observations = _build_observations(analysis, parsed)
        return analysis

    is_safe, resolved_ips = await _is_safe_host(domain, http_client)
    if not is_safe:
        analysis.error = "err_blocked_private"
        analysis.error_params = {"ip": resolved_ips[0] if resolved_ips else "?"}
        analysis.observations = _build_observations(analysis, parsed)
        return analysis

    has_dedicated = analysis.service in _SERVICE_METADATA_FETCHERS

    try:
        async with http_client.stream("GET", url) as response:
            analysis.status_code = response.status_code
            analysis.redirect_count = len(response.history)
            analysis.final_url = str(response.url)
            analysis.redirect_chain = _redirect_chain_hosts(response, domain)

            headers = response.headers
            content_type_header = headers.get("content-type", "")
            analysis.content_type = content_type_header.split(";")[0].strip() or None

            length_header = headers.get("content-length")
            if length_header and length_header.isdigit():
                analysis.content_length = int(length_header)

            if has_dedicated:
                # A dedicated official API is used for metadata below, so
                # there's no need to download/parse an HTML body at all --
                # this also saves bandwidth/CPU vs. the old always-scrape
                # approach for exactly the services that most needed it.
                await response.aclose()
            elif "text/html" in content_type_header.lower():
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) >= MAX_BODY_PEEK_BYTES:
                        break
                analysis.title, analysis.description = _parse_html_metadata(bytes(body))
            elif content_type_header.lower().startswith("image/"):
                # A QR code that encodes a link (rather than embedding the
                # picture itself, e.g. because it was too large to embed
                # directly) still fundamentally represents "this is an
                # image" from the user's point of view -- so fetch the
                # actual bytes here (bounded by MAX_IMAGE_BYTES, same cap
                # used everywhere else images are handled) so the original
                # can be sent back at full quality, not just described.
                analysis.is_downloadable_file = True
                analysis.filename = _extract_filename(headers.get("content-disposition", ""))
                if analysis.content_length is None or analysis.content_length <= MAX_IMAGE_BYTES:
                    body = bytearray()
                    async for chunk in response.aiter_bytes():
                        body.extend(chunk)
                        if len(body) > MAX_IMAGE_BYTES:
                            body = None
                            break
                    if body:
                        analysis.is_image_file = True
                        analysis.image_bytes = bytes(body)
            else:
                analysis.is_downloadable_file = True
                analysis.filename = _extract_filename(headers.get("content-disposition", ""))

    except httpx.TimeoutException:
        analysis.error = "err_timeout"
    except httpx.TooManyRedirects:
        analysis.error = "err_too_many_redirects"
    except httpx.ConnectError:
        analysis.error = "err_connect_failed"
    except httpx.HTTPError as exc:
        analysis.error = "err_network"
        analysis.error_params = {"detail": exc.__class__.__name__}
    except Exception:
        logger.debug("Unexpected error analyzing URL: %s", url, exc_info=True)
        analysis.error = "err_unexpected"

    # A shortener (or any redirect) might land on a known service even
    # though the original link gave no hint of it -- re-detect against the
    # final resolved URL so e.g. a bit.ly link to a YouTube video still
    # gets YouTube-specific enrichment instead of being left generic.
    metadata_url, metadata_parsed = url, parsed
    if analysis.service == ServiceType.GENERIC and analysis.final_url != url:
        final_parsed = urlparse(analysis.final_url)
        redetected = _detect_service(final_parsed)
        if redetected != ServiceType.GENERIC:
            analysis.service = redetected
            metadata_url, metadata_parsed = analysis.final_url, final_parsed
            has_dedicated = analysis.service in _SERVICE_METADATA_FETCHERS

    if analysis.error is None and has_dedicated:
        fetcher = _SERVICE_METADATA_FETCHERS[analysis.service]
        try:
            meta = await fetcher(metadata_url, metadata_parsed, http_client)
        except Exception:
            logger.debug("Dedicated metadata fetch raised for %s", metadata_url, exc_info=True)
            meta = None

        if meta:
            analysis.title = meta.get("title") or analysis.title
            analysis.description = meta.get("description") or analysis.description
            analysis.author = meta.get("author")
            analysis.extra = {k: v for k, v in meta.items() if k not in ("title", "description", "author")}
        else:
            fallback = await _fallback_generic_scrape(metadata_url, http_client)
            if fallback:
                analysis.title, analysis.description = fallback

    analysis.observations = _build_observations(analysis, parsed)
    return analysis


# --------------------------------------------------------------------------
# QR code generation
# --------------------------------------------------------------------------

def _clamp_size(size: int) -> int:
    return max(MIN_QR_SIZE, min(size, MAX_QR_SIZE))


def _extract_size(raw: str) -> tuple[int, str]:
    match = _SIZE_FLAG_PATTERN.search(raw)
    if not match:
        return DEFAULT_QR_SIZE, raw.strip()
    size = _clamp_size(int(match.group(1)))
    content = (raw[: match.start()] + raw[match.end():]).strip()
    return size, content


def _try_embed_image_directly(image_bytes: bytes) -> tuple[str | None, str]:
    """Only for genuinely small source images: try to fit a *recognizable*
    thumbnail into a data:image URI small enough for a single scannable QR
    code. This is deliberately NEVER attempted for large/high-resolution
    originals -- see the size gate below -- because shrinking a real photo
    down by 99.9% to force it into a QR code just destroys it for no real
    benefit; the primary strategy (see `_generate_qr_from_image`) is always
    to upload the untouched original and embed a link instead.

    Returns (data_uri, "ok") on success. On failure returns (None, reason)
    where reason is one of "too_large_dimensions", "too_large_bytes", or
    "no_fit" (small enough to try, but no quality/size combination fit the
    byte budget) so the caller can show an accurate message either way."""
    if len(image_bytes) > _DIRECT_EMBED_MAX_SOURCE_BYTES:
        return None, "too_large_bytes"

    try:
        image = Image.open(io.BytesIO(image_bytes))
        image = ImageOps.exif_transpose(image) or image
        image = image.convert("RGB")
    except Exception:
        logger.debug("Could not open image for image-to-QR encoding", exc_info=True)
        return None, "no_fit"

    if max(image.size) > _DIRECT_EMBED_MAX_DIMENSION:
        return None, "too_large_dimensions"

    for side in _EMBED_THUMBNAIL_SIDES:
        thumb = image.copy()
        thumb.thumbnail((side, side), Image.LANCZOS)
        for quality in _EMBED_JPEG_QUALITIES:
            buffer = io.BytesIO()
            try:
                thumb.save(buffer, format="JPEG", quality=quality, optimize=True)
            except Exception:
                logger.debug("JPEG encode failed at side=%s quality=%s", side, quality, exc_info=True)
                continue
            encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
            data_uri = f"data:image/jpeg;base64,{encoded}"
            if len(data_uri) <= _IMAGE_QR_BYTE_BUDGET:
                return data_uri, "ok"

    return None, "no_fit"


def _emergency_embed_image(image_bytes: bytes) -> str | None:
    """Absolute last resort for turning ANY image into a QR code when
    every upload host failed and the image is too large/high-res for
    `_try_embed_image_directly`'s normal, higher-fidelity budget. Uses a
    larger byte budget and heavier compression, so the result is always a
    genuinely low-quality thumbnail -- callers must pair this with an
    explicit warning; it exists so the command still produces *something*
    scannable rather than a hard failure, never as a silent substitute for
    the real, full-quality upload-and-link result."""
    try:
        image = Image.open(io.BytesIO(image_bytes))
        image = ImageOps.exif_transpose(image) or image
        image = image.convert("RGB")
    except Exception:
        logger.debug("Could not open image for emergency QR embedding", exc_info=True)
        return None

    for side in _EMERGENCY_THUMBNAIL_SIDES:
        thumb = image.copy()
        thumb.thumbnail((side, side), Image.LANCZOS)
        for quality in _EMERGENCY_JPEG_QUALITIES:
            buffer = io.BytesIO()
            try:
                thumb.save(buffer, format="JPEG", quality=quality, optimize=True)
            except Exception:
                logger.debug("Emergency JPEG encode failed at side=%s quality=%s", side, quality, exc_info=True)
                continue
            encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
            data_uri = f"data:image/jpeg;base64,{encoded}"
            if len(data_uri) <= _EMERGENCY_EMBED_BYTE_BUDGET:
                return data_uri

    return None


def _generate_qr_image(
    content: str, target_size: int, error_correction: int = ERROR_CORRECT_M
) -> tuple[bytes, int]:
    """Render `content` as a crisp PNG QR code approximately `target_size`
    pixels square. Size is controlled *only* through the QR module's own
    integer `box_size` (a whole-pixel-per-module scale factor) -- never by
    resizing the rendered bitmap afterwards, since interpolated resizing
    blurs the sharp module edges a scanner depends on and was what could
    previously make generated codes hard for some cameras to read.

    `error_correction` defaults to M (a good general real-world balance)
    everywhere except the emergency image-embed path, which explicitly
    opts into L for ~27% more raw data capacity -- a reasonable trade once
    quality is already known to be compromised, since it's a digitally
    generated/displayed code rather than a printed one exposed to wear.

    Returns (png_bytes, actual_size): the actual rendered size is returned
    alongside the bytes because it's quantized to a whole number of QR
    modules and will not exactly equal `target_size` in general."""
    try:
        # A single QRCode object does all the work: make(fit=True) is the
        # expensive part (picks the smallest version that fits, computes
        # Reed-Solomon error-correction codewords, places every module) and
        # is completely independent of box_size, which is only consumed
        # later by make_image(). So box_size=1 is used just to fit, then
        # mutated to the real computed value before rendering -- this
        # renders pixel-identically to (and is faster than) building a
        # separate throwaway QRCode purely to probe the module count.
        qr = qrcode.QRCode(error_correction=error_correction, box_size=1, border=QR_BORDER)
        qr.add_data(content)
        qr.make(fit=True)

        total_modules = qr.modules_count + 2 * QR_BORDER
        qr.box_size = max(MIN_BOX_SIZE, round(target_size / total_modules))

        rendered = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        actual_size = rendered.size[0]  # always square

        output_buffer = io.BytesIO()
        rendered.save(output_buffer, format="PNG", optimize=True)
        return output_buffer.getvalue(), actual_size

    except (DataOverflowError, ValueError) as exc:
        # qrcode raises DataOverflowError for most over-capacity content,
        # but can raise a plain ValueError from its internal version
        # bisection when the data doesn't fit even at the largest version
        # (40) -- both mean the same thing from the user's point of view.
        raise QRGenerationError(
            "This content is too large to encode in a single QR code.",
            key="qr_overflow",
        ) from exc
    except QRGenerationError:
        raise
    except Exception as exc:
        raise QRGenerationError(
            f"Failed to generate QR code: {exc}",
            key="qr_gen_failed",
            detail=str(exc),
        ) from exc


def _build_qr_caption(content: str, qtype: QRType, size: int, lang: str) -> str:
    preview = _truncate(content, 300)
    lines = [
        f"<b>{t('lbl_qr_generated', lang)}</b>",
        f"<b>{t('lbl_type', lang)}:</b> {esc(_qtype_label(qtype, lang))}",
        f"<b>{t('lbl_size', lang)}:</b> {size}×{size}px",
        f"<b>{t('lbl_characters', lang)}:</b> {len(content)}",
        "",
        f"<b>{t('lbl_content', lang)}:</b>",
        f"<code>{esc(preview)}</code>",
    ]
    caption = "\n".join(lines)
    if len(caption) > _TELEGRAM_CAPTION_LIMIT:
        caption = caption[: _TELEGRAM_CAPTION_LIMIT - 1] + "…"
    return caption


# --------------------------------------------------------------------------
# Report formatting
# --------------------------------------------------------------------------

def _format_type_specific(result: QRResult, lang: str) -> list[str]:
    data = result.parsed
    if not data:
        return []

    lines: list[str] = []

    if result.qr_type == QRType.WIFI:
        lines.append(f"<b>{t('lbl_ssid', lang)}:</b> {esc(data.get('ssid') or 'N/A')}")
        lines.append(f"<b>{t('lbl_encryption', lang)}:</b> {esc(data.get('encryption', 'Unknown'))}")
        password = data.get("password") or "None"
        lines.append(f"<b>{t('lbl_password', lang)}:</b> <code>{esc(password)}</code>")
        hidden_text = t("yes", lang) if data.get("hidden") else t("no", lang)
        lines.append(f"<b>{t('lbl_hidden', lang)}:</b> {hidden_text}")

    elif result.qr_type == QRType.VCARD:
        if data.get("name"):
            lines.append(f"<b>{t('lbl_name', lang)}:</b> {esc(data['name'])}")
        if data.get("organization"):
            lines.append(f"<b>{t('lbl_organization', lang)}:</b> {esc(data['organization'])}")
        if data.get("title"):
            lines.append(f"<b>{t('lbl_title', lang)}:</b> {esc(data['title'])}")
        for phone in data.get("phones", []):
            lines.append(f"<b>{t('lbl_phone', lang)}:</b> {esc(phone)}")
        for email_addr in data.get("emails", []):
            lines.append(f"<b>{t('lbl_email', lang)}:</b> {esc(email_addr)}")
        if data.get("address"):
            lines.append(f"<b>{t('lbl_address', lang)}:</b> {esc(data['address'])}")
        if data.get("url"):
            lines.append(f"<b>{t('lbl_website', lang)}:</b> {esc(data['url'])}")

    elif result.qr_type == QRType.EMAIL:
        lines.append(f"<b>{t('lbl_address', lang)}:</b> {esc(data.get('email') or 'N/A')}")
        if data.get("subject"):
            lines.append(f"<b>{t('lbl_subject', lang)}:</b> {esc(data['subject'])}")
        if data.get("body"):
            lines.append(f"<b>{t('lbl_body', lang)}:</b> {esc(_truncate(data['body'], 150))}")

    elif result.qr_type == QRType.TEL:
        lines.append(f"<b>{t('lbl_number', lang)}:</b> {esc(data.get('number') or 'N/A')}")

    elif result.qr_type == QRType.SMS:
        lines.append(f"<b>{t('lbl_number', lang)}:</b> {esc(data.get('number') or 'N/A')}")
        if data.get("message"):
            lines.append(f"<b>{t('lbl_message', lang)}:</b> {esc(_truncate(data['message'], 150))}")

    elif result.qr_type == QRType.GEO:
        lat = data.get("latitude", "N/A")
        lon = data.get("longitude", "N/A")
        lines.append(f"<b>{t('lbl_latitude', lang)}:</b> {esc(lat)}")
        lines.append(f"<b>{t('lbl_longitude', lang)}:</b> {esc(lon)}")
        if data.get("altitude"):
            lines.append(f"<b>{t('lbl_altitude', lang)}:</b> {esc(data['altitude'])}")
        lines.append(f"<b>{t('lbl_map', lang)}:</b> https://maps.google.com/?q={esc(lat)},{esc(lon)}")

    elif result.qr_type == QRType.BITCOIN:
        lines.append(f"<b>{t('lbl_address', lang)}:</b> <code>{esc(data.get('address') or 'N/A')}</code>")
        if data.get("amount"):
            lines.append(f"<b>{t('lbl_amount', lang)}:</b> {esc(data['amount'])} BTC")
        if data.get("label"):
            lines.append(f"<b>{t('lbl_label', lang)}:</b> {esc(data['label'])}")
        if data.get("message"):
            lines.append(f"<b>{t('lbl_message', lang)}:</b> {esc(data['message'])}")

    elif result.qr_type == QRType.EVENT:
        if data.get("summary"):
            lines.append(f"<b>{t('lbl_summary', lang)}:</b> {esc(data['summary'])}")
        if data.get("start"):
            lines.append(f"<b>{t('lbl_start', lang)}:</b> {esc(data['start'])}")
        if data.get("end"):
            lines.append(f"<b>{t('lbl_end', lang)}:</b> {esc(data['end'])}")
        if data.get("location"):
            lines.append(f"<b>{t('lbl_location', lang)}:</b> {esc(data['location'])}")
        if data.get("description"):
            lines.append(f"<b>{t('lbl_description', lang)}:</b> {esc(_truncate(data['description'], 150))}")

    elif result.qr_type == QRType.IMAGE:
        if data.get("mime_subtype"):
            lines.append(f"<b>{t('lbl_format', lang)}:</b> {esc(data['mime_subtype'])}")
        if data.get("byte_size") is not None:
            lines.append(f"<b>{t('lbl_size', lang)}:</b> {esc(_human_size(data['byte_size']))}")
        lines.append(t("embedded_image_note", lang))

    return lines


def _format_url_analysis(analysis: URLAnalysis, lang: str) -> list[str]:
    lines = [f"<b>{t('lbl_analysis_header', lang)}</b>"]
    lines.append(f"<b>{t('lbl_protocol', lang)}:</b> {esc(analysis.protocol)}")
    lines.append(f"<b>{t('lbl_domain', lang)}:</b> {esc(analysis.domain or 'N/A')}")
    if analysis.service != ServiceType.GENERIC:
        lines.append(f"<b>{t('lbl_service', lang)}:</b> {esc(_service_label(analysis, lang))}")

    if analysis.error:
        error_text = t(analysis.error, lang, **analysis.error_params)
        lines.append(f"<b>{t('lbl_status', lang)}:</b> ⚠ {esc(error_text)}")
    else:
        if analysis.status_code is not None:
            lines.append(f"<b>{t('lbl_http_status', lang)}:</b> {analysis.status_code}")
        lines.append(f"<b>{t('lbl_redirects', lang)}:</b> {analysis.redirect_count}")
        if analysis.redirect_count > 0:
            lines.append(f"<b>{t('lbl_final_url', lang)}:</b> {esc(_truncate(analysis.final_url, 200))}")
            distinct_hosts = [h for h in analysis.redirect_chain if h]
            if len(distinct_hosts) > 1:
                chain_text = " → ".join(esc(h) for h in distinct_hosts)
                lines.append(f"<b>{t('lbl_redirect_path', lang)}:</b> {chain_text}")
        if analysis.content_type:
            lines.append(f"<b>{t('lbl_content_type', lang)}:</b> {esc(analysis.content_type)}")
        if analysis.content_length is not None:
            lines.append(f"<b>{t('lbl_content_length', lang)}:</b> {esc(_human_size(analysis.content_length))}")
        if analysis.is_downloadable_file:
            lines.append(f"<b>{t('lbl_downloadable', lang)}:</b> {t('yes', lang)}")
            if analysis.filename:
                lines.append(f"<b>{t('lbl_filename', lang)}:</b> {esc(analysis.filename)}")
            if analysis.is_image_file and analysis.image_bytes:
                lines.append(t("linked_image_note", lang))
        else:
            if analysis.title:
                lines.append(f"<b>{t('lbl_title', lang)}:</b> {esc(analysis.title)}")
            if analysis.author:
                lines.append(f"<b>{t('lbl_author', lang)}:</b> {esc(analysis.author)}")
            if analysis.description:
                lines.append(f"<b>{t('lbl_description', lang)}:</b> {esc(analysis.description)}")
            if analysis.service == ServiceType.GITHUB:
                stats = []
                if "stars" in analysis.extra:
                    stats.append(f"⭐ {analysis.extra['stars']}")
                if "language" in analysis.extra:
                    stats.append(str(analysis.extra["language"]))
                if "forks" in analysis.extra:
                    stats.append(f"🍴 {analysis.extra['forks']}")
                if stats:
                    lines.append(f"<b>{t('lbl_repo_stats', lang)}:</b> {esc(' · '.join(stats))}")
            if analysis.extra.get("thumbnail"):
                lines.append(f"<b>{t('lbl_thumbnail', lang)}:</b> {esc(analysis.extra['thumbnail'])}")

    if analysis.observations:
        lines.append(f"<b>{t('lbl_observations', lang)}:</b>")
        for observation in analysis.observations:
            symbol = _OBSERVATION_SYMBOLS[observation.level]
            obs_text = t(observation.key, lang, **observation.params)
            lines.append(f"{symbol} {esc(obs_text)}")

    return lines


def _format_qr_block(result: QRResult, lang: str) -> str:
    lines = [
        f"<b>{t('lbl_qr_num', lang, n=result.index)}</b>",
        f"<b>{t('lbl_type', lang)}:</b> {esc(_qtype_label(result.qr_type, lang))}",
        f"<b>{t('lbl_content', lang)}:</b>",
    ]
    if result.qr_type == QRType.IMAGE:
        lines.append(t("image_content_placeholder", lang))
    else:
        lines.append(f"<code>{esc(_truncate(result.raw_content, 500))}</code>")
    lines.append(f"<b>{t('lbl_characters', lang)}:</b> {result.char_count}")
    lines.append(f"<b>{t('lbl_encoding', lang)}:</b> {esc(result.encoding)}")

    extra = _format_type_specific(result, lang)
    if extra:
        lines.append("")
        lines.extend(extra)

    if result.url_analysis is not None:
        lines.append("")
        lines.extend(_format_url_analysis(result.url_analysis, lang))

    return "\n".join(lines)


def _format_scan_report(results: list[QRResult], lang: str, truncated: bool = False) -> str:
    count = len(results)
    plural = "s" if count != 1 else ""
    header = f"<b>{t('scan_header', lang, count=count, plural=plural)}</b>"
    if truncated:
        header += t("scan_header_truncated", lang, n=MAX_QR_CODES_PER_IMAGE)

    blocks = [_format_qr_block(r, lang) for r in results]
    separator = "\n" + ("─" * 20) + "\n"
    return header + "\n\n" + separator.join(blocks)


def _split_message(text: str, limit: int) -> list[str]:
    if len(text) <= limit:
        return [text]

    parts: list[str] = []
    remaining = text
    while len(remaining) > limit:
        split_at = remaining.rfind("\n\n", 0, limit)
        if split_at <= 0:
            split_at = remaining.rfind("\n", 0, limit)
        if split_at <= 0:
            split_at = limit
        parts.append(remaining[:split_at].rstrip())
        remaining = remaining[split_at:].lstrip("\n")
    if remaining:
        parts.append(remaining)
    return parts


# --------------------------------------------------------------------------
# Telegram / media helpers
# --------------------------------------------------------------------------

def _is_image_message(message: Message | None) -> bool:
    """True only when the message's OWN media is a photo or an image
    document -- never for a text/link message whose only "photo" comes
    from an auto-generated webpage-preview thumbnail. Telethon's
    `.photo`/`.document`/`.file` convenience properties transparently
    fall back to a message's webpage preview when checked directly (see
    their docstrings), which would otherwise make a bare link that gets a
    rich preview -- e.g. a YouTube URL, which Telegram reliably attaches
    a large thumbnail to -- look like "an image to scan for a QR code"
    instead of the text/link it actually is. Confirming the real media
    type first avoids that fallback entirely."""
    if message is None:
        return False
    media = message.media
    if isinstance(media, MessageMediaPhoto):
        return True
    if isinstance(media, MessageMediaDocument):
        mime_type = message.file.mime_type if message.file else None
        return bool(mime_type and mime_type.startswith("image/"))
    return False


def _get_media_size(message: Message) -> int | None:
    try:
        return message.file.size if message.file else None
    except Exception:
        return None


async def _send_status(event: events.NewMessage.Event, text: str) -> Message:
    try:
        return await event.edit(text, parse_mode="html", link_preview=False)
    except Exception:
        logger.debug("Could not edit command message; replying instead", exc_info=True)
        return await event.reply(text, parse_mode="html", link_preview=False)


async def _deliver_report(status: Message, report: str) -> None:
    chunks = _split_message(report, _TELEGRAM_TEXT_LIMIT - 16) or ["No data to display."]
    try:
        await status.edit(chunks[0], parse_mode="html", link_preview=False)
    except Exception:
        logger.debug("Failed to edit status message with report", exc_info=True)
        status = await status.reply(chunks[0], parse_mode="html", link_preview=False)
    for chunk in chunks[1:]:
        await status.reply(chunk, parse_mode="html", link_preview=False)


async def _deliver_qr_images(
    event: events.NewMessage.Event, results: list[QRResult], lang: str
) -> None:
    """Send back the original image, at full quality, for any decoded QR
    that represents one -- whether the picture was embedded directly
    (a data:image;base64 URI, only possible for genuinely small images)
    or the QR just links to it (the case for anything too large to embed,
    which is why the image was uploaded and linked in the first place).
    Either way, the point is the same: verify "what image was this QR
    really about?" by seeing the actual picture, not a wall of base64 or
    a bare URL."""
    for result in results:
        if result.qr_type == QRType.IMAGE:
            raw_bytes = _decode_data_image_bytes(result.raw_content)
            if not raw_bytes:
                continue
            try:
                with Image.open(io.BytesIO(raw_bytes)) as probe:
                    probe.load()
            except Exception:
                logger.debug("data:image payload did not decode to a valid image", exc_info=True)
                continue
            caption = t("embedded_image_caption", lang, n=result.index)
        elif result.qr_type == QRType.URL and result.url_analysis and result.url_analysis.is_image_file:
            raw_bytes = result.url_analysis.image_bytes
            if not raw_bytes:
                continue
            caption = t("linked_image_caption", lang, n=result.index)
        else:
            continue

        buffer = io.BytesIO(raw_bytes)
        buffer.name = f"qr_image_{result.index}.jpg"
        try:
            await event.client.send_file(
                event.chat_id,
                file=buffer,
                caption=caption,
                parse_mode="html",
            )
        except Exception:
            logger.debug("Failed to send image for QR #%s", result.index, exc_info=True)


async def _safe_error_reply(event: events.NewMessage.Event, exc: Exception) -> None:
    lang = "en"
    try:
        match = event.pattern_match
        if match:
            lang = _detect_lang(match.group("cmd") or "")
    except Exception:
        pass
    error_text = str(exc) or exc.__class__.__name__
    message = t("error_prefix", lang, message=esc(error_text))
    try:
        await event.edit(message, parse_mode="html")
    except Exception:
        try:
            await event.reply(message, parse_mode="html")
        except Exception:
            logger.exception("Failed to deliver error message to the user")


# --------------------------------------------------------------------------
# Processing orchestration
# --------------------------------------------------------------------------

async def _process_decoded_qr(
    index: int, decoded: DecodedQR, http_client: httpx.AsyncClient
) -> QRResult:
    text, encoding = _decode_bytes(decoded.data)
    qtype = detect_qr_type(text)
    parsed_fields = _parse_content(qtype, text)

    url_analysis: URLAnalysis | None = None
    if qtype == QRType.URL:
        target = text if text.lower().startswith(("http://", "https://")) else f"http://{text}"
        url_analysis = await _analyze_url(target, http_client)

    return QRResult(
        index=index,
        qr_type=qtype,
        raw_content=text,
        char_count=len(text),
        encoding=encoding,
        parsed=parsed_fields,
        url_analysis=url_analysis,
    )


async def _process_all(
    decoded_list: list[DecodedQR], http_client: httpx.AsyncClient
) -> list[QRResult]:
    tasks = [
        _process_decoded_qr(idx, decoded, http_client)
        for idx, decoded in enumerate(decoded_list, start=1)
    ]
    return list(await asyncio.gather(*tasks))


# --------------------------------------------------------------------------
# Command handlers
# --------------------------------------------------------------------------

async def _handle_qr(event: events.NewMessage.Event) -> None:
    try:
        match = event.pattern_match
        lang = _detect_lang(match.group("cmd") or "")
        raw = (match.group("content") or "").strip()
        usage_kwargs = dict(
            prefix=COMMAND_PREFIX,
            min_size=MIN_QR_SIZE,
            max_size=MAX_QR_SIZE,
            default_size=DEFAULT_QR_SIZE,
        )

        if not raw:
            # No text supplied. Replying to an image with a bare "/qr" always
            # means "turn this image into a QR code" -- it never inspects the
            # image for a QR code of its own. Reading/showing existing QR or
            # link content is exclusively "/scan"'s job (_scan_image_reply).
            reply = await event.get_reply_message()
            if reply is not None and _is_image_message(reply):
                await _qr_from_image_reply(event, reply, lang)
                return
            await event.reply(t("qr_usage", lang, **usage_kwargs), parse_mode="html")
            return

        size, content = _extract_size(raw)
        if not content:
            await event.reply(t("qr_usage", lang, **usage_kwargs), parse_mode="html")
            return

        if len(content.encode("utf-8", errors="ignore")) > MAX_QR_PAYLOAD_BYTES:
            await event.reply(t("content_too_long", lang, max_bytes=MAX_QR_PAYLOAD_BYTES))
            return

        status = await _send_status(event, t("status_generating", lang))

        try:
            image_bytes, actual_size = await asyncio.to_thread(_generate_qr_image, content, size)
        except QRGenerationError as exc:
            msg = t(exc.key, lang, **exc.params) if exc.key in _STRINGS else str(exc)
            await status.edit(f"❌ {esc(msg)}", parse_mode="html")
            return

        qtype = detect_qr_type(content)
        caption = _build_qr_caption(content, qtype, actual_size, lang)

        buffer = io.BytesIO(image_bytes)
        buffer.name = "qrcode.png"

        await event.client.send_file(
            event.chat_id,
            file=buffer,
            caption=caption,
            parse_mode="html",
        )

        try:
            await status.delete()
        except Exception:
            logger.debug("Could not delete status message", exc_info=True)

    except Exception as exc:
        logger.exception("'/qr' command failed")
        await _safe_error_reply(event, exc)


async def _handle_scanqr(event: events.NewMessage.Event) -> None:
    """Dispatches '/scan' / '/scanqr' / '/اسکن' to the image or link scanner."""
    try:
        match = event.pattern_match
        lang = _detect_lang(match.group("cmd") or "")

        reply = await event.get_reply_message()

        if reply is not None and _is_image_message(reply):
            await _scan_image_reply(event, reply, lang)
            return

        if reply is not None:
            urls = _find_urls_in_text(reply.raw_text or "")
            if urls:
                await _scan_urls(event, urls, lang)
                return

        await event.reply(t("scan_usage", lang, prefix=COMMAND_PREFIX), parse_mode="html")

    except Exception as exc:
        logger.exception("'/scan' command failed")
        await _safe_error_reply(event, exc)


async def _download_replied_image(
    event: events.NewMessage.Event, reply: Message, lang: str, status_text: str
) -> tuple[Message, bytes] | None:
    """Shared size-check + status message + download for any command that
    needs the raw bytes of a replied-to image. On any failure this already
    messages the user and returns None; the caller just bails out."""
    media_size = _get_media_size(reply)
    if media_size is not None and media_size > MAX_IMAGE_BYTES:
        await event.reply(
            t("image_too_large", lang, size=_human_size(media_size), max_size=_human_size(MAX_IMAGE_BYTES))
        )
        return None

    status = await _send_status(event, status_text)

    try:
        image_bytes = await reply.download_media(file=bytes)
    except Exception as exc:
        logger.exception("Failed to download replied media")
        await status.edit(esc(t("download_failed", lang, reason=exc.__class__.__name__)), parse_mode="html")
        return None

    if not image_bytes:
        await status.edit(t("download_failed_generic", lang), parse_mode="html")
        return None

    return status, image_bytes


async def _scan_image_reply(event: events.NewMessage.Event, reply: Message, lang: str) -> None:
    """Handle '/scan' replying to a photo/image: decode and analyze every
    QR code found. This is the only path that ever reads an image's
    existing QR content -- see _qr_from_image_reply for '/qr', which never
    does."""
    downloaded = await _download_replied_image(event, reply, lang, t("status_scanning_image", lang))
    if downloaded is None:
        return
    status, image_bytes = downloaded

    try:
        decoded_list = await asyncio.to_thread(_decode_qr_codes, image_bytes)
    except QRDecodeError as exc:
        msg = t(exc.key, lang, **exc.params) if exc.key in _STRINGS else str(exc)
        await status.edit(f"❌ {esc(msg)}", parse_mode="html")
        return

    if not decoded_list:
        await status.edit(t("no_qr_found", lang), parse_mode="html")
        return

    truncated = len(decoded_list) > MAX_QR_CODES_PER_IMAGE
    decoded_list = decoded_list[:MAX_QR_CODES_PER_IMAGE]

    try:
        await status.edit(t("status_analyzing", lang), parse_mode="html")
    except Exception:
        logger.debug("Could not update status before analysis", exc_info=True)

    async with _build_http_client() as http_client:
        results = await _process_all(decoded_list, http_client)

    report = _format_scan_report(results, lang, truncated=truncated)
    await _deliver_report(status, report)
    await _deliver_qr_images(event, results, lang)


async def _qr_from_image_reply(event: events.NewMessage.Event, reply: Message, lang: str) -> None:
    """Handle '/qr' (no text) replying to an image: always embeds the image
    itself into a brand-new QR code. Deliberately never decodes the image
    first -- building a QR is this command's only job, so no CPU is spent
    on a pyzbar/OpenCV decode pass that the result wouldn't even use."""
    downloaded = await _download_replied_image(event, reply, lang, t("status_encoding_image_as_qr", lang))
    if downloaded is None:
        return
    status, image_bytes = downloaded
    await _generate_qr_from_image(event, status, image_bytes, lang)


def _detect_image_format(image_bytes: bytes) -> tuple[str, str]:
    """Sniff the real image format so uploads carry an accurate filename
    and Content-Type instead of always claiming '.jpg' regardless of the
    original format. This only parses the header (via PIL) -- it never
    decodes pixel data, so it's cheap even for a large original."""
    try:
        with Image.open(io.BytesIO(image_bytes)) as probe:
            fmt = (probe.format or "JPEG").upper()
    except Exception:
        fmt = "JPEG"
    mime_map = {
        "JPEG": ("jpg", "image/jpeg"),
        "PNG": ("png", "image/png"),
        "WEBP": ("webp", "image/webp"),
        "GIF": ("gif", "image/gif"),
        "BMP": ("bmp", "image/bmp"),
        "TIFF": ("tiff", "image/tiff"),
    }
    return mime_map.get(fmt, ("jpg", "image/jpeg"))


def _describe_exception(exc: BaseException) -> str:
    """`str(exc)` is often empty for httpx's connection-level errors (e.g.
    ConnectError), which just wrap the real OS socket error as `__cause__`
    -- walk the chain so the surfaced detail is actually informative
    instead of a bare "ConnectError: " with nothing after the colon."""
    seen = exc
    for _ in range(3):
        text = str(seen)
        if text:
            return f"{exc.__class__.__name__}: {text}"[:150]
        if seen.__cause__ is None:
            break
        seen = seen.__cause__
    return f"{exc.__class__.__name__} (no further detail available)"


async def _post_upload(
    url: str,
    http_client: httpx.AsyncClient,
    *,
    data: dict | None,
    files: dict,
    headers: dict,
    expected_prefix: str,
) -> tuple[str | None, str | None]:
    """Shared POST-and-validate logic for the anonymous upload hosts below:
    upload, then expect a plain-text URL starting with `expected_prefix`
    back. Returns (url, None) on success, or (None, error_detail) on
    failure -- the detail is shown to the user in the fallback status
    message so a real-world failure (network policy, host block, service
    change, ...) is diagnosable instead of silently vanishing into logs."""
    try:
        response = await http_client.post(url, data=data, files=files, headers=headers, timeout=UPLOAD_TIMEOUT)
        response.raise_for_status()
        result_url = response.text.strip()
        if result_url.startswith(expected_prefix):
            return result_url, None
        logger.debug("Upload to %s returned unexpected body: %s", url, result_url[:200])
        return None, f"unexpected response: {result_url[:120]!r}"
    except httpx.HTTPStatusError as exc:
        detail = f"HTTP {exc.response.status_code}"
        logger.debug("Upload to %s failed: %s", url, detail, exc_info=True)
        return None, detail
    except Exception as exc:
        detail = _describe_exception(exc)
        logger.debug("Upload to %s failed: %s", url, detail, exc_info=True)
        return None, detail


async def _upload_to_catbox(
    image_bytes: bytes, http_client: httpx.AsyncClient, filename: str, content_type: str
) -> tuple[str | None, str | None]:
    """Anonymous upload to Catbox.moe, a long-running free file host with a
    simple no-signup API -- embedding the resulting https:// link is the
    only way to make a QR every standard camera scanner will recognize and
    open (scanners only auto-act on known schemes; they never render
    arbitrary embedded data as an image). Bytes go up completely untouched
    -- no recompression, no resizing -- so the image comes back at full
    original quality.

    Deliberately uses a plain, honest, self-identifying User-Agent rather
    than one pretending to be a full browser: testing showed that a
    fabricated Chrome fingerprint made no difference to Catbox's response
    (an unrelated network intermediary between the user and Catbox is a
    more likely explanation at that point), and impersonation headers atop
    a non-browser TLS stack can look *more* suspicious to real bot-scoring
    than a client that's simply honest about being a bot."""
    headers = {"User-Agent": USER_AGENT}
    files = {"fileToUpload": (filename, image_bytes, content_type)}
    return await _post_upload(
        CATBOX_UPLOAD_URL,
        http_client,
        data={"reqtype": "fileupload"},
        files=files,
        headers=headers,
        expected_prefix="https://files.catbox.moe/",
    )


async def _upload_to_0x0(
    image_bytes: bytes, http_client: httpx.AsyncClient, filename: str, content_type: str
) -> tuple[str | None, str | None]:
    """Second, independent anonymous host, tried only if Catbox fails --
    0x0.st is a long-standing, minimal (single POST, plain-text URL reply)
    anonymous file host. Free third-party services can change over time;
    swap in a replacement here (or add a third entry to
    `_UPLOAD_STRATEGIES`) if this ever stops working."""
    files = {"file": (filename, image_bytes, content_type)}
    return await _post_upload(
        ZEROXZERO_UPLOAD_URL,
        http_client,
        data=None,
        files=files,
        headers={"User-Agent": "curl/8.0"},
        expected_prefix="https://0x0.st/",
    )


async def _upload_to_envs(
    image_bytes: bytes, http_client: httpx.AsyncClient, filename: str, content_type: str
) -> tuple[str | None, str | None]:
    """Third, independent anonymous host, tried only if both Catbox and
    0x0.st fail -- envs.sh runs the same minimal software as 0x0.st but is
    a separately operated instance, so it has its own IP reputation and
    rate limits; one being blocked/overloaded doesn't take the other down
    with it."""
    files = {"file": (filename, image_bytes, content_type)}
    return await _post_upload(
        ENVS_UPLOAD_URL,
        http_client,
        data=None,
        files=files,
        headers={"User-Agent": "curl/8.0"},
        expected_prefix="https://envs.sh/",
    )


_UPLOAD_STRATEGIES: tuple[Callable[..., Any], ...] = (_upload_to_catbox, _upload_to_0x0, _upload_to_envs)


async def _upload_image_with_fallbacks(
    image_bytes: bytes, http_client: httpx.AsyncClient
) -> tuple[str | None, str | None]:
    """Try each independent anonymous upload host in `_UPLOAD_STRATEGIES`
    in turn; the first success wins. One host being down, blocked, or
    rate-limited no longer forces a fall-through to the destructive
    direct-embed path -- that only happens if *every* host fails, in which
    case every host's own error is reported (not just the last one) so a
    real failure is actually diagnosable instead of hiding which host(s)
    were the problem."""
    filename_ext, content_type = _detect_image_format(image_bytes)
    filename = f"image.{filename_ext}"
    errors: list[str] = []
    for uploader in _UPLOAD_STRATEGIES:
        url, error = await uploader(image_bytes, http_client, filename, content_type)
        if url:
            return url, None
        errors.append(f"{uploader.__name__.replace('_upload_to_', '')}: {error}")
    return None, "; ".join(errors)


async def _generate_qr_from_image(
    event: events.NewMessage.Event, status: Message, image_bytes: bytes, lang: str
) -> None:
    """Turn `image_bytes` into a QR code, always producing *something*.
    Order of attempts: (1) upload the untouched original and embed that
    link -- full quality, works for any size; (2) if every upload host
    fails, embed a high-fidelity thumbnail directly, but only when the
    source was already small enough for that to look reasonable; (3) if
    the source is too large for that either, fall back to a much more
    heavily compressed "emergency" thumbnail so the command still
    succeeds instead of erroring out -- always paired with an explicit,
    honest quality warning so this is never mistaken for the original.
    This is /qr's unconditional behavior when replying to an image --
    called from _qr_from_image_reply, which already set an appropriate
    status message, so no status update happens here until something
    changes (upload failing, or the final result)."""
    async with _build_upload_http_client() as http_client:
        public_url, upload_error = await _upload_image_with_fallbacks(image_bytes, http_client)

    content_to_encode: str | None
    used_emergency_embed = False
    if public_url:
        content_to_encode = public_url
    else:
        try:
            await status.edit(
                t(
                    "status_upload_failed_fallback",
                    lang,
                    detail=esc(upload_error or "unknown"),
                ),
                parse_mode="html",
            )
        except Exception:
            logger.debug("Could not update status before local fallback", exc_info=True)

        content_to_encode, embed_reason = await asyncio.to_thread(
            _try_embed_image_directly, image_bytes
        )
        if not content_to_encode and embed_reason in ("too_large_dimensions", "too_large_bytes"):
            # The normal, higher-fidelity embed isn't possible either --
            # last resort: a much more heavily compressed thumbnail, so
            # this still produces *something* scannable instead of a hard
            # failure. Always paired with an explicit quality warning below.
            content_to_encode = await asyncio.to_thread(_emergency_embed_image, image_bytes)
            used_emergency_embed = bool(content_to_encode)

        if not content_to_encode:
            if embed_reason in ("too_large_dimensions", "too_large_bytes"):
                await status.edit(
                    t(
                        "image_upload_failed_and_too_large",
                        lang,
                        detail=esc(upload_error or "unknown"),
                    ),
                    parse_mode="html",
                )
            else:
                await status.edit(t("image_too_complex_for_qr", lang), parse_mode="html")
            return

    try:
        qr_error_correction = ERROR_CORRECT_L if used_emergency_embed else ERROR_CORRECT_M
        qr_png, _actual_size = await asyncio.to_thread(
            _generate_qr_image, content_to_encode, DEFAULT_QR_SIZE, qr_error_correction
        )
    except QRGenerationError as exc:
        msg = t(exc.key, lang, **exc.params) if exc.key in _STRINGS else str(exc)
        await status.edit(f"❌ {esc(msg)}", parse_mode="html")
        return

    if public_url:
        caption = t("image_to_qr_link_caption", lang, url=esc(public_url))
    elif used_emergency_embed:
        size_kb = len(content_to_encode) / 1024
        caption = t("image_emergency_embed_caption", lang, size_kb=f"{size_kb:.1f}")
        caption += "\n" + t(
            "upload_failure_note", lang, detail=esc(upload_error or "unknown")
        )
    else:
        size_kb = len(content_to_encode) / 1024
        caption = t("image_to_qr_caption", lang, size_kb=f"{size_kb:.1f}")
        # The status message showing *why* the upload failed gets deleted
        # a few lines down, so the reason must live in the caption itself
        # or it's lost forever -- this is what actually lets a real-world
        # failure get reported back and diagnosed, instead of vanishing.
        caption += "\n" + t(
            "upload_failure_note", lang, detail=esc(upload_error or "unknown")
        )

    buffer = io.BytesIO(qr_png)
    buffer.name = "qrcode.png"
    await event.client.send_file(event.chat_id, file=buffer, caption=caption, parse_mode="html")

    try:
        await status.delete()
    except Exception:
        logger.debug("Could not delete status message", exc_info=True)


async def _scan_urls(event: events.NewMessage.Event, urls: list[str], lang: str) -> None:
    """Handle scanning when replying to a text message that contains link(s)."""
    status = await _send_status(event, t("status_analyzing_link", lang))

    decoded_list = [DecodedQR(data=u.encode("utf-8", errors="ignore")) for u in urls]

    async with _build_http_client() as http_client:
        results = await _process_all(decoded_list, http_client)

    report = _format_scan_report(results, lang)
    await _deliver_report(status, report)
    await _deliver_qr_images(event, results, lang)


# --------------------------------------------------------------------------
# Module entry point
# --------------------------------------------------------------------------

def setup(client: TelegramClient) -> None:
    """Register the .qr and .scan commands (with Persian aliases) on the client."""
    client.add_event_handler(
        _handle_qr, events.NewMessage(outgoing=True, pattern=QR_PATTERN)
    )
    client.add_event_handler(
        _handle_scanqr, events.NewMessage(outgoing=True, pattern=SCANQR_PATTERN)
    )
    logger.info(
        "QR module loaded: '%s%s' and '%s%s' commands are ready.",
        COMMAND_PREFIX, "/".join(QR_COMMAND_WORDS),
        COMMAND_PREFIX, "/".join(SCAN_COMMAND_WORDS),
    )