"""
Super.py — سوپر ترک
====================
ردیابیِ گروه/کانال‌هایی که از زمان «روشن» بودنِ این قابلیت، تازه به آن‌ها
ملحق شده‌اید، و در صورت نیاز، ترکِ دسته‌جمعیِ همه‌ی آن‌ها.

⚠️ کاملاً مستقل و self-contained (دقیقاً مثل forced_join.py / mass_message.py) —
مستقیم با همان panel_state.json مشترک کار می‌کند؛ نه دیتابیس جدا (SQLite قبلی
حذف شد)، نه دستور متنی (`/سوپر ترک` و ...) — همه‌چیز از دکمه‌های پنل کنترل می‌شود:

    { سوپر ترک }
        ├─ روشن/خاموش
        ├─ لیست جوین اجباری     (نمایش گروه/کانال‌های ثبت‌شده)
        └─ ترک جوین اجباری      (ترکِ همه‌ی آن‌ها، یکجا)

⚠️ تغییرِ مهم نسبت به نسخه‌ی قبلی (چرا؟ چون توی تست واقعی کار نکرد):
نسخه‌ی قبلی سعی می‌کرد با گوش‌دادن به آپدیتِ خامِ UpdateChannelParticipant
لحظه‌ی «تازه‌عضو‌شدن» رو تشخیص بده. توی تستِ واقعی، این آپدیت برای عضویت در
کانال (broadcast) از طریق دکمه‌ی Join، به‌طور قابل‌اعتماد به سشنِ خودمون
نمی‌رسید (این رفتار، مستندِ رسمی و قطعی نیست و بین کلاینت‌ها/نسخه‌ها فرق
می‌کنه) - نتیجه: کانالی که join کردی، اصلاً ثبت نمی‌شد.

راه‌حلِ جایگزین، قابل‌اعتمادتر: به‌جای گوش‌دادن به یک نوع آپدیتِ خاص،
هر چند ثانیه یک‌بار لیستِ دیالوگ‌های فعلی رو می‌گیریم و با «چیزی که قبلاً
دیده بودیم» مقایسه می‌کنیم؛ هر دیالوگِ کانال/گروهِ *جدید* که قبلاً نبوده،
یعنی همین الان بهش join شده - این روش به هیچ فرضِ ریزی درباره‌ی کدوم آپدیتِ
خام کِی می‌رسه متکی نیست، فقط به «لیست دیالوگ‌ها»، که همیشه و برای همه‌چیز
درست کار می‌کنه. هزینه‌ش چند ثانیه تاخیر (به‌جای آنیِ‌بودن) است؛ طبق گفته‌ی
خودت («مهم نیست فلود بخوریم، فقط درست کار کنه») این معامله‌ی درستیه.

مدل داده (در panel_state.json → _global):
    super_track_enabled        : bool
    super_track_channels       : [{chat_id, title, username, kind}]   kind = "group" | "channel"
    super_track_leave_request  : {"chat_id": <چتی که باید نتیجه براش فرستاده شه>} یا None
"""

import asyncio
import json
from pathlib import Path

from telethon.errors import FloodWaitError

from core import panel_state

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

# هر چند ثانیه دیالوگ‌ها رو دوباره چک کنیم - نه زیاد کند (تشخیصِ دیرهنگام)،
# نه زیاد تند (فشار زیاد روی get_dialogs)
_POLL_INTERVAL = 8


# ===================== STATE I/O (مستقیم از panel_state.json، مثل forced_join.py) =====================

async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


async def _get_tracked() -> list:
    return (await _load_global()).get("super_track_channels", [])


# ===================== ترکِ دسته‌جمعی (وقتی از پنل «ترک جوین اجباری» زده شد) =====================

async def _leave_all(client, report_chat_id: int) -> None:
    items = await _get_tracked()
    if not items:
        try:
            await client.send_message(report_chat_id, "🤷‍♂️ لیست خالیه، چیزی برای ترک کردن نیست.")
        except Exception:
            pass
        return

    sem     = asyncio.Semaphore(5)   # هم‌زمانی امن؛ با FloodWait خودش دوباره تلاش می‌کند
    success = 0
    failed  = 0

    async def leave_one(item: dict) -> None:
        nonlocal success, failed
        async with sem:
            while True:
                try:
                    await client.delete_dialog(item["chat_id"])
                    success += 1
                    return
                except FloodWaitError as e:
                    await asyncio.sleep(e.seconds + 1)
                    continue
                except Exception:
                    failed += 1
                    return

    await asyncio.gather(*(leave_one(it) for it in items))

    # لیست ردیابی رو پاک می‌کنیم چون همه‌شون ترک شدن
    g = await _load_global()
    g["super_track_channels"] = []
    await _save_global(g)

    try:
        await client.send_message(
            report_chat_id,
            f"✅ عملیات ترک پایان یافت.\n🟢 موفق: {success}\n🔴 ناموفق: {failed}",
        )
    except Exception:
        pass


async def _leave_request_loop(client) -> None:
    """پنل با زدنِ دکمه‌ی «ترک جوین اجباری»، یک درخواست می‌گذارد؛ اینجا پردازشش می‌کنیم."""
    while True:
        try:
            g   = await _load_global()
            req = g.get("super_track_leave_request")
            if req:
                g.pop("super_track_leave_request", None)
                await _save_global(g)
                chat_id = req.get("chat_id")
                if chat_id:
                    asyncio.get_event_loop().create_task(_leave_all(client, chat_id))
        except Exception:
            pass
        await asyncio.sleep(2)


# ===================== تشخیصِ عضویتِ تازه (با مقایسه‌ی اسنپ‌شاتِ دیالوگ‌ها) =====================

async def _dialog_snapshot(client) -> dict:
    """آیدیِ marked ← {title, username, kind} برای همه‌ی کانال/گروه‌های فعلی"""
    snap = {}
    try:
        async for d in client.iter_dialogs():
            if not (d.is_channel or d.is_group):
                continue
            is_group = d.is_group or getattr(d.entity, "megagroup", False)
            snap[d.id] = {
                "title":    d.title or "بی‌نام",
                "username": getattr(d.entity, "username", None),
                "kind":     "group" if is_group else "channel",
            }
    except Exception:
        pass
    return snap


async def _poll_loop(client) -> None:
    prev_enabled  = False
    baseline_ids  = set()   # آیدی‌هایی که موقع روشن‌شدن از قبل عضوشون بودیم - این‌ها حساب نمی‌شن

    while True:
        try:
            g       = await _load_global()
            enabled = g.get("super_track_enabled", False)

            if enabled and not prev_enabled:
                # ✅ همین الان روشن شده (یا تازه استارت شده و از قبل روشن بوده):
                # اسنپ‌شاتِ فعلی رو baseline می‌گیریم که حساب نشن، و لیست رو خالی می‌کنیم
                snap = await _dialog_snapshot(client)
                baseline_ids = set(snap.keys())
                g["super_track_channels"] = []
                await _save_global(g)

            elif enabled:
                snap        = await _dialog_snapshot(client)
                tracked     = g.get("super_track_channels", [])
                tracked_ids = {t.get("chat_id") for t in tracked}
                changed     = False
                for cid, info in snap.items():
                    if cid in baseline_ids or cid in tracked_ids:
                        continue
                    tracked.append({"chat_id": cid, **info})
                    tracked_ids.add(cid)
                    changed = True
                if changed:
                    g["super_track_channels"] = tracked
                    await _save_global(g)

            prev_enabled = enabled
        except Exception:
            pass
        await asyncio.sleep(_POLL_INTERVAL)


def setup(client):
    asyncio.get_event_loop().create_task(_poll_loop(client))
    asyncio.get_event_loop().create_task(_leave_request_loop(client))