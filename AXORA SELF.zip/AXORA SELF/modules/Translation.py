"""
ماژول ترجمه برای یوزربات (Telethon)
====================================

نصب پیش‌نیاز:
    pip install telethon aiohttp

طرز استفاده در فایل اصلی یوزربات (این فایل رو به اسم Translation.py توی
پوشه‌ی modules بذار، دقیقاً کنار بقیه‌ی ماژول‌ها):
    from modules import Translation
    Translation.setup(client)

برای دقتِ حداکثری (اختیاری):
    یک متغیر محیطی به نام ANTHROPIC_API_KEY ست کن (کلید API آنتروپیک).
    اگه این مقدار موجود باشه، ترجمه اول با مدل Claude انجام می‌شه (خیلی
    دقیق‌تر و طبیعی‌تر از گوگل‌ترنسلیت، مخصوصاً برای جمله‌های محاوره‌ای/
    اصطلاحی). اگه ست نشده باشه یا به هر دلیلی خطا بده، خودکار میره سراغ
    مسیر سریعِ گوگل‌ترنسلیت. یعنی بدون هیچ کلیدی هم کامل کار می‌کنه.

دستورها (فقط از طرف خودِ اکانت اجرا می‌شن):

    ۱) حالت ریپلای — روی یک پیام ریپلای کن و بنویس:
           /ترجمه فارسی
           /ترجمه به روسی
       نتیجه: خودِ پیامِ دستور با ترجمه‌ی متنِ پیامِ ریپلای‌شده ویرایش می‌شود.

    ۲) حالت مستقیم — بدون ریپلای، متن رو جلوی زبان بنویس:
           /ترجمه چینی hi how sre you
       نتیجه: پیامِ دستور دست‌نخورده می‌مونه و ترجمه به‌صورت پیامِ جدید
       (ریپلای‌شده روی همون دستور) فرستاده می‌شه، تا متنِ اصلی از بین نره.

درباره‌ی سرعت:
    یک aiohttp.ClientSession به‌صورت واحد و مشترک بین همه‌ی درخواست‌ها نگه
    داشته می‌شه (Keep-Alive)، به‌جای اینکه هر بار یک اتصال HTTP جدید از صفر
    باز بشه. همه‌چیز هم native async هست، نه sync-در-thread، پس تاخیر اضافه‌ای
    از دیسپچ به ترد نداره.
"""

import logging
import os
import re
from typing import Optional

import aiohttp
from telethon import TelegramClient, events

logger = logging.getLogger(__name__)


# نام زبان (فارسی یا انگلیسی، حروف کوچک) -> کد زبان
LANGUAGES = {
    "فارسی": "fa", "پارسی": "fa", "farsi": "fa", "persian": "fa",
    "انگلیسی": "en", "english": "en",
    "عربی": "ar", "arabic": "ar",
    "روسی": "ru", "russian": "ru",
    "چینی": "zh-CN", "چینی ساده": "zh-CN", "chinese": "zh-CN",
    "چینی سنتی": "zh-TW",
    "فرانسوی": "fr", "french": "fr",
    "آلمانی": "de", "german": "de",
    "اسپانیایی": "es", "spanish": "es",
    "ایتالیایی": "it", "italian": "it",
    "ترکی": "tr", "turkish": "tr",
    "ژاپنی": "ja", "japanese": "ja",
    "کره ای": "ko", "کره‌ای": "ko", "korean": "ko",
    "هندی": "hi", "hindi": "hi",
    "اردو": "ur", "urdu": "ur",
    "پرتغالی": "pt", "portuguese": "pt",
    "هلندی": "nl", "dutch": "nl",
    "یونانی": "el", "greek": "el",
    "سوئدی": "sv", "swedish": "sv",
    "لهستانی": "pl", "polish": "pl",
    "اوکراینی": "uk", "ukrainian": "uk",
    "عبری": "he", "hebrew": "he",
    "تایلندی": "th", "thai": "th",
    "ویتنامی": "vi", "vietnamese": "vi",
    "اندونزیایی": "id", "indonesian": "id",
    "مالایی": "ms", "malay": "ms",
    "بنگالی": "bn", "bengali": "bn",
    "پنجابی": "pa", "punjabi": "pa",
    "رومانیایی": "ro", "romanian": "ro",
    "مجارستانی": "hu", "hungarian": "hu",
    "چکی": "cs", "czech": "cs",
    "دانمارکی": "da", "danish": "da",
    "فنلاندی": "fi", "finnish": "fi",
    "نروژی": "no", "norwegian": "no",
    "صربی": "sr", "serbian": "sr",
    "بلغاری": "bg", "bulgarian": "bg",
    "کرواتی": "hr", "croatian": "hr",
    "اسلواکی": "sk", "slovak": "sk",
    "کردی": "ku", "kurdish": "ku",
    "آذری": "az", "azerbaijani": "az",
    "ارمنی": "hy", "armenian": "hy",
    "گرجی": "ka", "georgian": "ka",
    "پشتو": "ps", "pashto": "ps",
    "تاجیکی": "tg", "tajik": "tg",
    "ازبکی": "uz", "uzbek": "uz",
    "قزاقی": "kk", "kazakh": "kk",
    "مغولی": "mn", "mongolian": "mn",
    "سواحیلی": "sw", "swahili": "sw",
    "مالایالم": "ml", "malayalam": "ml",
    "تامیلی": "ta", "tamil": "ta",
    "تلوگو": "te", "telugu": "te",
    "فیلیپینی": "tl", "filipino": "tl", "tagalog": "tl",
}

# کد زبان -> نام انگلیسیِ روون (برای دستورِ داخلی به Claude، وقتی فعال باشه)
LANGUAGE_NAMES = {
    "fa": "Persian (Farsi)", "en": "English", "ar": "Arabic", "ru": "Russian",
    "zh-CN": "Chinese (Simplified)", "zh-TW": "Chinese (Traditional)",
    "fr": "French", "de": "German", "es": "Spanish", "it": "Italian",
    "tr": "Turkish", "ja": "Japanese", "ko": "Korean", "hi": "Hindi",
    "ur": "Urdu", "pt": "Portuguese", "nl": "Dutch", "el": "Greek",
    "sv": "Swedish", "pl": "Polish", "uk": "Ukrainian", "he": "Hebrew",
    "th": "Thai", "vi": "Vietnamese", "id": "Indonesian", "ms": "Malay",
    "bn": "Bengali", "pa": "Punjabi", "ro": "Romanian", "hu": "Hungarian",
    "cs": "Czech", "da": "Danish", "fi": "Finnish", "no": "Norwegian",
    "sr": "Serbian", "bg": "Bulgarian", "hr": "Croatian", "sk": "Slovak",
    "ku": "Kurdish", "az": "Azerbaijani", "hy": "Armenian", "ka": "Georgian",
    "ps": "Pashto", "tg": "Tajik", "uz": "Uzbek", "kk": "Kazakh",
    "mn": "Mongolian", "sw": "Swahili", "ml": "Malayalam", "ta": "Tamil",
    "te": "Telugu", "tl": "Filipino (Tagalog)",
}

# /ترجمه [به] <زبان> [متنِ اختیاری]
COMMAND_RE = re.compile(r"^/ترجمه(?:\s+به)?(?:\s+(\S+))?(?:\s+([\s\S]+))?$")

USAGE_TEXT = (
    "**راهنمای دستور /ترجمه**\n\n"
    "روی یک پیام ریپلای کن و بنویس:\n`/ترجمه فارسی` یا `/ترجمه به روسی`\n\n"
    "یا بدون ریپلای، مستقیم متن بده:\n`/ترجمه چینی hi how are you`"
)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
CLAUDE_MODEL = "claude-haiku-4-5-20251001"
CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
GOOGLE_TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single"
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

_session: Optional[aiohttp.ClientSession] = None


def _normalize_fa(text: str) -> str:
    """یکسان‌سازی حروف عربی/فارسی مشابه (ي->ی ، ك->ک) که با کیبوردهای مختلف پیش میاد."""
    return text.replace("ي", "ی").replace("ك", "ک").strip()


async def _get_session() -> aiohttp.ClientSession:
    """یک session مشترک و پایدار برمی‌گردونه تا اتصال HTTP بین درخواست‌ها reuse بشه (سرعت)."""
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    return _session


async def _translate_with_claude(text: str, lang_name: str) -> Optional[str]:
    """ترجمه با Claude برای بالاترین دقت. اگه کلید ست نشده یا خطا بده، None برمی‌گردونه."""
    if not ANTHROPIC_API_KEY:
        return None
    try:
        session = await _get_session()
        async with session.post(
            CLAUDE_API_URL,
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": CLAUDE_MODEL,
                "max_tokens": 1024,
                "system": (
                    f"You are a professional translator. Translate the user's message into "
                    f"{lang_name} with complete accuracy, preserving tone, register, and "
                    f"nuance. Reply with ONLY the translated text - no notes, no quotation "
                    f"marks, no explanations, nothing else."
                ),
                "messages": [{"role": "user", "content": text}],
            },
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 200:
                body = await resp.text()
                logger.warning("Claude translate failed (%s): %s", resp.status, body[:300])
                return None
            data = await resp.json()
            return data["content"][0]["text"].strip()
    except Exception as exc:
        logger.warning("Claude translate raised, falling back to Google: %s", exc)
        return None


async def _translate_with_google(text: str, target_code: str) -> str:
    """مسیر سریع و رایگان: تماس async مستقیم با گوگل‌ترنسلیت، با اتصال reuse شده."""
    session = await _get_session()
    params = {"client": "gtx", "sl": "auto", "tl": target_code, "dt": "t", "q": text}
    async with session.get(
        GOOGLE_TRANSLATE_URL,
        params=params,
        headers={"User-Agent": _USER_AGENT},
        timeout=aiohttp.ClientTimeout(total=8),
    ) as resp:
        resp.raise_for_status()
        data = await resp.json(content_type=None)
        return "".join(chunk[0] for chunk in data[0] if chunk[0])


async def translate_text(text: str, target_code: str, target_name: str) -> str:
    """اول (در صورت فعال بودن) Claude برای دقت، بعد fallback به گوگل برای سرعت/پایداری."""
    result = await _translate_with_claude(text, target_name)
    if result:
        return result
    return await _translate_with_google(text, target_code)


def setup(client: TelegramClient):
    """پلاگین ترجمه. کافیه یک‌بار Translation.setup(client) صدا زده بشه."""

    @client.on(events.NewMessage(outgoing=True, pattern=COMMAND_RE))
    async def _translate(event):
        match = event.pattern_match
        lang_raw = match.group(1)
        inline_text = (match.group(2) or "").strip()

        if not lang_raw:
            await event.edit(USAGE_TEXT)
            return

        target_code = LANGUAGES.get(_normalize_fa(lang_raw).lower())
        if not target_code:
            await event.edit(f"زبان «{lang_raw}» رو نشناختم.\n\n{USAGE_TEXT}")
            return
        target_name = LANGUAGE_NAMES.get(target_code, target_code)

        reply_text = None
        if event.is_reply:
            reply_msg = await event.get_reply_message()
            if reply_msg:
                reply_text = reply_msg.raw_text

        if inline_text:
            source_text = inline_text
        elif reply_text:
            source_text = reply_text
        else:
            await event.edit(f"متنی برای ترجمه پیدا نکردم.\n\n{USAGE_TEXT}")
            return

        try:
            translated = await translate_text(source_text, target_code, target_name)
        except Exception as exc:
            await event.edit(f"خطا در ترجمه: {exc}")
            return

        if not translated:
            await event.edit("ترجمه‌ای برنگشت، دوباره امتحان کن.")
            return

        if inline_text:
            # متنِ اصلی همین‌جا توی خودِ دستور بود -> دستور دست‌نخورده می‌مونه
            # و ترجمه به‌عنوان یک پیامِ جدید (ریپلای روی دستور) فرستاده می‌شه.
            await event.reply(translated, parse_mode=None)
        else:
            # متن از پیامِ ریپلای‌شده اومد و همون‌جا محفوظه -> خودِ پیامِ
            # دستور رو می‌شه با خیال راحت با ترجمه جایگزین کرد.
            await event.edit(translated, parse_mode=None)