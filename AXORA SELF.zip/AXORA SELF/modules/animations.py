import asyncio
import logging
import re

from telethon import events, errors
from telethon.tl.functions.messages import SendReactionRequest
from telethon.tl.types import ReactionEmoji, ReactionCustomEmoji

logger = logging.getLogger("animations")

# ============================================================================
# ثابت‌ها
# ============================================================================

NUMBER_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣",
                 "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]

MAX_SECONDS  = 120   # سقف ثانیه برای انیمیشن‌ها

# ساختار ذخیره‌سازی ری‌اکشن‌ها
_reaction_targets: dict = {}
_global_chat_reactions: dict = {}


# ============================================================================
# ابزارها
# ============================================================================

async def safe_edit(msg, text: str) -> bool:
    """ویرایش امن با مدیریت FloodWait، افکت باکس مونوپیس و امضای بولد-ایتالیک تیتان"""
    formatted_text = f"```{text}```\n\n**__AXoRA SelF__**"
    for _ in range(3):
        try:
            await msg.edit(formatted_text, parse_mode='markdown')
            return True
        except errors.FloodWaitError as e:
            await asyncio.sleep(e.seconds + 1)
        except errors.MessageNotModifiedError:
            return True   
        except Exception:
            return False
    return False

def split_emojis(s: str) -> list:
    """تقسیم رشته ایموجی به واحدهای مجزا"""
    result, buf = [], ""
    for ch in s:
        cp = ord(ch)
        is_modifier = (
            cp == 0x200D                  
            or 0xFE00 <= cp <= 0xFE0F    
            or 0x1F3FB <= cp <= 0x1F3FF  
            or 0x20D0 <= cp <= 0x20FF    
        )
        if is_modifier:
            buf += ch
        else:
            if buf:
                result.append(buf)
            buf = ch
    if buf:
        result.append(buf)
    return [c for c in result if not c.isspace()]


def parse_reaction_emoji(emoji_str: str):
    """تشخیص ایموجی عادی یا پرمیوم (سفارشی)"""
    if emoji_str.isdigit():
        return ReactionCustomEmoji(document_id=int(emoji_str))
    return ReactionEmoji(emoticon=emoji_str)


# ============================================================================
# setup
# ============================================================================

def setup(client):

    # ─────────────────────────────────────────────────────────────────────────
    # ۱. حالت تایپ دونه دونه حروف:  /متن N  یا  متن N
    # ─────────────────────────────────────────────────────────────────────────
    @client.on(events.NewMessage(outgoing=True, pattern=r'(?i)^(?:/)?متن\s+(\d+)(?:\s+(.+))?$'))
    async def type_animation_handler(event):
        seconds = min(int(event.pattern_match.group(1)), MAX_SECONDS)
        text = event.pattern_match.group(2)

        # اگر متن جلوش نبود، چک کنه ببینه روی پیامی ریپلای شده یا نه
        if not text and event.is_reply:
            replied = await event.get_reply_message()
            text = replied.text
        
        if not text:
            await safe_edit(event.message, "⚠️ لطفا متن رو وارد کنید یا روی یک پیام متنی ریپلای کنید.")
            return

        text = text.strip()
        await event.delete()

        # ارسال پیام اولیه خالی جهت شروع افکت تایپ
        current_text = ""
        msg = await event.respond("✍️...")
        
        # محاسبه زمان تاخیر بین هر کاراکتر بر اساس ثانیه درخواستی
        delay = max(seconds / len(text), 0.05)

        for char in text:
            current_text += char
            await safe_edit(msg, current_text + "▒")
            await asyncio.sleep(delay)
        
        # نمایش نهایی متن بدون نشانگر تایپ
        await safe_edit(msg, text)


    # ─────────────────────────────────────────────────────────────────────────
    # ۲. نمایش ترتیبی / شمارنده عددی (اول عددها، بعد یهو ایموجی)
    # ─────────────────────────────────────────────────────────────────────────
    @client.on(events.NewMessage(outgoing=True, pattern=r'(?i)^(?:/)?نمایش\s+(\S+)\s+در\s+(\d+)\s*ثانیه\s*$'))
    async def display_sequence_handler(event):
        raw     = event.pattern_match.group(1).strip()
        seconds = min(int(event.pattern_match.group(2)), MAX_SECONDS)

        emojis = split_emojis(raw)

        if len(emojis) >= 2:
            # حالت ترتیبی ایموجی‌ها پشت سر هم
            for emoji in emojis:
                await safe_edit(event.message, emoji)
                await asyncio.sleep(seconds)
        else:
            # حالت شمارنده عددی درخواستی شما: اول معکوس شمارش میکنه بعد یهو ایموجی رو میده
            base  = emojis[0] if emojis else raw
            count = min(seconds, len(NUMBER_EMOJIS))
            
            for i in range(count):
                await safe_edit(event.message, f"{NUMBER_EMOJIS[i]}")
                await asyncio.sleep(1)
            
            # نمایش یهویی ایموجی اصلی پس از پایان شمارش
            await safe_edit(event.message, base)


    # ─────────────────────────────────────────────────────────────────────────
    # ۳. فعال / غیرفعال کردن ری‌اکشن خودکار (پرمیوم هوشمند + کانال و گروه)
    # ─────────────────────────────────────────────────────────────────────────
    @client.on(events.NewMessage(outgoing=True, pattern=r'(?i)^(?:/)?(?:ری\s*اکشن|reaction)\s+(\S+)\s*$'))
    async def set_reaction_handler(event):
        emoji = event.pattern_match.group(1).strip()
        chat_id = event.chat_id

        # وضعیت خاموش کردن ری‌اکشن در این چت
        if emoji.lower() in ("off", "خاموش", "لغو"):
            # حذف از لیست همگانی چت
            _global_chat_reactions.pop(chat_id, None)
            
            # حذف کاربر ریپلای شده (اگر ریپلای وجود داشت)
            if event.is_reply:
                replied = await event.get_reply_message()
                if replied and replied.sender_id:
                    _reaction_targets.pop(replied.sender_id, None)
            
            await safe_edit(event.message, "🔕 تنظیمات ری‌اکشن خودکار اعمال شده در این بخش لغو شد.")
            return

        # حالت اول: ریپلای روی پیام یک شخص یا ریپلای روی لینک چت/کانال
        if event.is_reply:
            replied = await event.get_reply_message()
            if not replied:
                await safe_edit(event.message, "⚠️ پیام ریپلای شده معتبر نیست.")
                return

            # بررسی اینکه آیا متن ریپلای شده حاوی لینک یا آیدی کانال/گروه است؟
            text_to_check = replied.text or ""
            mention_match = re.search(r'(?:t\.me\/|@)([a-zA-Z0-9_]{5,})', text_to_check)
            
            if mention_match:
                target_peer = mention_match.group(1)
                try:
                    target_entity = await client.get_entity(target_peer)
                    _global_chat_reactions[target_entity.id] = emoji
                    await safe_edit(event.message, f"📢 ری‌اکشن خودکار {emoji} روی تمام پیام‌های چت/کانال `{target_entity.title}` فعال شد.")
                    return
                except Exception:
                    pass 

            # ریپلای روی کاربر معمولی
            if replied.sender_id:
                _reaction_targets[replied.sender_id] = emoji
                await safe_edit(event.message, f"✅ ری‌اکشن خودکار {emoji} روی پیام‌های این کاربر قفل شد.")
                return
            else:
                await safe_edit(event.message, "⚠️ شناسه کاربر یافت نشد.")
                return

        # حالت دوم: بدون ریپلای (قفل کردن ری‌اکشن همگانی روی کل گروه/کانال فعلی)
        else:
            _global_chat_reactions[chat_id] = emoji
            await safe_edit(event.message, f"👥 ری‌اکشن خودکار {emoji} روی **تمامی پیام‌های ارسالی این چت** فعال شد.")


    # ─────────────────────────────────────────────────────────────────────────
    # ۴. پردازشگر اصلی اعمال ری‌اکشن خودکار روی پیام‌های جدید ورودی
    # ─────────────────────────────────────────────────────────────────────────
    @client.on(events.NewMessage(incoming=True))
    async def auto_react_handler(event):
        chat_id = event.chat_id
        sender_id = event.sender_id
        chosen_emoji = None

        # اولویت اول: آیا کل این چت/گروه/کانال تحت رصد ری‌اکشن همگانی هست؟
        if chat_id in _global_chat_reactions:
            chosen_emoji = _global_chat_reactions[chat_id]
        
        # اولویت دوم: آیا فرد ارسال کننده پیام به صورت اختصاصی تحت رصد هست؟
        elif sender_id in _reaction_targets:
            chosen_emoji = _reaction_targets[sender_id]

        if not chosen_emoji:
            return

        try:
            # پارس کردن ری‌اکشن جهت پشتیبانی کامل از اموجی‌های عادی و پرمیوم سفارشی
            reaction_object = parse_reaction_emoji(chosen_emoji)
            
            await client(SendReactionRequest(
                peer=event.chat_id,
                msg_id=event.id,
                reaction=[reaction_object],
            ))
        except Exception as e:
            logger.debug(f"خطا در ارسال ری‌اکشن خودکار: {e}")

    logger.info("ماژول animations با امکانات جدید با موفقیت لود شد ✅")