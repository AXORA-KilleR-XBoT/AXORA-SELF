import json
from pathlib import Path
from datetime import datetime, timedelta
from telethon import events
from telethon.tl.types import MessageMediaPhoto, MessageMediaDocument
from config import settings
from core.state import state
from core import panel_state

_client_ref = None
_my_id: int | None = None

async def _get_my_id() -> int:
    global _my_id
    if _my_id is None and _client_ref is not None:
        try:
            _my_id = (await _client_ref.get_me()).id
        except Exception:
            return 0
    return _my_id or 0

try:
    from modules.panel import log_deleted_message
except ImportError:
    async def log_deleted_message(user_id, name="", username=""): pass
# ✅ جدید: همون panel_state.json که پنل می‌نویسه - برای خوندنِ روشن/خاموش و زبان
_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

_ANTI_DELETE_SIGNATURE = "**__AXoRA SelF__**"


async def _load_panel_data() -> dict:
    """✅ عملکرد: قبلاً سنکرون بود - هر پیامِ حذف/ویرایش‌شده (هر خروجی/ورودی
    که این ماژول می‌بینه) کل event loop رو تا خوندنِ فایل بلاک می‌کرد. فقط
    خواندنه، نیازی به transaction نیست - از قفلِ core/panel_state.py رد می‌شه
    تا وسطِ نوشتنِ یه ماژولِ دیگه، نصفه‌ونیمه نخونه."""
    return await panel_state.load()


async def _is_anti_delete_enabled() -> bool:
    return (await _load_panel_data()).get(str(await _get_my_id()), {}).get("_global", {}).get("anti_delete_enabled", False)


async def _report_lang_is_fa() -> bool:
    """زبانِ گزارش از تنظیمِ زبانِ پنل، دقیقاً برای همون چتِ گزارش خونده می‌شه -
    یعنی اگه پنل توی آن چت روی English باشه، گزارش انگلیسی می‌شه، وگرنه فارسی."""
    try:
        chat_state = (await _load_panel_data()).get(str(await _get_my_id()), {}).get(str(settings.REPORT_CHAT_ID_ANTI), {})
        return chat_state.get("lang", "fa") == "fa"
    except Exception:
        return True


def _is_sendable_media(media) -> bool:
    """فقط عکس و داکیومنت (که ویس/ویدیو/فایل/استیکر/گیف/ویدیوی گرد هم زیرمجموعه‌شون
    محسوب می‌شن) واقعاً با send_file قابل ارسالِ دوباره‌ن. پیش‌نمایشِ لینک، لوکیشن،
    مخاطب، نظرسنجی و... فایلِ واقعی برای فرستادن ندارن، پس اونا رو متنی گزارش می‌کنیم."""
    return isinstance(media, (MessageMediaPhoto, MessageMediaDocument))


def _media_id(media):
    """یه شناسه‌ی پایدار از مدیا می‌سازه تا تشخیصِ «مدیا موقعِ ویرایش عوض شده یا نه»
    درست باشه؛ مقایسه‌ی مستقیمِ آبجکت‌ها گاهی به‌خاطرِ تغییرِ file_reference بینِ
    دو فچ، اشتباهی «تغییر کرده» گزارش می‌شه."""
    if isinstance(media, MessageMediaPhoto) and media.photo:
        return ("photo", media.photo.id)
    if isinstance(media, MessageMediaDocument) and media.document:
        return ("document", media.document.id)
    return type(media).__name__ if media else None


def _safe_caption(text: str, limit: int = 1024) -> str:
    """کپشنِ مدیا توی تلگرام حداکثر ۱۰۲۴ کاراکتره؛ اگه رد بشه ارسال fail می‌کنه،
    پس در صورتِ نیاز کوتاهش می‌کنیم تا گزارش همیشه با موفقیت بره."""
    if limit <= 0:
        return ""
    if len(text) <= limit:
        return text
    return text[: max(limit - 1, 0)] + "…"


# مدت زمانی که یک پیام پی‌وی برای تشخیص حذف/ویرایش در حافظه نگه داشته می‌شود.
# بدون این، state.saved_messages تا ابد بزرگ‌تر می‌شد (memory leak).
SAVED_MSG_TTL = timedelta(hours=24)
_PRUNE_INTERVAL = timedelta(minutes=5)
_last_prune = datetime.min


def _prune_saved_messages():
    """پیام‌های قدیمی‌تر از SAVED_MSG_TTL را از حافظه حذف می‌کند.
    برای جلوگیری از اسکن کامل دیکشنری روی هر پیام، این کار حداکثر هر
    چند دقیقه یک‌بار اجرا می‌شود (throttle)."""
    global _last_prune
    now = datetime.now()
    if now - _last_prune < _PRUNE_INTERVAL:
        return
    _last_prune = now

    expired = [mid for mid, data in state.saved_messages.items()
               if now - data["time"] > SAVED_MSG_TTL]
    for mid in expired:
        del state.saved_messages[mid]


# ===================== CODE 1 (DELETE + UNDO) =====================
@events.register(events.NewMessage(outgoing=True, pattern=r"^([حح]ذف|\!del)\s*(\d+)?$"))
async def _delete_upwards(event):
    client = event.client
    count = int(event.pattern_match.group(2) or 5)
    if not 1 <= count <= 500:
        await event.edit("```❌ عدد باید بین ۱ تا ۵۰۰ باشه```\n\n**__AXoRA SelF__**")
        return

    chat_id = event.chat_id
    # پیام outgoing است، یعنی فرستنده همیشه خودمونیم -> نیازی به get_me() نیست
    my_id = event.sender_id
    to_delete = []

    reply = await event.get_reply_message()
    if reply:
        async for msg in client.iter_messages(chat_id, max_id=reply.id + 1, limit=count + 50):
            if len(to_delete) >= count:
                break
            if msg.sender_id == my_id or event.is_private:
                to_delete.append(msg)
    else:
        # ✅ فیکسِ باگ: offset_id=event.id باعث می‌شه خودِ پیامِ دستور («حذف 10») از
        # نتیجه کنار گذاشته بشه. قبلاً چون این پیام تازه‌ترین پیامِ «me» توی همون چت
        # بود، جزوِ همون count تا حساب می‌شد و در عمل یکی کمتر از عددِ خواسته‌شده پاک
        # می‌شد. بافرِ count+20 دست نخورده موند چون توی پی‌وی، فیلترِ from_user سمتِ
        # کلاینت انجام می‌شه نه سرور (تلگرام from_id رو توی پی‌وی نادیده می‌گیره)،
        # پس این بافر همون نقشِ قبلیش رو برای کم‌کردنِ رفت‌وبرگشت‌های اضافه داره.
        async for msg in client.iter_messages(chat_id, from_user="me", offset_id=event.id, limit=count + 20):
            if len(to_delete) >= count:
                break
            to_delete.append(msg)

    if not to_delete:
        await event.edit("```❌ پیامی برای حذف پیدا نشد!```\n\n**__AXoRA SelF__**")
        return

    await client.delete_messages(chat_id, to_delete)
    state.last_deleted[chat_id] = {"msgs": to_delete, "time": datetime.now()}
    await event.delete()


def setup_delete_undo(client):
    client.add_event_handler(_delete_upwards)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^(برگرد|undo)$"))
    async def undo(event):
        chat_id = event.chat_id
        data = state.last_deleted.get(chat_id)
        if not data:
            await event.edit("```❌ چیزی برای برگرداندن نیست!```\n\n**__AXoRA SelF__**")
            return

        if (datetime.now() - data["time"]).total_seconds() > 20:
            del state.last_deleted[chat_id]
            await event.edit("```⏰ مهلت 20 ثانیه تموم شد!```\n\n**__AXoRA SelF__**")
            return

        restored = 0
        for msg in reversed(data["msgs"]):
            try:
                # ✅ همون فیکسِ پیش‌نمایشِ لینک اینجا هم اعمال شد: قبلاً با یه
                # msg.media ساده چک می‌شد که برای MessageMediaWebPage (لینک) هم
                # True بود و send_file روش fail می‌کرد و اون پیام اصلاً برنمی‌گشت.
                if _is_sendable_media(msg.media):
                    await client.send_file(chat_id, msg.media, caption=msg.message or "")
                elif msg.message:
                    await client.send_message(chat_id, msg.message)
                restored += 1
            except Exception:
                pass

        await client.send_message(chat_id, f"```✅ {restored} پیام برگشت!```\n\n**__AXoRA SelF__**")
        del state.last_deleted[chat_id]
        await event.delete()


# ===================== CODE 2 (ANTI DELETE/EDIT PV) =====================
def setup_anti_delete_pv(client):
    @client.on(events.NewMessage(incoming=True))
    async def save_pv(event):
        if not event.is_private:
            return
        sender = await event.get_sender()
        if sender and not sender.bot:
            state.saved_messages[event.id] = {
                "msg": event.message,
                "text": event.message.message or "[Media]",
                "time": datetime.now(),
                "chat_id": event.chat_id,
                # کش کردن اطلاعات فرستنده همین‌جا تا موقع حذف/ویرایش
                # لازم نباشه دوباره get_entity/get_sender صدا بزنیم
                "first_name": sender.first_name,
                "username": sender.username,
                "sender_id": sender.id,
            }
            _prune_saved_messages()

    @client.on(events.MessageDeleted)
    async def anti_delete_pv(event):
        if not await _is_anti_delete_enabled():
            return
        fa = await _report_lang_is_fa()

        for msg_id in event.deleted_ids or []:
            data = state.saved_messages.pop(msg_id, None)
            if not data:
                continue

            name = data["first_name"] or "Unnamed"
            username = f"@{data['username']}" if data["username"] else "—"
            sender_id = data["sender_id"]
            await log_deleted_message(sender_id, data["first_name"] or "", data["username"] or "")
            send_time = data["time"].strftime("%H:%M:%S - %Y/%m/%d")
            delete_time = datetime.now().strftime("%H:%M:%S - %Y/%m/%d")

            header = (
                f"Message deleted\n\n"
                f"Name: {name}\n"
                f"Username: {username}\n"
                f"ID: `{sender_id}`\n\n"
                f"Sent at: {send_time}\n"
                f"Deleted at: {delete_time}\n\n"
            )
            caption_label = "Message:\n"
            text_label = "Message:\n"
            fail_label = "Report failed: "

            footer = f"\n\n{_ANTI_DELETE_SIGNATURE}"
            media = data["msg"].media

            try:
                # ✅ فیکس: قبلاً هر مدیایی (از جمله پیش‌نمایشِ لینک) با send_file
                # فرستاده می‌شد و برای لینک‌ها fail می‌کرد و می‌رفت تو حالتِ
                # «گزارش نشد». حالا فقط فایلِ واقعی (عکس/ویس/ویدیو/سند/استیکر/گیف)
                # با send_file می‌ره، بقیه (لینک، لوکیشن، مخاطب، نظرسنجی...)
                # به‌صورتِ متنی که خودِ لینک/محتوا توشه گزارش می‌شن.
                if _is_sendable_media(media):
                    caption = header + (f"{caption_label}{data['text']}" if data["text"] != "[Media]" else "")
                    await client.send_file(
                        settings.REPORT_CHAT_ID_ANTI,
                        media,
                        caption=_safe_caption(caption or header, 1024 - len(footer)) + footer,
                    )
                else:
                    await client.send_message(settings.REPORT_CHAT_ID_ANTI, header + f"{text_label}{data['text']}" + footer)
            except Exception as e:
                await client.send_message(settings.REPORT_CHAT_ID_ANTI, header + f"{fail_label}{str(e)[:100]}" + footer)

    @client.on(events.MessageEdited(incoming=True))
    async def anti_edit_pv(event):
        old = state.saved_messages.get(event.id)
        if not event.is_private or not old:
            return
        if not await _is_anti_delete_enabled():
            return

        new_text = event.message.message or "[Media]"
        new_media = event.message.media
        if old["text"] == new_text and _media_id(old["msg"].media) == _media_id(new_media):
            return

        username = f"@{old['username']}" if old["username"] else "—"
        sent_time = old["time"].strftime("%H:%M:%S - %Y/%m/%d")
        edited_time = datetime.now().strftime("%H:%M:%S - %Y/%m/%d")

        body = (
            f"Message edited\n\n"
            f"Username: {username}\n"
            f"ID: `{old['sender_id']}`\n\n"
            f"Sent at: {sent_time}\n\n"
            f"Previous message:\n{old['text']}\n\n"
            f"Edited at: {edited_time}\n\n"
            f"New message:\n{new_text}\n"
        )
        footer = f"\n{_ANTI_DELETE_SIGNATURE}"

        try:
            # ✅ فیکس: قبلاً توی گزارشِ ویرایش، مدیا اصلاً فرستاده نمی‌شد (فقط متنِ
            # قبل/بعد می‌رفت). حالا اگه مدیای واقعی (غیر از پیش‌نمایشِ لینک) داشته
            # باشه، خودِ فایل رو هم به‌همراهِ کپشنِ قبل/بعد می‌فرسته.
            if _is_sendable_media(new_media):
                await client.send_file(
                    settings.REPORT_CHAT_ID_ANTI,
                    new_media,
                    caption=_safe_caption(body, 1024 - len(footer)) + footer,
                )
            else:
                await client.send_message(settings.REPORT_CHAT_ID_ANTI, body + footer, parse_mode="md")
        except Exception:
            pass

        old.update({
            "text": new_text,
            "msg": event.message,
            "time": datetime.now()
        })
# ===================== FINAL (ONE SETUP) =====================
def setup(client):
    global _client_ref
    _client_ref = client
    setup_delete_undo(client)
    setup_anti_delete_pv(client)