import asyncio
import json
from pathlib import Path

from telethon import events, functions
from telethon.tl import types

from core import panel_state

_client_ref = None
_my_id: int | None = None

async def _get_my_id() -> int:
    global _my_id
    if _my_id is None and _client_ref is not None:
        try:
            _my_id = (await _client_ref.get_me()).id
        except Exception:
            return 0
    return _my_id or 0

# ✅ همون JSON که panel_bot.py می‌نویسه
_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

enabled = False
task = None
allowed_hashes = set()
control_lock = asyncio.Lock()
_prev_shield = False   # برای ردیابی تغییر وضعیت سپر امنیتی

CHECK_EVERY = 2  # seconds


def normalize_text(text: str) -> str:
    text = (text or "").strip().lower()
    text = text.replace("ي", "ی").replace("ك", "ک")
    text = " ".join(text.split())
    return text


async def _is_shield_on() -> bool:
    """خواندن سپر امنیتی از تنظیمات سراسری.
    ✅ عملکرد: این تابع هر ۲ ثانیه از guard_loop صدا زده می‌شه - یعنی همیشه،
    نه فقط وقتی کاربر کاری می‌کنه. قبلاً سنکرون بود، یعنی تا وقتی ربات روشنه
    هر ۲ ثانیه یه بار کل event loop رو تا خوندنِ فایل بلاک می‌کرد."""
    try:
        data = await panel_state.load()
        return data.get(str(await _get_my_id()), {}).get("_global", {}).get("shield_enabled", False)
    except Exception:
        return False


async def get_authorizations(client):
    auths = await client(functions.account.GetAuthorizationsRequest())
    return auths.authorizations


async def revoke_new_sessions(client):
    global allowed_hashes
    async with control_lock:
        hashes_snapshot = set(allowed_hashes)
    auths = await get_authorizations(client)
    revoked = 0
    for auth in auths:
        if auth.current:
            continue
        if auth.hash in hashes_snapshot:
            continue
        try:
            await client(functions.account.ResetAuthorizationRequest(hash=auth.hash))
            revoked += 1
        except Exception:
            pass
    return revoked


async def guard_loop(client):
    global enabled, allowed_hashes, _prev_shield
    while True:
        try:
            shield_now = await _is_shield_on()

            # ── سپر تازه روشن شد (OFF → ON) ──────────────────────
            if shield_now and not _prev_shield:
                current_auths = await get_authorizations(client)
                async with control_lock:
                    allowed_hashes = {a.hash for a in current_auths}
                    enabled = True
                _prev_shield = True

            # ── سپر تازه خاموش شد (ON → OFF) ─────────────────────
            elif not shield_now and _prev_shield:
                async with control_lock:
                    enabled = False
                _prev_shield = False

            # ── اگه فعاله، سشن های جدید رو قطع کن ───────────────
            if enabled:
                await revoke_new_sessions(client)

        except Exception:
            pass
        await asyncio.sleep(CHECK_EVERY)


def setup(client):
    global task, enabled, allowed_hashes

    @client.on(events.NewMessage(outgoing=True))
    async def anti_log_commands(event):
        global enabled, allowed_hashes

        text = normalize_text(event.raw_text or "")

        # ── دستورات دستی (مستقل از پنل) ───────────────────────────
        if text in {"لاگ روشن", "/لاگ روشن", "log on", "/log on", "antilog on", "/antilog on"}:
            await event.delete()
            current_auths = await get_authorizations(client)
            async with control_lock:
                allowed_hashes = {a.hash for a in current_auths}
                enabled = True
            await client.send_message(
                event.chat_id,
                f"آنتی لاگ روشن شد.\n{len(allowed_hashes)} سشن فعلی ذخیره شد.\nاز الان فقط سشن های جدید قطع میشن.",
            )
            return

        if text in {"لاگ خاموش", "/لاگ خاموش", "log off", "/log off", "antilog off", "/antilog off"}:
            async with control_lock:
                enabled = False
            await event.delete()
            await client.send_message(
                event.chat_id,
                "آنتی لاگ خاموش شد.\nتا وقتی خاموشه به سشن های قبلی کاری نداره.",
            )
            return

    @client.on(events.Raw)
    async def anti_log_new_auth(event):
        """واکنش فوری به اتصال جدید - بدون انتظار برای حلقه"""
        if not enabled:
            return
        if isinstance(event, types.UpdateNewAuthorization):
            try:
                await revoke_new_sessions(client)
            except Exception:
                pass

    if task is None or task.done():
        task = asyncio.create_task(guard_loop(client))

def setup(client):
    global _client_ref
    _client_ref = client