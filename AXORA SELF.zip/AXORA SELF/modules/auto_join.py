from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import parse_qs, urlparse

from telethon import events, types, utils
from telethon.errors import BotResponseTimeoutError, FloodWaitError
from telethon.tl.functions.channels import (
    GetParticipantRequest,
    JoinChannelRequest,
    LeaveChannelRequest,
)
from telethon.tl.functions.messages import (
    CheckChatInviteRequest,
    DeleteChatUserRequest,
    GetBotCallbackAnswerRequest,
    ImportChatInviteRequest,
)

log = logging.getLogger(__name__)
if not log.handlers:
    _stream = logging.StreamHandler()
    _stream.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(_stream)
    log.setLevel(logging.INFO)
    log.propagate = False

MAX_JOIN_PER_RUN = 20
CALLBACK_WAIT_SECONDS = 4.0
PENDING_WAIT_SECONDS = 1.5
RECENT_JOIN_SECONDS = 180
LEAVE_RETRIES = 3
LEAVE_DELAY_SECONDS = 6.0
HISTORY_LIMIT = 15
PROMPT_SPAN = 8
LEAVE_CONCURRENCY = 5
DIALOG_LIST_TIMEOUT = 8.0
PENDING_POLL_SECONDS = 2.0
PENDING_POLL_MAX_SECONDS = 20.0
PENDING_MAX_WAIT_SECONDS = 600.0
FLOOD_MAX_SLEEP_SECONDS = 900.0
LEAVE_MAX_SECONDS = 1200.0
_ALREADY_OUT = ("UserNotParticipant", "USER_NOT_PARTICIPANT")

_COMMAND_RE = re.compile(r"^(?:/ko|/?عضو\s+خودکار)(?:@\w+)?\s*$", re.IGNORECASE)
_CONFIRM_RE = re.compile(
    r"(تایید|تأیید|عضو\s*شدم|بررسی(?:\s*عضویت|\s*کردم)?|ادامه|"
    r"check|verify|joined|i\s*am\s*joined|i.?ve\s*joined)",
    re.IGNORECASE,
)
_URL_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(?:t\.me|telegram\.me)/[^\s<>\"']+"
    r"|tg://join\?invite=[A-Za-z0-9_-]+",
    re.IGNORECASE,
)
_SCHEME_RE = re.compile(r"^https?://", re.IGNORECASE)
_USERNAME_RE = re.compile(r"[A-Za-z0-9_]{5,32}")
_TRAILING = ".,!?;:،؛)]}>\"'"
_HOSTS = frozenset({"t.me", "www.t.me", "telegram.me", "www.telegram.me"})
_SKIP = frozenset({"c", "s", "addlist", "proxy", "share", "iv"})

_active: Set[int] = set()
_registered: Set[int] = set()
_tasks: Set[asyncio.Future] = set()

Target = Tuple[str, str]
Key = Tuple[str, int]


class _Session:
    __slots__ = ("joined", "pending", "mark", "baseline", "attempts")

    def __init__(self) -> None:
        self.joined: Dict[Key, Any] = {}
        self.pending: List[Tuple[str, Any]] = []
        self.mark: float = asyncio.get_running_loop().time()
        self.baseline: Optional[Set[int]] = None
        self.attempts: int = 0


def setup(client: Any) -> None:
    key = id(client)
    if key in _registered:
        return
    client.add_event_handler(
        _handler,
        events.NewMessage(outgoing=True, pattern=_COMMAND_RE),
    )
    _registered.add(key)


def _spawn(coro: Any) -> None:
    task = asyncio.ensure_future(coro)
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def _silent_delete(event: Any) -> None:
    try:
        await event.delete()
    except Exception:
        pass


def _note(value: str, text: str) -> None:
    log.info("auto_join: %s -> %s", value, text)


def _is(exc: Exception, *tokens: str) -> bool:
    text = type(exc).__name__ + " " + str(getattr(exc, "message", ""))
    return any(token in text for token in tokens)


async def _handler(event: Any) -> None:
    if not event.is_private:
        return

    peer_id = int(event.chat_id)

    try:
        chat = await event.get_chat()
        peer = await event.get_input_chat()
    except Exception:
        return

    _spawn(_silent_delete(event))

    if not getattr(chat, "bot", False) or peer_id in _active:
        return

    client = event.client
    session = _Session()
    _active.add(peer_id)
    try:
        await _join_and_confirm(client, peer, session)
    except Exception:
        log.exception("auto_join: flow failed")
    finally:
        _active.discard(peer_id)

    if session.baseline is None and not session.joined and not session.pending:
        log.info("auto_join: nothing to leave")
        return

    log.info(
        "auto_join: joined %d, waiting for approval %d",
        len(session.joined),
        len(session.pending),
    )
    await _leave_session(client, session)


async def _join_and_confirm(client: Any, peer: Any, session: _Session) -> None:
    history = await client.get_messages(peer, limit=HISTORY_LIMIT)

    prompts = []
    for message in history:
        if message.out:
            continue
        targets, button = _scan(message)
        if targets or button is not None:
            prompts.append((message, targets, button))

    if not prompts:
        log.info("auto_join: no join links or confirm button in the last %d messages", HISTORY_LIMIT)
        return

    newest = max(item[0].id for item in prompts)
    prompts = [item for item in prompts if newest - item[0].id <= PROMPT_SPAN]

    unique: List[Target] = []
    seen: Set[Target] = set()
    for _msg, targets, _btn in reversed(prompts):
        for target in targets:
            if target not in seen:
                seen.add(target)
                unique.append(target)

    if unique:
        targets = unique[:MAX_JOIN_PER_RUN]
        session.attempts = len(targets)
        dialogs = await _dialog_map(client)
        session.baseline = None if dialogs is None else set(dialogs)
        await asyncio.gather(*(_join(client, kind, value, session) for kind, value in targets))

    if session.pending:
        await asyncio.sleep(PENDING_WAIT_SECONDS)

    session.mark = asyncio.get_running_loop().time()

    presses = [_press(client, peer, msg, btn) for msg, _t, btn in prompts if btn is not None]
    if presses:
        await asyncio.gather(*presses)


async def _join(client: Any, kind: str, value: str, session: _Session) -> None:
    try:
        if kind == "invite":
            await _join_invite(client, value, session)
        else:
            await _join_public(client, value, session)
    except Exception as exc:
        log.warning("auto_join: join failed for %s (%s)", value, type(exc).__name__)


async def _join_invite(client: Any, value: str, session: _Session) -> None:
    try:
        result = await client(ImportChatInviteRequest(value))
    except Exception as exc:
        if _is(exc, "InviteRequestSent", "INVITE_REQUEST_SENT"):
            session.pending.append(("invite", value))
            _note(value, "waiting for approval")
        elif _is(exc, "UserAlreadyParticipant", "USER_ALREADY_PARTICIPANT"):
            await _adopt_recent(client, value, await _invite_chat(client, value), session)
        else:
            raise
        return

    for chat in getattr(result, "chats", None) or ():
        if getattr(chat, "min", False) or getattr(chat, "left", False):
            continue
        item = _membership(chat)
        if item is not None:
            session.joined[item[0]] = item[1]
            _note(value, "joined")
            return
    _note(value, "joined, will be found through the dialog list")


async def _join_public(client: Any, value: str, session: _Session) -> None:
    entity = await client.get_entity(value)
    if not isinstance(entity, types.Channel) or entity.access_hash is None:
        _note(value, "skipped, not a channel or group")
        return
    if entity.left is False:
        await _adopt_recent(client, value, entity, session)
        return

    channel = types.InputChannel(entity.id, entity.access_hash)
    try:
        await client(JoinChannelRequest(channel))
    except Exception as exc:
        if _is(exc, "InviteRequestSent", "INVITE_REQUEST_SENT"):
            session.pending.append(("channel", channel))
            _note(value, "waiting for approval")
        elif _is(exc, "UserAlreadyParticipant", "USER_ALREADY_PARTICIPANT"):
            await _adopt_recent(client, value, entity, session)
        else:
            raise
        return

    session.joined[("channel", entity.id)] = LeaveChannelRequest(channel)
    _note(value, "joined")


async def _invite_chat(client: Any, value: str) -> Any:
    try:
        info = await client(CheckChatInviteRequest(value))
    except Exception:
        return None
    return info.chat if isinstance(info, types.ChatInviteAlready) else None


async def _adopt_recent(client: Any, value: str, chat: Any, session: _Session) -> None:
    item = await _recent_membership(client, chat)
    if item is None:
        _note(value, "already a member from before, left untouched")
        return
    session.joined[item[0]] = item[1]
    _note(value, "was joined moments ago by something else, will leave")


async def _recent_membership(client: Any, chat: Any) -> Optional[Tuple[Key, Any]]:
    if not isinstance(chat, types.Channel) or chat.access_hash is None:
        return None
    channel = types.InputChannel(chat.id, chat.access_hash)
    try:
        result = await client(GetParticipantRequest(channel, types.InputPeerSelf()))
    except Exception:
        return None
    participant = getattr(result, "participant", None)
    if not isinstance(participant, types.ChannelParticipantSelf) or participant.date is None:
        return None
    date = participant.date
    if date.tzinfo is None:
        date = date.replace(tzinfo=timezone.utc)
    if (datetime.now(timezone.utc) - date).total_seconds() > RECENT_JOIN_SECONDS:
        return None
    return ("channel", chat.id), LeaveChannelRequest(channel)


def _membership(chat: Any) -> Optional[Tuple[Key, Any]]:
    if isinstance(chat, types.Channel):
        if chat.access_hash is None:
            return None
        request = LeaveChannelRequest(types.InputChannel(chat.id, chat.access_hash))
        return ("channel", chat.id), request
    if isinstance(chat, types.Chat):
        request = DeleteChatUserRequest(chat_id=chat.id, user_id=types.InputUserSelf())
        return ("chat", chat.id), request
    return None


def _key_of(marked_id: int) -> Key:
    real_id, peer_type = utils.resolve_id(marked_id)
    return ("channel" if peer_type is types.PeerChannel else "chat"), real_id


def _ref_of(request: Any) -> Any:
    if isinstance(request, LeaveChannelRequest):
        return request.channel
    return types.InputPeerChat(request.chat_id)


def _flood_pause(exc: Exception) -> float:
    return max(float(getattr(exc, "seconds", 0) or 0), 1.0) + 1.0


async def _dialog_map(client: Any) -> Optional[Dict[int, Tuple[Any, str]]]:
    async def collect() -> Dict[int, Tuple[Any, str]]:
        found: Dict[int, Tuple[Any, str]] = {}
        async for dialog in client.iter_dialogs():
            if dialog.is_channel or dialog.is_group:
                found[dialog.id] = (dialog.entity, dialog.title or "")
        return found

    try:
        return await asyncio.wait_for(collect(), DIALOG_LIST_TIMEOUT)
    except Exception as exc:
        log.warning("auto_join: could not read the dialog list (%s)", type(exc).__name__)
        return None


async def _fresh_chats(client: Any, session: _Session) -> Dict[Key, Tuple[Any, str]]:
    if session.baseline is None:
        return {}
    dialogs = None
    for _ in range(3):
        dialogs = await _dialog_map(client)
        if dialogs is not None:
            break
        await asyncio.sleep(2.0)
    if dialogs is None:
        return {}
    fresh = {cid: item for cid, item in dialogs.items() if cid not in session.baseline}
    if len(fresh) > session.attempts:
        log.warning(
            "auto_join: %d new chats appeared but only %d join(s) were attempted, ignoring the dialog list",
            len(fresh),
            session.attempts,
        )
        return {}
    return {_key_of(cid): item for cid, item in fresh.items()}


async def _resolve_pending(client: Any, kind: str, value: Any) -> Optional[Tuple[Key, Any]]:
    try:
        if kind == "channel":
            await client(GetParticipantRequest(value, types.InputPeerSelf()))
            return ("channel", value.channel_id), value
        info = await client(CheckChatInviteRequest(value))
    except FloodWaitError:
        raise
    except Exception:
        return None
    chat = info.chat if isinstance(info, types.ChatInviteAlready) else None
    if isinstance(chat, types.Channel):
        return ("channel", chat.id), chat
    if isinstance(chat, types.Chat):
        return ("chat", chat.id), chat
    return None


async def _leave_ref(client: Any, ref: Any, key: Key) -> bool:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + LEAVE_MAX_SECONDS
    failures = 0
    while True:
        try:
            await client.delete_dialog(ref)
            return True
        except FloodWaitError as exc:
            pause = _flood_pause(exc)
            if pause > FLOOD_MAX_SLEEP_SECONDS or loop.time() + pause > deadline:
                log.warning("auto_join: leave %s abandoned, FloodWait of %ds is too long", key, pause)
                return False
            log.info("auto_join: leave %s hit FloodWait, retrying in %ds", key, pause)
            await asyncio.sleep(pause)
        except Exception as exc:
            if _is(exc, *_ALREADY_OUT):
                return True
            failures += 1
            log.warning("auto_join: leave %s failed (%s): %s", key, type(exc).__name__, exc)
            if failures >= LEAVE_RETRIES:
                return False
            await asyncio.sleep(float(failures))


async def _leave_targets(client: Any, targets: Dict[Key, Tuple[Any, str]]) -> None:
    gate = asyncio.Semaphore(LEAVE_CONCURRENCY)

    async def one(key: Key, ref: Any, title: str) -> bool:
        async with gate:
            done = await _leave_ref(client, ref, key)
        if done:
            log.info("auto_join: left %s", title or key)
        return done

    results = await asyncio.gather(*(one(key, ref, title) for key, (ref, title) in targets.items()))
    log.info("auto_join: left %d of %d", sum(results), len(results))


async def _leave_when_approved(client: Any, kind: str, value: Any, handled: Set[Key]) -> None:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + PENDING_MAX_WAIT_SECONDS
    delay = PENDING_POLL_SECONDS
    try:
        while True:
            try:
                item = await _resolve_pending(client, kind, value)
            except FloodWaitError as exc:
                item = None
                delay = max(delay, min(_flood_pause(exc), FLOOD_MAX_SLEEP_SECONDS))
            if item is not None:
                key, ref = item
                if key in handled:
                    return
                handled.add(key)
                if await _leave_ref(client, ref, key):
                    log.info("auto_join: approved later, left %s", key)
                return
            if loop.time() + delay > deadline:
                log.info(
                    "auto_join: join request not approved within %ds, nothing to leave",
                    PENDING_MAX_WAIT_SECONDS,
                )
                return
            await asyncio.sleep(delay)
            delay = min(delay * 1.5, PENDING_POLL_MAX_SECONDS)
    except Exception:
        log.exception("auto_join: waiting for approval failed")


async def _leave_session(client: Any, session: _Session) -> None:
    _spawn(_run_leave(client, session))


async def _run_leave(client: Any, session: _Session) -> None:
    try:
        loop = asyncio.get_running_loop()
        wait = LEAVE_DELAY_SECONDS - (loop.time() - session.mark)
        if wait > 0:
            await asyncio.sleep(wait)

        targets = await _fresh_chats(client, session)
        for key, request in session.joined.items():
            targets.setdefault(key, (_ref_of(request), ""))

        handled: Set[Key] = set(targets)
        if session.pending:
            log.info(
                "auto_join: %d join request(s) waiting for approval, watching in background",
                len(session.pending),
            )
            for kind, value in session.pending:
                _spawn(_leave_when_approved(client, kind, value, handled))

        if targets:
            await _leave_targets(client, targets)
        elif not session.pending:
            log.info("auto_join: no new group or channel found, nothing to leave")
    except Exception:
        log.exception("auto_join: leave stage failed")


async def _press(client: Any, peer: Any, message: Any, button: Any) -> None:
    try:
        data = button.data
        if data is not None:
            try:
                await asyncio.wait_for(
                    client(
                        GetBotCallbackAnswerRequest(
                            peer=peer,
                            msg_id=message.id,
                            data=data,
                        )
                    ),
                    CALLBACK_WAIT_SECONDS,
                )
            except (BotResponseTimeoutError, asyncio.TimeoutError):
                pass
        elif _is_plain(button):
            await client.send_message(peer, button.text)
    except Exception as exc:
        log.debug("press failed: %s", exc)


def _is_plain(button: Any) -> bool:
    raw = button.button
    kind = getattr(raw, "type", None)
    if kind is not None:
        return type(kind).__name__ == "ButtonTypeDefault"
    return type(raw).__name__ == "KeyboardButton"


def _scan(message: Any) -> Tuple[List[Target], Optional[Any]]:
    texts: List[str] = [message.raw_text or ""]

    for entity in message.entities or ():
        if isinstance(entity, types.MessageEntityTextUrl) and entity.url:
            texts.append(entity.url)

    confirm = None
    for row in message.buttons or ():
        for button in row:
            url = button.url
            if url:
                texts.append(str(url))
                continue
            if confirm is None and (button.data is not None or _is_plain(button)):
                label = (button.text or "").strip()
                if label and _CONFIRM_RE.search(label):
                    confirm = button

    targets: List[Target] = []
    seen: Set[Target] = set()
    for text in texts:
        for raw_url in _URL_RE.findall(text):
            target = _parse_link(raw_url.rstrip(_TRAILING))
            if target is not None and target not in seen:
                seen.add(target)
                targets.append(target)

    return targets, confirm


def _parse_link(url: str) -> Optional[Target]:
    if url.lower().startswith("tg://"):
        invite = parse_qs(urlparse(url).query).get("invite", [None])[0]
        return ("invite", invite) if invite else None

    if not _SCHEME_RE.match(url):
        url = "https://" + url

    parsed = urlparse(url)
    host = (parsed.netloc or "").lower().split(":", 1)[0]
    if host not in _HOSTS:
        return None

    parts = [p for p in parsed.path.split("/") if p]
    if not parts:
        return None

    first = parts[0]
    if first.startswith("+") and len(first) > 1:
        return "invite", first[1:]
    if first.lower() == "joinchat" and len(parts) > 1:
        return "invite", parts[1]
    if first.lower() in _SKIP:
        return None

    username = first.lstrip("@").strip()
    if not _USERNAME_RE.fullmatch(username):
        return None
    return "public", username