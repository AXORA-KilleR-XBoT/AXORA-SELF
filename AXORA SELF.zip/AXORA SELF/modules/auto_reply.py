import json
import asyncio
from pathlib import Path

from telethon import events

from core import panel_state

STATE_FILE  = Path(__file__).resolve().parent.parent / "panel_state.json"
_PROMPT_MSG = "📝 پاسخ خودکار را به این شکل بفرستید:\nکلمه : پاسخ"

_handling_request = False


def _normalize(text: str) -> str:
    """نرمال‌سازی برای مقایسه کلمه کلیدی (بی‌حساس به حروف بزرگ/کوچک، ی/ي، ک/ك)"""
    text = (text or "").strip().lower()
    text = text.replace("ي", "ی").replace("ك", "ک")
    text = " ".join(text.split())
    return text


async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


async def _process_add_request(client, req: dict):
    """userbot توی همون چتی که پنل باز شده، prompt برای کلمه:پاسخ می‌فرسته"""
    global _handling_request
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_request = False
        return
    try:
        msg = await client.send_message(chat_id, _PROMPT_MSG)
    except Exception as e:
        print(f"[auto_reply] prompt error: {e}")
        _handling_request = False
        return
    g = await _load_global()
    g.pop("auto_reply_add", None)
    g["auto_reply_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_request = False


async def _request_loop(client):
    global _handling_request
    while True:
        try:
            g   = await _load_global()
            req = g.get("auto_reply_add")
            if req and not _handling_request:
                _handling_request = True
                asyncio.get_event_loop().create_task(_process_add_request(client, req))
        except Exception as e:
            print(f"[auto_reply] loop error: {e}")
        await asyncio.sleep(3)


def setup(client):

    @client.on(events.NewMessage(outgoing=True))
    async def add_rule_catcher(event):
        """صید پاسخ کاربر به شکل «کلمه : پاسخ» بعد از prompt پنل"""
        if not event.is_private:
            return
        text = (event.raw_text or "").strip()
        if text == _PROMPT_MSG:
            return

        g       = await _load_global()
        waiting = g.get("auto_reply_waiting")
        if not waiting:
            return
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if text.lower() in ("لغو", "cancel"):
            g.pop("auto_reply_waiting", None)
            await _save_global(g)
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, "❌ لغو شد")
            except Exception:
                pass
            return

        # پشتیبانی از : فارسی/انگلیسی
        sep = ":" if ":" in text else ("：" if "：" in text else None)
        if not sep:
            try:
                await event.reply("❌ فرمت اشتباهه. به این شکل بفرست:\nکلمه : پاسخ")
            except Exception:
                pass
            return  # حالت انتظار رو نگه می‌داریم تا دوباره تلاش کنه

        keyword, response = text.split(sep, 1)
        keyword  = keyword.strip()
        response = response.strip()
        if not keyword or not response:
            try:
                await event.reply("❌ هم کلمه و هم پاسخ باید پر باشن")
            except Exception:
                pass
            return

        rules = g.get("auto_reply_rules", [])
        rules.append({"keyword": keyword, "response": response})
        g["auto_reply_rules"] = rules
        g.pop("auto_reply_waiting", None)
        await _save_global(g)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass
        try:
            await client.send_message(event.chat_id, f"✅ اضافه شد:\n«{keyword}» ➜ «{response}»")
        except Exception:
            pass

    @client.on(events.NewMessage(incoming=True))
    async def auto_reply_responder(event):
        """✅ این بخش قبلاً اصلاً وجود نداشت — حالا واقعاً پیام‌ها رو چک می‌کنه"""
        if not event.is_private:
            return

        g = await _load_global()
        if not g.get("auto_reply_enabled", False):
            return

        rules = g.get("auto_reply_rules", [])
        if not rules:
            return

        sender = await event.get_sender()
        if not sender or getattr(sender, "bot", False):
            return

        msg_norm = _normalize(event.raw_text or "")
        if not msg_norm:
            return

        for rule in rules:
            kw_norm = _normalize(rule.get("keyword", ""))
            if kw_norm and kw_norm in msg_norm:
                try:
                    await event.reply(rule.get("response", ""))
                except Exception:
                    pass
                break  # فقط یک پاسخ به ازای هر پیام (اولین قانون منطبق)

    asyncio.get_event_loop().create_task(_request_loop(client))