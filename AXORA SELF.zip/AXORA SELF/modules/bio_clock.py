import re
import json
import asyncio
from datetime import datetime
from pathlib import Path
from telethon import events, functions

from core import panel_state

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

CITY_TIMEZONES: dict[str, str] = {
    "تهران":     "Asia/Tehran",
    "لندن":      "Europe/London",
    "واشینگتن":  "America/New_York",
    "واشنگتن":   "America/New_York",
    "نیویورک":   "America/New_York",
    "نیو یورک":  "America/New_York",
    "پاریس":     "Europe/Paris",
    "دبی":       "Asia/Dubai",
    "توکیو":     "Asia/Tokyo",
    "مسکو":      "Europe/Moscow",
    "استانبول":  "Europe/Istanbul",
    "ریاض":      "Asia/Riyadh",
    "بغداد":     "Asia/Baghdad",
    "قاهره":     "Africa/Cairo",
    "برلین":     "Europe/Berlin",
    "لس‌آنجلس":  "America/Los_Angeles",
    "لس انجلس":  "America/Los_Angeles",
    "بمبئی":     "Asia/Kolkata",
    "پکن":       "Asia/Shanghai",
    "سیدنی":     "Australia/Sydney",
    "تورنتو":    "America/Toronto",
    "استکهلم":   "Europe/Stockholm",
    "آمستردام":  "Europe/Amsterdam",
    "رم":        "Europe/Rome",
    "مادرید":    "Europe/Madrid",
}

# پیام‌های خود ربات که نباید صید بشن
_PROMPT_MSGS = {"⏰ ساعت شهر را بگویید", "📝 متن خود را بنویسید"}


def _get_tz(tz_name: str):
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name)
    except Exception:
        import pytz
        return pytz.timezone(tz_name)


def get_city_time(city_fa: str) -> str:
    tz_name = CITY_TIMEZONES.get(city_fa.strip())
    if not tz_name:
        return "??:??"
    try:
        return datetime.now(_get_tz(tz_name)).strftime("%H:%M")
    except Exception:
        return "??:??"


def resolve_template(template: str) -> str:
    """{شهر} را با ساعت فعلی جایگزین می‌کنه"""
    def replace(m):
        return get_city_time(m.group(1))
    return re.sub(r"\{([^}]+)\}", replace, template)


async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


# جلوگیری از پردازش همزمان چند pending
_handling_input = False


async def _process_pending_input(client, pending: dict):
    """ارسال prompt به chat و انتظار برای پاسخ کاربر"""
    global _handling_input

    input_type = pending.get("type")   # "city" | "text"
    chat_id    = pending.get("chat_id")
    if not chat_id:
        _handling_input = False
        return

    # ارسال prompt توسط userbot در همون چت
    prompt_text = "⏰ ساعت شهر را بگویید" if input_type == "city" else "📝 متن خود را بنویسید"
    try:
        msg = await client.send_message(chat_id, prompt_text)
        prompt_id = msg.id
    except Exception as e:
        print(f"[bio_clock] send prompt error: {e}")
        _handling_input = False
        return

    # ذخیره حالت انتظار توی JSON
    g = await _load_global()
    g.pop("bio_input", None)
    g["bio_waiting"] = {"type": input_type, "chat_id": chat_id, "prompt_id": prompt_id}
    await _save_global(g)

    _handling_input = False


async def _bio_update_loop(client):
    global _handling_input
    while True:
        try:
            g = await _load_global()

            # بررسی pending input از panel_bot
            pending = g.get("bio_input")
            if pending and not _handling_input:
                _handling_input = True
                asyncio.get_event_loop().create_task(_process_pending_input(client, pending))

            # آپدیت بیو هر ۳۰ ثانیه
            if g.get("bio_clock_enabled", False):
                template = g.get("bio_clock_template", "")
                if template:
                    bio_text = resolve_template(template)
                    try:
                        await client(functions.account.UpdateProfileRequest(about=bio_text))
                    except Exception as e:
                        if "FLOOD_WAIT" in str(e):
                            pass  # telegram rate limit - صبر می‌کنیم

        except Exception as e:
            print(f"[bio_clock] loop error: {e}")

        await asyncio.sleep(30)


def setup(client):
    @client.on(events.NewMessage(outgoing=True))
    async def bio_input_catcher(event):
        """صید پاسخ کاربر برای تنظیم ساعت بیو"""
        if not event.is_private:
            return

        text = (event.raw_text or "").strip()

        # نادیده گرفتن prompt های خودمون
        if text in _PROMPT_MSGS:
            return

        # بررسی حالت انتظار
        try:
            data    = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            g       = data.get("_global", {})
            waiting = g.get("bio_waiting")
        except Exception:
            return

        if not waiting:
            return

        # بررسی chat و پیام معتبر
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if text.lower() in ("لغو", "cancel"):
            g.pop("bio_waiting", None)
            data["_global"] = g
            STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, "❌ لغو شد")
            except Exception:
                pass
            return

        # ذخیره template
        input_type = waiting.get("type")
        prompt_id  = waiting.get("prompt_id")

        g.pop("bio_waiting", None)

        if input_type == "city":
            g["bio_clock_template"] = f"{{{text}}}"
        else:
            g["bio_clock_template"] = text

        data["_global"] = g
        STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        # حذف prompt و پاسخ کاربر
        try:
            await client.delete_messages(event.chat_id, [prompt_id])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass

    asyncio.get_event_loop().create_task(_bio_update_loop(client))