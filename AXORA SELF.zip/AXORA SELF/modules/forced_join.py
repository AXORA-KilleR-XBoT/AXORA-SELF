import re
import time
import json
import asyncio
from pathlib import Path

from telethon import events, functions, utils
from telethon.tl.types import User, InputChannelEmpty
from telethon.errors import UserNotParticipantError

from core import panel_state

# 🔇 چاپ در کنسول غیرفعال شد: این تابع، print() استاندارد پایتون رو فقط داخل
# همین فایل بازنویسی می‌کنه و هیچ‌کاری نمی‌کنه. در نتیجه هر print(...) که همین
# الان یا بعداً توی این ماژول نوشته بشه، دیگه چیزی توی کنسول چاپ نمی‌کنه.
def print(*args, **kwargs):
    pass

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"
BOT_USERNAME = "NightmareTitanXBoT"  # یوزرنیم بات پنل - برای ارسال دیوار عضویت با دکمه شیشه‌ای

_PROMPT_MSG_FA = "📝 متن خود را به همراه لینک‌ها ارسال نمایید:"
_PROMPT_MSG_EN = "📝 Please send your text along with the links:"

_CA_PROMPT_MSG_FA = "📝 لینک کانال‌ها/گروه‌ها را ارسال نمایید:"
_CA_PROMPT_MSG_EN = "📝 Please send the channel/group links:"

# پشتیبانی از t.me/xxx ، telegram.me/xxx و @xxx (هر کدوم توی متن باشه)
_LINK_RE     = re.compile(r'(?:https?://)?(?:t(?:elegram)?\.me)/([A-Za-z0-9_]{4,32})', re.IGNORECASE)
_USERNAME_RE = re.compile(r'^@?([A-Za-z0-9_]{4,32})$')

_handling_add     = False  # عضویت اجباری
_handling_ca_add  = False  # تبلیغات چنل

# کش حافظه: کاربرانی که قبلاً تشخیص دادیم "قدیمی" (سابقه چت) هستن - برای سرعت
_known_senders: set = set()
# کش حافظه: کاربرانی که قبلاً عضویتشون تایید شده - تا هر پیام دوباره چک نشه
_verified_members: set = set()


# ===================== STATE HELPERS =====================

async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})

async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


# ===================== LINK PARSING =====================

def _extract_links(text: str):
    """
    خط به خط متن رو می‌خونه؛ هر خطی که لینک تلگرامی یا یوزرنیم باشه از متن جدا
    می‌شه و باقی خط‌ها به عنوان قالب پیام (template) برمی‌گردن.
    """
    usernames = []
    template_lines = []
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped:
            template_lines.append(line)
            continue
        m = _LINK_RE.search(stripped)
        if m:
            usernames.append(m.group(1))
            continue
        m2 = _USERNAME_RE.fullmatch(stripped)
        if m2:
            usernames.append(m2.group(1))
            continue
        template_lines.append(line)
    template = "\n".join(template_lines).strip()
    return template, usernames


def _extract_links_only(text: str):
    """مثل _extract_links ولی فقط لیست یوزرنیم‌ها رو برمی‌گردونه (برای تبلیغات چنل قالب لازم نیست)"""
    _, usernames = _extract_links(text)
    return usernames


# ===================== ACCESS / MEMBERSHIP CHECKS (مخصوص عضویت اجباری) =====================

async def _check_channel_access(client, entity) -> bool:
    """
    ✅ آیا userbot توی این چنل/گروه ادمینه یا حداقل دسترسی دیدن اعضا رو داره؟
    برای اینکه بشه عضویت بقیه رو چک کرد، یکی از این دو لازمه.
    """
    try:
        perms = await client.get_permissions(entity, "me")
        if getattr(perms, "is_admin", False) or getattr(perms, "is_creator", False):
            return True
    except Exception:
        pass
    try:
        async for _ in client.iter_participants(entity, limit=1):
            return True
    except Exception:
        pass
    return False


async def _is_member(client, entity, user_id) -> bool:
    try:
        await client.get_permissions(entity, user_id)
        return True
    except UserNotParticipantError:
        return False
    except Exception:
        # هر خطای دیگه‌ای (دسترسی، نت، و...) رو محافظه‌کارانه «عضو نیست» در نظر می‌گیریم
        return False


# ===================== عضویت اجباری: ADD-CHANNEL FLOW =====================

async def _process_add_request(client, req: dict):
    global _handling_add
    chat_id = req.get("chat_id")
    print(f"[forced_join] 📨 _process_add_request اجرا شد، chat_id={chat_id} (type={type(chat_id)})")  # 🔍 دیباگ
    if not chat_id:
        print("[forced_join] ❌ chat_id خالیه، برمی‌گردم")
        _handling_add = False
        return
    try:
        msg = await client.send_message(chat_id, _PROMPT_MSG_FA)
        print(f"[forced_join] ✅ پیام prompt با موفقیت فرستاده شد، msg.id={msg.id}")
    except Exception as e:
        print(f"[forced_join] ❌ prompt error: {type(e).__name__}: {e}")
        _handling_add = False
        return
    g = await _load_global()
    g.pop("forced_join_add", None)
    g["forced_join_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_add = False


async def _request_loop(client):
    global _handling_add
    print("[forced_join] 🔁 _request_loop started")  # 🔍 دیباگ
    while True:
        try:
            g   = await _load_global()
            req = g.get("forced_join_add")
            if req:
                print(f"[forced_join] 🔍 دیدم forced_join_add = {req} | _handling_add={_handling_add}")
            if req and not _handling_add:
                _handling_add = True
                print("[forced_join] ▶️ شروع پردازش درخواست...")
                asyncio.get_event_loop().create_task(_process_add_request(client, req))
        except Exception as e:
            print(f"[forced_join] ❌ loop error: {e}")
        await asyncio.sleep(3)


async def _resolve_and_check_one(client, username: str):
    """یک یوزرنیم رو resolve و دسترسی ادمین/اعضا رو چک می‌کنه - برای اجرای موازی"""
    try:
        entity = await client.get_entity(username)
    except Exception:
        return {"username": username, "ok": False, "reason": "not_found", "entity": None, "title": username}

    ok    = await _check_channel_access(client, entity)
    title = getattr(entity, "title", None) or getattr(entity, "first_name", None) or username
    return {"username": username, "ok": ok, "reason": None if ok else "no_access", "entity": entity, "title": title}


async def _handle_add_channels(client, event, waiting: dict, text: str):
    """پردازش پیامی که کاربر بعد از prompt عضویت اجباری فرستاده (متن + لینک‌ها)"""
    g = await _load_global()

    # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
    if text.strip().lower() in ("لغو", "cancel"):
        g.pop("forced_join_waiting", None)
        await _save_global(g)
        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass
        try:
            await client.send_message(event.chat_id, "❌ لغو شد")
        except Exception:
            pass
        return

    template, usernames = _extract_links(text)
    if not usernames:
        try:
            await event.reply("❌ هیچ لینک تلگرامی توی متن پیدا نشد. دوباره با لینک بفرست.")
        except Exception:
            pass
        return  # حالت انتظار رو نگه می‌داریم تا دوباره تلاش کنه

    g.pop("forced_join_waiting", None)

    # ✅ سرعت: همه‌ی لینک‌ها رو موازی resolve و چک می‌کنیم (نه یکی‌یکی)
    results = await asyncio.gather(*(_resolve_and_check_one(client, u) for u in usernames))

    channels = g.get("forced_join_channels", [])
    existing_usernames = {c.get("username", "").lower() for c in channels}

    added, broken_not_found, broken_no_access = [], [], []
    for r in results:
        uname = r["username"]
        if r["ok"]:
            if uname.lower() not in existing_usernames:
                channels.append({
                    "username": uname,
                    "title": r["title"],
                    "link": f"https://t.me/{uname}",
                })
                existing_usernames.add(uname.lower())
            added.append((uname, r["title"]))
        elif r["reason"] == "not_found":
            broken_not_found.append(uname)
        else:
            broken_no_access.append((uname, r["title"]))

    g["forced_join_channels"] = channels
    if template:
        g["forced_join_message"] = template
    await _save_global(g)

    try:
        await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
    except Exception:
        pass
    try:
        await event.delete()
    except Exception:
        pass

    if added:
        lines = "\n".join(f"✅ {t} (@{u})" for u, t in added)
        try:
            await client.send_message(event.chat_id, f"چنل‌های زیر اضافه شدن:\n\n{lines}")
        except Exception:
            pass

    for uname in broken_not_found:
        try:
            await client.send_message(event.chat_id, f"❌ https://t.me/{uname}\nاین یوزرنیم/لینک پیدا نشد.")
        except Exception:
            pass

    for uname, title in broken_no_access:
        try:
            await client.send_message(
                event.chat_id,
                f"❌ https://t.me/{uname} ({title})\n"
                f"تو نه توی این چنل ادمین هستی و نه دسترسی به دیدن اعضا رو داری. کاری از دستم بر نمیاد."
            )
        except Exception:
            pass


# ===================== عضویت اجباری: AUDIENCE TARGETING =====================

async def _is_new_sender(client, user_id: int) -> bool:
    """آیا این کاربر سابقه‌ی چت قبلی نداره؟ (پیام جدید)"""
    if user_id in _known_senders:
        return False
    try:
        history = await client.get_messages(user_id, limit=2)
        is_new = len(history) <= 1
    except Exception:
        is_new = True
    if not is_new:
        _known_senders.add(user_id)
    return is_new


def _audience_match(key: str, is_new: bool, is_contact: bool) -> bool:
    if key == "contacts_chatted":
        return is_contact and not is_new
    if key == "currently_chatting":
        return not is_new
    if key == "new_in_private":
        return is_new
    if key == "anyone_message":
        return True
    if key == "new_except_contacts":
        return is_new and not is_contact
    if key == "everyone":
        return True
    return True  # پیش‌فرض محافظه‌کارانه: فعال


# ===================== تبلیغات چنل: ADD-CHANNEL FLOW (ساده‌تر، بدون چک دسترسی) =====================
# برای گذاشتن لینک توی بیوی خودمون، نیازی به ادمین بودن نیست - فقط باید چنل/گروه پیدا بشه

async def _resolve_one_for_ads(client, username: str):
    try:
        entity = await client.get_entity(username)
    except Exception:
        return {"username": username, "ok": False, "title": username}
    title = getattr(entity, "title", None) or getattr(entity, "first_name", None) or username
    return {"username": username, "ok": True, "title": title}


async def _process_ca_add_request(client, req: dict):
    global _handling_ca_add
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_ca_add = False
        return
    try:
        msg = await client.send_message(chat_id, _CA_PROMPT_MSG_FA)
    except Exception:
        _handling_ca_add = False
        return
    g = await _load_global()
    g.pop("channel_ads_add", None)
    g["channel_ads_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_ca_add = False


async def _ca_request_loop(client):
    global _handling_ca_add
    while True:
        try:
            g   = await _load_global()
            req = g.get("channel_ads_add")
            if req and not _handling_ca_add:
                _handling_ca_add = True
                asyncio.get_event_loop().create_task(_process_ca_add_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(3)


async def _handle_ca_add_channels(client, event, waiting: dict, text: str):
    """پردازش لینک‌های تبلیغات چنل - فقط resolve می‌کنیم، نیازی به چک ادمین نیست"""
    g = await _load_global()

    # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
    if text.strip().lower() in ("لغو", "cancel"):
        g.pop("channel_ads_waiting", None)
        await _save_global(g)
        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass
        try:
            await client.send_message(event.chat_id, "❌ لغو شد")
        except Exception:
            pass
        return

    usernames = _extract_links_only(text)

    if not usernames:
        try:
            await event.reply("❌ هیچ لینک تلگرامی توی متن پیدا نشد. دوباره با لینک بفرست.")
        except Exception:
            pass
        return

    g.pop("channel_ads_waiting", None)

    results = await asyncio.gather(*(_resolve_one_for_ads(client, u) for u in usernames))

    channels = g.get("channel_ads_channels", [])
    existing = {c.get("username", "").lower() for c in channels}

    added, broken = [], []
    for r in results:
        uname = r["username"]
        if r["ok"]:
            if uname.lower() not in existing:
                channels.append({
                    "username": uname,
                    "title": r["title"],
                    "link": f"https://t.me/{uname}",
                })
                existing.add(uname.lower())
            added.append((uname, r["title"]))
        else:
            broken.append(uname)

    g["channel_ads_channels"] = channels
    await _save_global(g)

    try:
        await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
    except Exception:
        pass
    try:
        await event.delete()
    except Exception:
        pass

    if added:
        lines = "\n".join(f"✅ {t} (@{u})" for u, t in added)
        try:
            await client.send_message(event.chat_id, f"چنل‌های زیر به چرخه‌ی تبلیغات اضافه شدن:\n\n{lines}")
        except Exception:
            pass

    for uname in broken:
        try:
            await client.send_message(event.chat_id, f"❌ https://t.me/{uname}\nاین یوزرنیم/لینک پیدا نشد.")
        except Exception:
            pass


# ===================== تبلیغات چنل: حلقه چرخش Personal Channel =====================
# ⚠️ توجه مهم: اینجا بیوگرافی (about) دست نمی‌خوره! به‌جاش از متد رسمی تلگرام
# account.updatePersonalChannel استفاده می‌شه که همون بخش «کانال شخصی» توی
# صفحه‌ی پروفایل اکانت هست (همونی که زیر بیو، با عکس و اسم چنل نشون داده می‌شه).

async def _set_personal_channel(client, username: str) -> bool:
    """چنل داده‌شده رو به‌عنوان Personal Channel ست می‌کنه. موفق=True"""
    try:
        entity        = await client.get_entity(username)
        input_channel = utils.get_input_channel(entity)
        await client(functions.account.UpdatePersonalChannelRequest(channel=input_channel))
        return True
    except Exception:
        return False


async def _clear_personal_channel(client) -> bool:
    """Personal Channel رو از پروفایل حذف می‌کنه (برای وقتی خاموش می‌شه یا لیست خالیه)"""
    try:
        await client(functions.account.UpdatePersonalChannelRequest(channel=InputChannelEmpty()))
        return True
    except Exception:
        return False


# یادآوری وضعیت قبلی، فقط برای اینکه بفهمیم چه زمانی enabled از True به False
# رفته (تا در اون لحظه Personal Channel پاک شه) - نیازی به ذخیره توی فایل نیست.
_ads_was_enabled = False


async def _channel_ads_rotation_loop(client):
    """
    ✅ هر چند ثانیه چک می‌کنه که آیا زمان سوئیچ رسیده؛ اگه رسیده باشه به چنل
    بعدی توی لیست می‌ره و همون چنل رو به‌عنوان Personal Channel پروفایل ست می‌کنه.
    """
    global _ads_was_enabled
    while True:
        try:
            g       = await _load_global()
            enabled = g.get("channel_ads_enabled", False)

            if enabled:
                channels = g.get("channel_ads_channels", [])
                if channels:
                    interval    = g.get("channel_ads_interval_seconds", 600)
                    last_switch = g.get("channel_ads_last_switch", 0)
                    now         = time.time()
                    if now - last_switch >= interval:
                        idx = g.get("channel_ads_current_index", 0) % len(channels)
                        ch  = channels[idx]
                        await _set_personal_channel(client, ch["username"])
                        g["channel_ads_current_index"] = (idx + 1) % len(channels)
                        g["channel_ads_last_switch"]   = now
                        await _save_global(g)
            elif _ads_was_enabled:
                # ✅ همین الان از روشن به خاموش سوئیچ شده -> Personal Channel رو پاک کن
                await _clear_personal_channel(client)

            _ads_was_enabled = enabled
        except Exception:
            pass
        await asyncio.sleep(5)


# ===================== SETUP =====================

def setup(client):
    print("✅ forced_join module loaded")  # 🔍 اگه این رو توی کنسول نمی‌بینی، یعنی setup() صدا زده نمیشه

    # ── عضویت اجباری: گرفتن متن+لینک‌ها از کاربر ──
    @client.on(events.NewMessage(outgoing=True))
    async def add_channels_catcher(event):
        if not event.is_private:
            return
        text = (event.raw_text or "").strip()
        if text in (_PROMPT_MSG_FA, _PROMPT_MSG_EN):
            return

        g       = await _load_global()
        waiting = g.get("forced_join_waiting")
        if not waiting:
            return
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        await _handle_add_channels(client, event, waiting, text)

    # ── تبلیغات چنل: گرفتن لینک‌ها از کاربر ──
    @client.on(events.NewMessage(outgoing=True))
    async def ca_add_channels_catcher(event):
        if not event.is_private:
            return
        text = (event.raw_text or "").strip()
        if text in (_CA_PROMPT_MSG_FA, _CA_PROMPT_MSG_EN):
            return

        g       = await _load_global()
        waiting = g.get("channel_ads_waiting")
        if not waiting:
            return
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        await _handle_ca_add_channels(client, event, waiting, text)

    # ── عضویت اجباری: enforcement روی پیام‌های ورودی ──
    @client.on(events.NewMessage(incoming=True))
    async def forced_join_enforcer(event):
        if not event.is_private:
            return

        g = await _load_global()
        if not g.get("forced_join_enabled", False):
            return

        channels = g.get("forced_join_channels", [])
        if not channels:
            return

        sender = await event.get_sender()
        if not sender or not isinstance(sender, User) or sender.bot:
            return

        uid = sender.id

        # ✅ اگه قبلاً تایید شده عضو همه‌ی چنل‌هاست، دیگه چک نکن (سرعت)
        if uid in _verified_members:
            return

        is_contact = bool(getattr(sender, "contact", False))
        is_new     = await _is_new_sender(client, uid)

        audience_key = g.get("forced_join_audience", "everyone")
        if not _audience_match(audience_key, is_new, is_contact):
            return

        # ✅ سرعت: چک عضویت همه‌ی چنل‌ها به‌صورت موازی، نه یکی‌یکی
        async def _check_one(ch):
            try:
                entity = await client.get_entity(ch["username"])
            except Exception:
                return None  # چنل پیدا نشد - نادیده بگیر، گناه کاربر نیست
            member = await _is_member(client, entity, uid)
            return None if member else ch

        results    = await asyncio.gather(*(_check_one(ch) for ch in channels))
        not_joined = [ch for ch in results if ch is not None]

        if not not_joined:
            _verified_members.add(uid)
            return

        # پیام کاربر رو پاک کن و دیوار عضویت رو نشون بده
        try:
            await event.delete()
        except Exception:
            pass

        text_msg = g.get("forced_join_message", "برای اینکه با من صحبت کنید در چنل های زیر عضو شید")

        # ✅ FIX: یوزراکانت‌ها (userbot) نمی‌تونن دکمه شیشه‌ای واقعی بفرستن - این یک
        # محدودیت خود تلگرامه، نه باگ. فقط اکانت‌های بات اجازه‌ی ارسال inline keyboard
        # دارن. برای همین از همون ترفند inline_query که برای دستور «پنل» استفاده شده
        # کمک می‌گیریم: یک inline query به بات می‌زنیم و نتیجه‌ش رو کلیک می‌کنیم تا
        # پیام واقعاً از طرف بات با دکمه‌ی کامل ارسال شه.
        wall_id = f"{uid}_{int(time.time()*1000)}"
        all_state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        g_full = all_state.setdefault("_global", {})
        wall_store = g_full.setdefault("forced_join_wall_data", {})
        wall_store[wall_id] = {
            "text": text_msg,
            "channels": [
                {"title": ch.get("title", ch.get("username", "")), "link": ch["link"]}
                for ch in not_joined
            ],
        }
        # نگه‌داری حداکثر ۵۰ تای آخر تا فایل بی‌نهایت بزرگ نشه
        if len(wall_store) > 50:
            for old_id in list(wall_store.keys())[:-50]:
                wall_store.pop(old_id, None)
        STATE_FILE.write_text(json.dumps(all_state, ensure_ascii=False, indent=2), encoding="utf-8")

        sent_ok = False
        try:
            results = await client.inline_query(BOT_USERNAME, f"fjwall:{wall_id}")
            if results:
                await results[0].click(event.chat_id)
                sent_ok = True
        except Exception as e:
            print(f"[forced_join] ❌ inline wall send error: {e}")

        if not sent_ok:
            # fallback: حداقل متن رو بدون دکمه بفرست تا کاربر کاملاً بی‌خبر نمونه
            try:
                links_text = "\n".join(f"📢 {ch.get('title','')}: {ch['link']}" for ch in not_joined)
                await client.send_message(event.chat_id, f"{text_msg}\n\n{links_text}")
            except Exception:
                pass

    print("[forced_join] 📌 در حال زمان‌بندی background task ها...")
    try:
        loop = asyncio.get_event_loop()
        loop.create_task(_request_loop(client))
        loop.create_task(_ca_request_loop(client))
        loop.create_task(_channel_ads_rotation_loop(client))
        print("[forced_join] ✅ هر سه task با موفقیت زمان‌بندی شدن")
    except Exception as e:
        print(f"[forced_join] ❌ خطا در زمان‌بندی task ها: {type(e).__name__}: {e}")