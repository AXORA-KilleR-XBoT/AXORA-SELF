from telethon import events
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.channels import GetFullChannelRequest, GetParticipantsRequest
from telethon.tl.functions.messages import GetFullChatRequest
from telethon.tl.types import User as TLUser, Chat as TLChat, Channel as TLChannel, ChannelParticipantsAdmins, ChatParticipants, ChannelParticipantCreator, ChatParticipantCreator
import datetime
import asyncio
import re

try:
    import jdatetime
    HAS_JALALI = True
except Exception:
    HAS_JALALI = False

# ===================== TEXT NORMALIZATION =====================
def normalize_fa(text: str) -> str:
    """Normalize Arabic-script look-alikes to their Persian forms."""
    return (text or "").replace("ك", "ک").replace("ي", "ی").replace("ۀ", "ه")

# ===================== TRIGGER DETECTION =====================
PERSIAN_BACKUP_WORDS = {"بکاپ", "پکاپ", "پکاب", "بکاب"}
ENGLISH_BACKUP_WORD = "backup"
STRIP_CHARS = " \t\r\n./,!?؟،:؛()[]{}\"'«»"

USERNAME_RE = re.compile(r"@(\w{3,32})")
# ریجکس برای استخراج پابلیک لینک‌ها یا جوین‌لینک‌های تلگرام
LINK_RE = re.compile(r"(?:t\.me/|telegram\.me/)(joinchat/)?(\+)?([\w\-_]{3,32})")


def match_trigger(token: str):
    if not token:
        return None
    clean = token.strip(STRIP_CHARS)
    if not clean:
        return None

    if clean.lower() == ENGLISH_BACKUP_WORD:
        return "en"

    if normalize_fa(clean) in PERSIAN_BACKUP_WORDS:
        return "fa"

    return None


def detect_backup_command(raw_text: str):
    if not raw_text:
        return None

    lang = None
    for line in raw_text.splitlines():
        for token in line.split():
            lang = match_trigger(token)
            if lang:
                break
        if lang:
            break

    if not lang:
        return None

    m = USERNAME_RE.search(raw_text)
    username = m.group(1) if m else None

    # بررسی وجود لینک در متن
    link_m = LINK_RE.search(raw_text)
    link_str = link_m.group(0) if link_m else None

    return {"lang": lang, "username": username, "link": link_str}


# ===================== TIME FORMAT =====================
def format_time(is_fa: bool) -> str:
    now = datetime.datetime.now()
    if is_fa and HAS_JALALI:
        return jdatetime.datetime.now().strftime("%Y/%m/%d - %H:%M:%S")
    if is_fa:
        return now.strftime("%Y/%m/%d - %H:%M:%S")
    return now.strftime("%Y-%m-%d - %H:%M:%S")


# ===================== GIFT COUNT =====================
async def get_gift_count(client, user):
    try:
        from telethon.tl.functions.payments import GetSavedStarGiftsRequest
    except Exception:
        return None
    try:
        result = await client(GetSavedStarGiftsRequest(peer=user, offset="", limit=1))
        count = getattr(result, "count", None)
        if count is None:
            count = len(getattr(result, "gifts", None) or [])
        return count
    except Exception:
        return None


# ===================== BACKUP HANDLER =====================
def setup(client):

    @client.on(events.NewMessage(outgoing=True))
    async def handler(event):
        raw = event.raw_text or ""

        cmd = detect_backup_command(raw)
        if not cmd:
            return  

        lang = cmd["lang"]
        username = cmd["username"]
        link = cmd["link"]
        is_fa = lang == "fa"

        try:
            # ---------------- TARGET RESOLUTION ----------------
            entity = None

            # اولویت ۱: ریپلای
            if event.is_reply:
                reply_msg = await event.get_reply_message()
                if reply_msg:
                    reply_text = reply_msg.raw_text or ""
                    # بررسی لینک در پیام ریپلای شده
                    reply_link_m = LINK_RE.search(reply_text)
                    reply_m = USERNAME_RE.search(reply_text)
                    
                    if reply_link_m:
                        try:
                            entity = await client.get_entity(reply_link_m.group(0))
                        except Exception:
                            entity = None
                    elif reply_m:
                        try:
                            entity = await client.get_entity(reply_m.group(1))
                        except Exception:
                            entity = None
                    
                    if not entity:
                        try:
                            entity = await reply_msg.get_sender()
                        except Exception:
                            entity = None
                        # اگر سندر خالی بود (مثلاً پیام در کانال فرستاده شده)، خود چت ریپلای شده رو بردارد
                        if not entity:
                            entity = await reply_msg.get_chat()

            # اولویت ۲: لینک موجود در متن خود دستور
            if not entity and link:
                try:
                    entity = await client.get_entity(link)
                except Exception:
                    entity = None

            # اولویت ۳: یوزرنیم موجود در متن خود دستور
            if not entity and username:
                try:
                    entity = await client.get_entity(username)
                except Exception:
                    entity = None

            # اولویت ۴: چت فعلی (اگر پرایوت، کانال یا گروه باشد)
            if not entity:
                entity = await event.get_chat()

            if not entity:
                if event.is_private or username or link or event.is_reply:
                    err = "❌ هدف پیدا نشد" if is_fa else "❌ Target not found"
                    await event.reply(err)
                return

            # =========================================================
            # ------------------- منطق کاربر (USER) -------------------
            # =========================================================
            if isinstance(entity, TLUser):
                full, photos, gift_count = await asyncio.gather(
                    client(GetFullUserRequest(entity.id)),
                    client.get_profile_photos(entity, limit=7),
                    get_gift_count(client, entity),
                    return_exceptions=True,
                )

                if isinstance(full, Exception): full = None
                if isinstance(photos, Exception): photos = []
                if isinstance(gift_count, Exception): gift_count = None

                full_user = getattr(full, "full_user", None)

                name = f"{entity.first_name or ''} {entity.last_name or ''}".strip()
                name = name or ("بدون نام" if is_fa else "No name")

                bio = full_user.about if (full_user and full_user.about) else ("خالی" if is_fa else "Empty")
                username_display = f"@{entity.username}" if entity.username else ("ندارد" if is_fa else "None")
                is_scam = getattr(full_user, "scam", False) if full_user else False
                is_premium = getattr(entity, "premium", False)
                gift_display = gift_count if gift_count is not None else ("نامشخص" if is_fa else "Unknown")
                time_str = format_time(is_fa)

                if is_fa:
                    caption = (
                        "📦 بکاپ کاربر\n\n"
                        f"👤 نام: {name}\n"
                        f"🤡 بیو: {bio}\n"
                        f"🔹 یوزرنیم: {username_display}\n"
                        f"🆔 آیدی عددی: {entity.id}\n"
                        f"⭐ پرمیوم: {'بله' if is_premium else 'خیر'}\n"
                        f"🎁 تعداد گیفت: {gift_display}\n"
                        f"🚨 اسکمر: {'بله' if is_scam else 'خیر'}\n"
                        f"⏱ زمان: {time_str}"
                    )
                else:
                    caption = (
                        "📦 USER BACKUP\n\n"
                        f"👤 Name: {name}\n"
                        f"🤡 Bio: {bio}\n"
                        f"🔹 Username: {username_display}\n"
                        f"🆔 ID: {entity.id}\n"
                        f"⭐ Premium: {'Yes' if is_premium else 'No'}\n"
                        f"🎁 Gifts: {gift_display}\n"
                        f"🚨 Scammer: {'Yes' if is_scam else 'No'}\n"
                        f"⏱ Time: {time_str}"
                    )

                try:
                    if photos:
                        await client.send_file(event.chat_id, photos, caption=caption)
                        await event.delete()
                    else:
                        await event.reply(caption)
                        await event.delete()
                except Exception as e:
                    await event.reply(f"Error: {e}")

                if is_scam:
                    alert = ("🚨 هشدار: این کاربر اسکمر شناسایی شده!" if is_fa else "🚨 WARNING: Scammer detected!")
                    await event.reply(alert)

            # =========================================================
            # ----------------- منطق گروه و کانال -----------------
            # =========================================================
            elif isinstance(entity, (TLChat, TLChannel)):
                is_channel = isinstance(entity, TLChannel) and getattr(entity, "broadcast", False)
                
                # تشخیص نوع چت برای تایتل
                if is_channel:
                    chat_type_fa, chat_type_en = "کانال", "Channel"
                else:
                    chat_type_fa, chat_type_en = "گروه", "Group"

                # دریافت اطلاعات کامل چت و عکس‌ها (۳ عکس آخر) به صورت همزمان
                photos_task = client.get_profile_photos(entity, limit=3)
                
                full_chat = None
                admins_list = []
                owner_display = "نامشخص" if is_fa else "Unknown"
                member_count = "نامشخص" if is_fa else "Unknown"

                try:
                    if isinstance(entity, TLChannel):
                        full_res = await client(GetFullChannelRequest(channel=entity))
                        full_chat = full_res.full_chat
                        member_count = full_chat.participants_count if full_chat else (entity.participants_count or member_count)
                        
                        try:
                            admins_res = await client(GetParticipantsRequest(
                                channel=entity,
                                filter=ChannelParticipantsAdmins(),
                                offset=0, limit=100, hash=0
                            ))
                            
                            user_map = {u.id: u for u in admins_res.users}
                            for p in admins_res.participants:
                                u = user_map.get(p.user_id)
                                if not u:
                                    continue
                                u_mention = f"@{u.username}" if u.username else f"`{u.id}`"
                                
                                # تشخیص مالک کانال/سوپرگروه
                                if isinstance(p, ChannelParticipantCreator):
                                    owner_display = u_mention
                                else:
                                    admins_list.append(u_mention)
                        except Exception:
                            pass
                    else:
                        # گروه‌های معمولی (Small Groups)
                        # ✅ عملکرد: قبلاً هر عضو (مالک/ادمین) با client.get_entity()
                        # جدا و سکانسیال صدا زده می‌شد - یعنی یه رفت‌وبرگشتِ شبکه‌ی
                        # مجزا به ازای هر نفر. دقیقاً مثل شاخه‌ی کانال/سوپرگروهِ بالا،
                        # full_res خودش لیستِ کاملِ .users رو برمی‌گردونه - از همون
                        # استفاده می‌کنیم، بدون هیچ کالِ اضافه‌ای.
                        full_res = await client(GetFullChatRequest(chat_id=entity.id))
                        full_chat = full_res.full_chat
                        full_user_map = {u.id: u for u in full_res.users}
                        if full_chat and full_chat.participants:
                            member_count = len(full_chat.participants.participants)
                            for p in full_chat.participants.participants:
                                # تشخیص مالک گروه معمولی
                                if isinstance(p, ChatParticipantCreator):
                                    u_ent = full_user_map.get(p.user_id)
                                    if u_ent:
                                        owner_display = f"@{u_ent.username}" if u_ent.username else f"`{u_ent.id}`"
                                    else:
                                        owner_display = f"`{p.user_id}`"
                                elif hasattr(p, 'is_admin') and p.is_admin:
                                    u_ent = full_user_map.get(p.user_id)
                                    if u_ent:
                                        if u_ent.username:
                                            admins_list.append(f"@{u_ent.username}")
                                        else:
                                            admins_list.append(f"`{u_ent.id}`")
                                    else:
                                        admins_list.append(f"`{p.user_id}`")
                except Exception:
                    pass

                photos = await photos_task
                if isinstance(photos, Exception):
                    photos = []

                # استخراج هوشمند لینک یا یوزرنیم بر اساس موجودیت چت
                link_label_fa = "لینک" if is_fa else "Link"
                link_label_en = "Link"
                link_display = "ندارد" if is_fa else "None"

                if getattr(entity, "username", None):
                    link_label_fa = "یوزرنیم"
                    link_label_en = "Username"
                    link_display = f"@{entity.username}"
                elif full_chat and getattr(full_chat, "exported_invite", None):
                    link_display = full_chat.exported_invite.link

                # وضعیت پرمیوم
                is_premium_chat = "بله" if getattr(entity, "premium", False) else "خیر"
                is_premium_chat_en = "Yes" if getattr(entity, "premium", False) else "No"

                # فرمت کردن لیست ادمین‌ها
                if admins_list:
                    admins_display = ", ".join(admins_list[:10]) # محدود به ۱۰ ادمین اول
                    if len(admins_list) > 10:
                        admins_display += " ..."
                else:
                    admins_display = "نامشخص" if is_fa else "Unknown"

                time_str = format_time(is_fa)
                title = entity.title or ("بدون نام" if is_fa else "No title")

                if is_fa:
                    caption = (
                        f"📦 بکاپ {chat_type_fa}\n\n"
                        f"👤 نام {chat_type_fa}: {title}\n"
                        f"🔗 {link_label_fa}: {link_display}\n"                    
                        f"🆔 آیدی عددی: {entity.id}\n"
                        f"👥 تعداد اعضا: {member_count}\n"
                        f"👑 مالک: {owner_display}\n"
                        f"👮 ادمین‌ها: {admins_display}\n"
                        f"⭐ پرمیوم: {is_premium_chat}\n"
                        f"⏱ زمان: {time_str}"
                    )
                else:
                    caption = (
                        f"📦 {chat_type_en.upper()} BACKUP\n\n"
                        f"👤 {chat_type_en} Name: {title}\n"
                        f"🔗 {link_label_en}: {link_display}\n"
                        f"🆔 ID: {entity.id}\n"
                        f"👥 Members: {member_count}\n"
                        f"👑 Owner: {owner_display}\n"
                        f"👮 Admins: {admins_display}\n"
                        f"⭐ Premium: {is_premium_chat_en}\n"
                        f"⏱ Time: {time_str}"
                    )

                try:
                    if photos:
                        await client.send_file(event.chat_id, photos, caption=caption)
                        await event.delete()
                    else:
                        await event.reply(caption)
                        await event.delete()
                except Exception as e:
                    await event.reply(f"Error: {e}")

            else:
                err = "❌ ساختار ناشناخته" if is_fa else "❌ Unknown structure"
                await event.reply(err)

        except Exception as e:
            try:
                await event.reply(f"Error: {e}")
            except Exception:
                pass