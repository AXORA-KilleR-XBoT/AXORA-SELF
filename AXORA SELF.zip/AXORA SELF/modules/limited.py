import asyncio
import json
from pathlib import Path
from datetime import datetime
from telethon import events
from telethon.tl.types import (
    DocumentAttributeAnimated, DocumentAttributeSticker,
    MessageEntityHashtag, MessageEntityMention, MessageEntityMentionName,
    MessageEntitySpoiler, MessageEntityUrl, MessageEntityTextUrl, MessageMediaGame,
)

from core.state import state
from core.utils import parse_time_range, default_flags, is_only_emoji
from core import panel_state

_client_ref = None
_my_id: int | None = None

async def _get_my_id() -> int:
    global _my_id
    if _my_id is None and _client_ref is not None:
        try:
            _my_id = (await _client_ref.get_me()).id
        except Exception:
            return 0
    return _my_id or 0

# پنل state رو ایمپورت می‌کنیم
try:
    from modules.panel import get_media_flags as _panel_flags
    PANEL_AVAILABLE = True
except ImportError:
    PANEL_AVAILABLE = False
    async def _panel_flags(chat_id): return {}

# ===================== CODE 1 (SILENCE) =====================

def setup_silence(client):
    @client.on(events.NewMessage(outgoing=True))
    async def timed_silence_command(event):
        if not event.is_private:
            return

        rng = parse_time_range(event.raw_text or "")
        if not rng:
            return

        start, end = rng
        state.timed_silence[event.chat_id] = (start, end)

        await event.delete()
        await client.send_message(event.chat_id, f"⏰ سکوت زمان‌بندی شد\nاز {start.strftime('%H:%M')} تا {end.strftime('%H:%M')}")

    @client.on(events.NewMessage(incoming=True))
    async def timed_silence_enforcer(event):
        if not event.is_private:
            return

        settings = state.timed_silence.get(event.chat_id)
        if not settings:
            return

        start, end = settings
        now = datetime.now().time()
        active = (start <= now <= end) if start <= end else (now >= start or now <= end)

        if active:
            try:
                await event.delete()
            except Exception:
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=r"^(سکوت|سکوت خاموش)$"))
    async def manual_silence_command(event):
        reply = await event.get_reply_message()
        if not reply:
            await event.reply("❌ باید روی پیام فرد ریپلای کنی")
            return

        uid = reply.sender_id
        chat_id = event.chat_id
        state.manual_silence.setdefault(chat_id, set())

        text = event.raw_text.strip()
        if text == "سکوت":
            state.manual_silence[chat_id].add(uid)
            await event.delete()
            await client.send_message(chat_id, "🔇 کاربر سایلنت شد")
        else:
            state.manual_silence[chat_id].discard(uid)
            await event.delete()
            await client.send_message(chat_id, "🔊 سکوت خاموش شد")

    @client.on(events.NewMessage(incoming=True))
    async def manual_silence_enforcer(event):
        me = await client.get_me()
        if event.sender_id == me.id:
            return

        silents = state.manual_silence.get(event.chat_id)
        if silents and event.sender_id in silents:
            try:
                await event.delete()
            except Exception:
                pass


# ===================== CODE 2 (MEDIA BLOCK) =====================

LONG_MESSAGE_THRESHOLD = 300  # پیام‌های متنیِ بلندتر از این تعداد کاراکتر «طولانی» حساب می‌شن

_MEDIA_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

def is_gif(msg):
    return bool(msg.document and any(isinstance(a, DocumentAttributeAnimated) for a in msg.document.attributes))

def is_sticker(msg):
    return bool(msg.document and any(isinstance(a, DocumentAttributeSticker) for a in msg.document.attributes))

def is_emoji(msg):
    return is_only_emoji(msg.message or "")

def is_videonote(msg):
    return bool(msg.video_note)

def is_plain_message(msg):
    """پیام متنی خالی - بدون هیچ نوع مدیا (گیف/استیکر/ویس/ویدیو/عکس/ویدیومسیج و ...)"""
    if msg.media:
        return False
    return bool((msg.message or "").strip())

# ── جدید: ۱۲ تشخیص‌دهنده‌ی تازه ──────────────────────────────
def is_music(msg):
    return bool(msg.audio)

def is_poll(msg):
    return bool(msg.poll)

def is_game(msg):
    return isinstance(getattr(msg, "media", None), MessageMediaGame)

def is_inline_sent(msg):
    return bool(getattr(msg, "via_bot_id", None))

def _entities_have(msg, *types):
    ents = msg.entities or []
    return any(isinstance(e, types) for e in ents)

def is_hashtag(msg):
    return _entities_have(msg, MessageEntityHashtag)

def is_mention(msg):
    return _entities_have(msg, MessageEntityMention, MessageEntityMentionName)

def is_spoiler(msg):
    if _entities_have(msg, MessageEntitySpoiler):
        return True
    media = getattr(msg, "media", None)
    return bool(media and getattr(media, "spoiler", False))

def is_long_message(msg):
    return len(msg.message or "") > LONG_MESSAGE_THRESHOLD

def is_link(msg):
    if _entities_have(msg, MessageEntityUrl, MessageEntityTextUrl):
        return True
    low = (msg.message or "").lower()
    return ("http://" in low) or ("https://" in low) or ("www." in low) or ("t.me/" in low)

def is_forward(msg):
    return bool(msg.forward)

def is_file(msg):
    """فایل عمومی - سندی که گیف/استیکر/موزیک/ویس/ویدیو/ویدیومسیج نباشه."""
    if not msg.document:
        return False
    if is_gif(msg) or is_sticker(msg) or is_music(msg):
        return False
    if bool(msg.voice) or bool(msg.video) or is_videonote(msg):
        return False
    return True


# ── جدید: نگاشت کامل قفل‌ها = (نام مطابقتِ بدون نیم‌فاصله برای پردازش دستور,
# نام نمایشی درست برای پیام تایید, کلید فلگ) ──────────────────
_LOCK_TYPES = [
    ("گیف",            "گیف",              "gif"),
    ("استیکر",         "استیکر",           "sticker"),
    ("ایموجی",         "ایموجی",           "emoji"),
    ("ویس",            "ویس",              "voice"),
    ("ویدیو",          "ویدیو",            "video"),
    ("عکس",            "عکس",              "photo"),
    ("ویدیو مسیج",     "ویدیو مسیج",       "videonote"),
    ("پیام",           "پیام",             "message"),
    ("فایل",           "فایل",             "file"),
    ("موسیقی",         "موسیقی",           "music"),
    ("نظرسنجی",        "نظرسنجی",          "poll"),
    ("بازیها",         "بازی‌ها",           "games"),
    ("اینلاین",        "اینلاین",          "inline"),
    ("هشتگ",           "هشتگ",             "hashtag"),
    ("منشن",           "منشن",             "mention"),
    ("اسپویلر",        "اسپویلر",          "spoiler"),
    ("پیامهای طولانی", "پیام‌های طولانی",   "longmsg"),
    ("لینک",           "لینک",             "link"),
    ("فوروارد",        "فوروارد",          "forward"),
    ("رباتها",         "ربات‌ها",           "bots"),
]

def _extended_default_flags() -> dict:
    """فلگ‌های قبلی از core.utils پایه گرفته می‌شه، ۱۲ قفل جدید هم روش اضافه
    می‌شه - هیچ تغییری توی core/utils.py لازم نیست."""
    d = default_flags()
    for _, _, key in _LOCK_TYPES:
        d.setdefault(key, False)
    return d

def _strip_zwnj(s: str) -> str:
    return (s or "").replace("\u200c", "").strip()

# ✅ به جای «<نوع> مرده/زنده» قدیمی، حالا «قفل <نوع>» / «باز <نوع>» - نیم‌فاصله
# اختیاریه (چه بنویسی چه ننویسی کار می‌کنه چون نرمال می‌شه)
_LOCK_PATTERNS = {}   # متن نرمال‌شده → (کلید فلگ یا None برای «همه», آیا قفله)
_LOCK_DISPLAY  = {}   # کلید فلگ → نام نمایشی فارسی درست
for _match_name, _display_name, _flag_key in _LOCK_TYPES:
    _LOCK_PATTERNS[f"قفل {_match_name}"] = (_flag_key, True)
    _LOCK_PATTERNS[f"باز {_match_name}"]  = (_flag_key, False)
    _LOCK_DISPLAY[_flag_key] = _display_name
_LOCK_PATTERNS["قفل همه"] = (None, True)
_LOCK_PATTERNS["باز همه"] = (None, False)


def ensure_private_flags(chat_id: int):
    if chat_id not in state.blocked_types_private:
        state.blocked_types_private[chat_id] = _extended_default_flags().copy()
    return state.blocked_types_private[chat_id]


async def _sync_panel_media_flag(chat_id: int, key: str, val: bool):
    """این تغییر رو هم توی panel_state.json ذخیره می‌کنه (همون‌جایی که پنل و
    get_media_flags می‌خونن) - مستقل از state.blocked_types_private که فقط تو
    حافظه‌ست. اینجوری پنل هم دقیقاً همون تیک درست رو نشون می‌ده.
    ✅ عملکرد+ایمنی: قبلاً سنکرون بود (بلاک‌کننده) و بدونِ هیچ قفلی روی فایلِ
    مشترکِ panel_state.json می‌نوشت - حالا از core/panel_state.py رد می‌شه."""
    async with panel_state.transaction() as data:
        mine        = data.setdefault(str(await _get_my_id()), {})
        chat_data   = mine.setdefault(str(chat_id), {})
        media_flags = chat_data.setdefault("media_flags", {})
        media_flags[key] = val


def setup_media_block(client):
    @client.on(events.NewMessage(outgoing=True))
    async def block_commands(event):
        text      = (event.raw_text or "").strip()
        chat_id   = event.chat_id
        text_norm = _strip_zwnj(text)

        if text_norm not in _LOCK_PATTERNS:
            return
        key, val = _LOCK_PATTERNS[text_norm]

        if event.is_private:
            flags = ensure_private_flags(chat_id)
            if key:
                flags[key] = val
                await _sync_panel_media_flag(chat_id, key, val)
            else:
                for k in _extended_default_flags():
                    flags[k] = val
                    await _sync_panel_media_flag(chat_id, k, val)
            await event.delete()
            await client.send_message(chat_id, "✅ انجام شد")
            return

        if event.is_group or event.is_channel:
            # ✅ جدید: فقط ادمین یا مالک گروه/کانال بتونه قفل/باز کنه
            try:
                perms = await client.get_permissions(chat_id, "me")
                is_admin_or_owner = bool(perms.is_admin or perms.is_creator)
            except Exception:
                is_admin_or_owner = False

            if not is_admin_or_owner:
                try:
                    await event.reply("🚫 برای قفل/باز کردن محدودیت‌ها باید توی این گروه ادمین یا مالک باشی.")
                except Exception:
                    pass
                return

            reply     = await event.get_reply_message()
            label     = _LOCK_DISPLAY.get(key, "همه") if key else "همه"
            state_txt = "قفل" if val else "باز"

            if reply:
                # ✅ جدید: فقط برای همون کاربر ریپلای‌شده - override مستقل از تنظیم کل گروه
                target_id   = reply.sender_id
                group_flags = state.restricted_users_group.setdefault(chat_id, {})
                user_flags  = group_flags.setdefault(target_id, {})
                if key:
                    user_flags[key] = val
                else:
                    for k in _extended_default_flags():
                        user_flags[k] = val
                await event.delete()
                try:
                    await client.send_message(chat_id, f"✅ {label} برای این کاربر {state_txt} شد.")
                except Exception:
                    pass
            else:
                # ✅ کل گروه - دقیقاً همون media_flags که پنل هم می‌خونه/می‌نویسه
                if key:
                    await _sync_panel_media_flag(chat_id, key, val)
                else:
                    for k in _extended_default_flags():
                        await _sync_panel_media_flag(chat_id, k, val)
                await event.delete()
                try:
                    await client.send_message(chat_id, f"✅ {label} برای کل گروه {state_txt} شد.")
                except Exception:
                    pass
            return

    @client.on(events.NewMessage(incoming=True))
    async def auto_delete_media(event):
        me = await client.get_me()
        if event.sender_id == me.id:
            return

        msg = event.message

        _is_gif       = is_gif(msg)
        _is_st        = is_sticker(msg)
        _is_em        = is_emoji(msg)
        _is_voice     = bool(msg.voice)
        _is_video     = bool(msg.video)
        _is_videonote = is_videonote(msg)      # ← fix: جدا از video
        _is_photo     = bool(msg.photo)
        _is_msg       = is_plain_message(msg)  # ← جدید: پیام متنی خالی
        # ── جدید: ۱۲ قفل تازه ──
        _is_file      = is_file(msg)
        _is_music     = is_music(msg)
        _is_poll      = is_poll(msg)
        _is_game      = is_game(msg)
        _is_inline    = is_inline_sent(msg)
        _is_hashtag   = is_hashtag(msg)
        _is_mention   = is_mention(msg)
        _is_spoiler   = is_spoiler(msg)
        _is_long      = is_long_message(msg)
        _is_link      = is_link(msg)
        _is_forward   = is_forward(msg)

        # فلگ‌های پنل (اولویت بالاتر)
        try:
            panel_flags = await _panel_flags(event.chat_id)
        except Exception as e:
            panel_flags = {}
            print("PANEL ERROR:", e)

        # فلگ‌های دستوری
        state_flags = {}
        if event.is_private:
            state_flags = state.blocked_types_private.get(event.chat_id, {})
        elif event.is_group:
            state_flags = state.restricted_users_group.get(event.chat_id, {}).get(event.sender_id, {})

        def blocked(key):
            # ✅ جدید: اگه برای همین کاربر override صریح ثبت شده (چه قفل چه باز)
            # همون برنده‌ست، وگرنه برو سراغ تنظیم کل گروه/پنل (media_flags).
            override = state_flags.get(key)
            if override is not None:
                return override
            return panel_flags.get(key, False)

        should_delete = (
            (blocked("gif")       and _is_gif)       or
            (blocked("sticker")   and _is_st)        or
            (blocked("emoji")     and _is_em)        or
            (blocked("voice")     and _is_voice)     or
            (blocked("video")     and _is_video)     or
            (blocked("videonote") and _is_videonote) or   # ← fix: چک مجزا
            (blocked("photo")     and _is_photo)     or
            (blocked("message")   and _is_msg)       or   # ← جدید: مسدودسازی پیام متنی
            (blocked("file")      and _is_file)      or
            (blocked("music")     and _is_music)     or
            (blocked("poll")      and _is_poll)      or
            (blocked("games")     and _is_game)      or
            (blocked("inline")    and _is_inline)    or
            (blocked("hashtag")   and _is_hashtag)   or
            (blocked("mention")   and _is_mention)   or
            (blocked("spoiler")   and _is_spoiler)   or
            (blocked("longmsg")   and _is_long)      or
            (blocked("link")      and _is_link)      or
            (blocked("forward")   and _is_forward)
        )

        # ── ربات‌ها: فقط وقتی واقعاً لازمه (قفله) فرستنده رو چک کن، چون یه
        # فراخوانی get_sender اضافه داره - برای همین فقط شرطی صداش می‌زنیم ──
        if not should_delete and blocked("bots"):
            try:
                sender = await event.get_sender()
                if bool(getattr(sender, "bot", False)):
                    should_delete = True
            except Exception:
                pass

        if should_delete:
            try:
                await event.delete()
            except Exception:
                pass
            return  # بعد از حذف ادامه نده

        # سکوت پنل — فقط پیام‌های incoming
        # (outgoing رو پاک نمی‌کنیم چون پیام‌های خودمونه)
        if panel_flags.get("silence", False):
            try:
                await event.delete()
            except Exception:
                pass


# ===================== CODE 3 (کلمه غیر مجاز / BANNED WORDS) =====================
# ⚠️ این بخش کاملاً مستقل و جدیده، به هیچ‌کدوم از کدهای بالا دست نخورده.
# هر چتی (پیوی/گروه/چنل) که از پنل برایش کلمه‌ی غیرمجاز ثبت شده باشه، هر
# پیامی که شامل یکی از اون کلمات باشه همون لحظه پاک می‌شه.

_BW_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"
_BW_PROMPT_FA  = "📝 کلمات غیر مجاز خود را ارسال نمایید (هر کلمه در یک خط):"
_BW_PROMPT_EN  = "📝 Please send your banned words (one per line):"

_handling_bw_add = False


async def _bw_load_all() -> dict:
    """✅ عملکرد+ایمنی: قبلاً سنکرون بود؛ حالا از core/panel_state.py رد می‌شه
    که هم بلاک نمی‌کنه هم بینِ ~۲۰ ماژولی که همین فایل رو می‌خونن/می‌نویسن قفلِ
    مشترک داره."""
    return await panel_state.load()

async def _bw_get_global() -> dict:
    return (await _bw_load_all()).get(str(await _get_my_id()), {}).get("_global", {})

async def _bw_set_global(g: dict):
    async with panel_state.transaction() as data:
        data.setdefault(str(await _get_my_id()), {})["_global"] = g

async def _bw_get_words(chat_id: int) -> list:
    data = await _bw_load_all()
    return data.get(str(await _get_my_id()), {}).get(str(chat_id), {}).get("banned_words", [])

async def _bw_set_words(chat_id: int, words: list):
    async with panel_state.transaction() as data:
        mine = data.setdefault(str(await _get_my_id()), {})
        key  = str(chat_id)
        mine.setdefault(key, {})
        mine[key]["banned_words"] = words

async def _bw_process_add_request(client, req: dict):
    global _handling_bw_add
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_bw_add = False
        return
    try:
        msg = await client.send_message(chat_id, _BW_PROMPT_FA)
    except Exception:
        _handling_bw_add = False
        return
    g = await _bw_get_global()
    g.pop("banned_words_add", None)
    g["banned_words_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _bw_set_global(g)
    _handling_bw_add = False


async def _bw_request_loop(client):
    global _handling_bw_add
    while True:
        try:
            g   = await _bw_get_global()
            req = g.get("banned_words_add")
            if req and not _handling_bw_add:
                _handling_bw_add = True
                asyncio.get_event_loop().create_task(_bw_process_add_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(3)


def setup_banned_words(client):

    # ── گرفتن کلمات از کاربر، توی همون چتی که پنل باز شده ──
    @client.on(events.NewMessage(outgoing=True))
    async def bw_add_catcher(event):
        text = (event.raw_text or "").strip()
        if text in (_BW_PROMPT_FA, _BW_PROMPT_EN):
            return

        g       = await _bw_get_global()
        waiting = g.get("banned_words_waiting")
        if not waiting:
            return
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        new_words = [w.strip() for w in text.splitlines() if w.strip()]
        if not new_words:
            try:
                await event.reply("❌ هیچ کلمه‌ای پیدا نشد. دوباره بفرست، هر کلمه توی یک خط.")
            except Exception:
                pass
            return  # حالت انتظار رو نگه می‌داریم تا دوباره تلاش کنه

        g.pop("banned_words_waiting", None)
        await _bw_set_global(g)

        words          = await _bw_get_words(event.chat_id)
        existing_lower = {w.lower() for w in words}
        added = []
        for w in new_words:
            if w.lower() not in existing_lower:
                words.append(w)
                existing_lower.add(w.lower())
                added.append(w)
        await _bw_set_words(event.chat_id, words)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass

        if added:
            lines = "\n".join(f"🚫 {w}" for w in added)
            try:
                await client.send_message(event.chat_id, f"کلمات زیر به لیست کلمات غیرمجاز این چت اضافه شدن:\n\n{lines}")
            except Exception:
                pass

    # ── حذف خودکار پیام‌هایی که شامل کلمات غیرمجاز هستن (پیوی/گروه/چنل) ──
    @client.on(events.NewMessage(incoming=True))
    async def bw_enforcer(event):
        words = await _bw_get_words(event.chat_id)
        if not words:
            return

        text = event.raw_text or ""
        if not text:
            return

        low = text.lower()
        for w in words:
            if w.lower() in low:
                try:
                    await event.delete()
                except Exception:
                    pass
                return

    try:
        asyncio.get_event_loop().create_task(_bw_request_loop(client))
    except Exception:
        pass


# ===================== FINAL (ONE SETUP) =====================

def setup(client):
    global _client_ref
    _client_ref = client
    setup_silence(client)
    setup_media_block(client)
    setup_banned_words(client)