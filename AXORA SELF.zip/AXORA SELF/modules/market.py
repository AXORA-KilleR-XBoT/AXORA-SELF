# modules/market.py
"""
ماژول قیمت‌های بازار — نسخه ۲ (Market Prices Module v2)
══════════════════════════════════════════════════════════════════════════
این فایل به‌صورت کامل بازنویسی شده تا از گرامر «دارایی به واحد» با فاصله
(مثل «/دلار به تومن») پشتیبانی کند، تمام ارزهای جهان را بشناسد، طلای هر
کشوری را به هر ارزی تبدیل کند، رمزارزها را به هر ارزی تبدیل کند، و دو
فهرست کامل (۲۰۰ رمزارز برتر و تمام پول‌های جهان) ارائه دهد.

نکتهٔ معماری مهم: تنها یک هندلر Telethon با الگوی عمومی «/...» ثبت می‌شود.
اگر دستور ورودی به‌هیچ‌کدام از موضوعات این ماژول (ارز، طلا، رمزارز، فهرست‌ها)
مربوط نباشد، هندلر بدون پاسخ و بی‌صدا خارج می‌شود — یعنی هیچ تداخلی با سایر
ماژول‌های ربات (panel.py، downloader.py، auto_reply.py و...) ایجاد نمی‌شود.

راهنمای کامل کاربر در HELP_TEXT و با دستور /بازار در دسترس است.
"""

import os
import re
import time
import json
import asyncio
import aiohttp
from telethon import events

# ════════════════════════════════════════════════════════════════════════
#  تنظیمات / Config
# ════════════════════════════════════════════════════════════════════════
REQUEST_TIMEOUT   = 15     # ثانیه برای هر درخواست HTTP
CACHE_TTL         = 25     # ثانیه — کش پایه (صفحات TGJU و...)
RATES_CACHE_TTL   = 90     # ثانیه — نرخ صلیبی ارزهای فیات
GOLD_CACHE_TTL    = 60     # ثانیه — قیمت جهانی طلا
CRYPTO_CACHE_TTL  = 45     # ثانیه — فهرست بازار رمزارزها
GRAMS_PER_OUNCE   = 31.1034768

# اگر سرور شما برای دسترسی به API‌های خارجی به پراکسی نیاز دارد، این متغیر
# محیطی را تنظیم کنید: MARKET_HTTP_PROXY=http://user:pass@host:port
PROXY_URL = os.environ.get("MARKET_HTTP_PROXY") or None

# ════════════════════════════════════════════════════════════════════════
#  منابع داده / Data Sources
# ════════════════════════════════════════════════════════════════════════
TGJU_USD    = "https://english.tgju.org/profile/price_dollar_rl"
TGJU_GOLD18 = "https://english.tgju.org/profile/geram18"

NOBITEX_GLOBAL = "https://api.nobitex.ir/market/stats/global"

EXCHANGERATE_API = "https://open.er-api.com/v6/latest/USD"

# قیمت جهانی طلا (دلار به ازای هر اونس تروی) — بدون نیاز به کلید
GOLD_API_PRIMARY = "https://api.gold-api.com/price/XAU"

COINGECKO_MARKETS_TMPL = (
    "https://api.coingecko.com/api/v3/coins/markets"
    "?vs_currency=usd&order=market_cap_desc&per_page={n}&page=1&sparkline=false"
)

# ════════════════════════════════════════════════════════════════════════
#  کش / Cache
# ════════════════════════════════════════════════════════════════════════
_cache: dict = {}


# ════════════════════════════════════════════════════════════════════════
#  پایگاه‌دادهٔ ارزها / Currency Database
#  (نام فارسی + پرچم) برای هر کد ISO — برای نمایش خروجی
# ════════════════════════════════════════════════════════════════════════
CURRENCY_INFO = {
    "IRT": ("تومان", "🇮🇷"),
    "KPW": ("وون کره شمالی", "🇰🇵"),
    "AED": ("درهم امارات", "🇦🇪"),
    "AFN": ("افغانی", "🇦🇫"),
    "ALL": ("لک آلبانی", "🇦🇱"),
    "AMD": ("درام ارمنستان", "🇦🇲"),
    "ANG": ("گیلدر آنتیل هلند", "🇨🇼"),
    "AOA": ("کوانزای آنگولا", "🇦🇴"),
    "ARS": ("پزوی آرژانتین", "🇦🇷"),
    "AUD": ("دلار استرالیا", "🇦🇺"),
    "AWG": ("فلورین آروبا", "🇦🇼"),
    "AZN": ("منات جمهوری آذربایجان", "🇦🇿"),
    "BAM": ("مارک تبدیل‌پذیر بوسنی و هرزگوین", "🇧🇦"),
    "BBD": ("دلار باربادوس", "🇧🇧"),
    "BDT": ("تاکای بنگلادش", "🇧🇩"),
    "BGN": ("لو بلغارستان", "🇧🇬"),
    "BHD": ("دینار بحرین", "🇧🇭"),
    "BIF": ("فرانک بوروندی", "🇧🇮"),
    "BMD": ("دلار برمودا", "🇧🇲"),
    "BND": ("دلار برونئی", "🇧🇳"),
    "BOB": ("بولیویانوی بولیوی", "🇧🇴"),
    "BRL": ("رئال برزیل", "🇧🇷"),
    "BSD": ("دلار باهاما", "🇧🇸"),
    "BTN": ("انگولتروم بوتان", "🇧🇹"),
    "BWP": ("پولای بوتسوانا", "🇧🇼"),
    "BYN": ("روبل بلاروس", "🇧🇾"),
    "BZD": ("دلار بلیز", "🇧🇿"),
    "CAD": ("دلار کانادا", "🇨🇦"),
    "CDF": ("فرانک کنگو", "🇨🇩"),
    "CHF": ("فرانک سوئیس", "🇨🇭"),
    "CLP": ("پزوی شیلی", "🇨🇱"),
    "CNY": ("یوان چین", "🇨🇳"),
    "COP": ("پزوی کلمبیا", "🇨🇴"),
    "CRC": ("کولون کاستاریکا", "🇨🇷"),
    "CUP": ("پزوی کوبا", "🇨🇺"),
    "CVE": ("اسکودوی کیپ‌ورد", "🇨🇻"),
    "CZK": ("کورونای جمهوری چک", "🇨🇿"),
    "DJF": ("فرانک جیبوتی", "🇩🇯"),
    "DKK": ("کرون دانمارک", "🇩🇰"),
    "DOP": ("پزوی جمهوری دومینیکن", "🇩🇴"),
    "DZD": ("دینار الجزایر", "🇩🇿"),
    "EGP": ("پوند مصر", "🇪🇬"),
    "ERN": ("ناکفای اریتره", "🇪🇷"),
    "ETB": ("بیر اتیوپی", "🇪🇹"),
    "EUR": ("یورو", "🇪🇺"),
    "FJD": ("دلار فیجی", "🇫🇯"),
    "FKP": ("پوند جزایر فالکلند", "🇫🇰"),
    "GBP": ("پوند انگلیس", "🇬🇧"),
    "GEL": ("لاری گرجستان", "🇬🇪"),
    "GGP": ("پوند گرنزی", "🇬🇬"),
    "GHS": ("سدی غنا", "🇬🇭"),
    "GIP": ("پوند جبل‌الطارق", "🇬🇮"),
    "GMD": ("دالاسی گامبیا", "🇬🇲"),
    "GNF": ("فرانک گینه", "🇬🇳"),
    "GTQ": ("کتزال گواتمالا", "🇬🇹"),
    "GYD": ("دلار گویانا", "🇬🇾"),
    "HKD": ("دلار هنگ‌کنگ", "🇭🇰"),
    "HNL": ("لمپیرای هندوراس", "🇭🇳"),
    "HTG": ("گورد هائیتی", "🇭🇹"),
    "HUF": ("فورینت مجارستان", "🇭🇺"),
    "IDR": ("روپیه اندونزی", "🇮🇩"),
    "ILS": ("شِکِل جدید اسرائیل", "🇮🇱"),
    "IMP": ("پوند جزیره من", "🇮🇲"),
    "INR": ("روپیه هند", "🇮🇳"),
    "IQD": ("دینار عراق", "🇮🇶"),
    "IRR": ("ریال ایران", "🇮🇷"),
    "ISK": ("کرونای ایسلند", "🇮🇸"),
    "JEP": ("پوند جرزی", "🇯🇪"),
    "JMD": ("دلار جامائیکا", "🇯🇲"),
    "JOD": ("دینار اردن", "🇯🇴"),
    "JPY": ("ین ژاپن", "🇯🇵"),
    "KES": ("شیلینگ کنیا", "🇰🇪"),
    "KGS": ("سوم قرقیزستان", "🇰🇬"),
    "KHR": ("ری‌یل کامبوج", "🇰🇭"),
    "KMF": ("فرانک کومورو", "🇰🇲"),
    "KRW": ("وون کره جنوبی", "🇰🇷"),
    "KWD": ("دینار کویت", "🇰🇼"),
    "KYD": ("دلار جزایر کِیمن", "🇰🇾"),
    "KZT": ("تنگه قزاقستان", "🇰🇿"),
    "LAK": ("کیپ لائوس", "🇱🇦"),
    "LBP": ("لیر لبنان", "🇱🇧"),
    "LKR": ("روپیه سری‌لانکا", "🇱🇰"),
    "LRD": ("دلار لیبریا", "🇱🇷"),
    "LSL": ("لوتی لسوتو", "🇱🇸"),
    "LYD": ("دینار لیبی", "🇱🇾"),
    "MAD": ("درهم مراکش", "🇲🇦"),
    "MDL": ("لئوی مولداوی", "🇲🇩"),
    "MGA": ("آریاری مالاگاسی", "🇲🇬"),
    "MKD": ("دینار مقدونیه", "🇲🇰"),
    "MMK": ("کیات میانمار", "🇲🇲"),
    "MNT": ("توگریک مغولستان", "🇲🇳"),
    "MOP": ("پاتاکای ماکائو", "🇲🇴"),
    "MRU": ("اوگوئیای موریتانی", "🇲🇷"),
    "MUR": ("روپیه موریس", "🇲🇺"),
    "MVR": ("روپیه مالدیو", "🇲🇻"),
    "MWK": ("کواچای مالاوی", "🇲🇼"),
    "MXN": ("پزوی مکزیک", "🇲🇽"),
    "MYR": ("رینگیت مالزی", "🇲🇾"),
    "MZN": ("متیکال موزامبیک", "🇲🇿"),
    "NAD": ("دلار نامیبیا", "🇳🇦"),
    "NGN": ("نایرای نیجریه", "🇳🇬"),
    "NIO": ("کوردوبای نیکاراگوئه", "🇳🇮"),
    "NOK": ("کرون نروژ", "🇳🇴"),
    "NPR": ("روپیه نپال", "🇳🇵"),
    "NZD": ("دلار نیوزیلند", "🇳🇿"),
    "OMR": ("ریال عمان", "🇴🇲"),
    "PAB": ("بالبوای پاناما", "🇵🇦"),
    "PEN": ("سول پرو", "🇵🇪"),
    "PGK": ("کینای پاپوا گینه نو", "🇵🇬"),
    "PHP": ("پزوی فیلیپین", "🇵🇭"),
    "PKR": ("روپیه پاکستان", "🇵🇰"),
    "PLN": ("زلوتی لهستان", "🇵🇱"),
    "PYG": ("گوارانی پاراگوئه", "🇵🇾"),
    "QAR": ("ریال قطر", "🇶🇦"),
    "RON": ("لئوی رومانی", "🇷🇴"),
    "RSD": ("دینار صربستان", "🇷🇸"),
    "RUB": ("روبل روسیه", "🇷🇺"),
    "RWF": ("فرانک رواندا", "🇷🇼"),
    "SAR": ("ریال سعودی", "🇸🇦"),
    "SBD": ("دلار جزایر سلیمان", "🇸🇧"),
    "SCR": ("روپیه سیشل", "🇸🇨"),
    "SDG": ("پوند سودان", "🇸🇩"),
    "SEK": ("کرون سوئد", "🇸🇪"),
    "SGD": ("دلار سنگاپور", "🇸🇬"),
    "SHP": ("پوند سنت هلن", "🇸🇭"),
    "SLE": ("لئون سیرالئون", "🇸🇱"),
    "SOS": ("شیلینگ سومالی", "🇸🇴"),
    "SRD": ("دلار سورینام", "🇸🇷"),
    "SSP": ("پوند سودان جنوبی", "🇸🇸"),
    "STN": ("دوبرای سائوتومه و پرنسیپ", "🇸🇹"),
    "SYP": ("لیر سوریه", "🇸🇾"),
    "SZL": ("لیلانگنی سوازیلند", "🇸🇿"),
    "THB": ("بات تایلند", "🇹🇭"),
    "TJS": ("سامانی تاجیکستان", "🇹🇯"),
    "TMT": ("منات ترکمنستان", "🇹🇲"),
    "TND": ("دینار تونس", "🇹🇳"),
    "TOP": ("پاآنگای تونگا", "🇹🇴"),
    "TRY": ("لیر ترکیه", "🇹🇷"),
    "TTD": ("دلار ترینیداد و توباگو", "🇹🇹"),
    "TWD": ("دلار جدید تایوان", "🇹🇼"),
    "TZS": ("شیلینگ تانزانیا", "🇹🇿"),
    "UAH": ("هریونیای اوکراین", "🇺🇦"),
    "UGX": ("شیلینگ اوگاندا", "🇺🇬"),
    "USD": ("دلار آمریکا", "🇺🇸"),
    "UYU": ("پزوی اوروگوئه", "🇺🇾"),
    "UZS": ("سوم ازبکستان", "🇺🇿"),
    "VES": ("بولیوار ونزوئلا", "🇻🇪"),
    "VND": ("دانگ ویتنام", "🇻🇳"),
    "VUV": ("واتوی وانوواتو", "🇻🇺"),
    "WST": ("تالای ساموا", "🇼🇸"),
    "XAF": ("فرانک CFA مرکز افریقا", "🌍"),
    "XCD": ("دلار شرق کارائیب", "🌴"),
    "XOF": ("فرانک CFA غرب افریقا", "🌍"),
    "XPF": ("فرانک اقیانوسیه", "🌴"),
    "YER": ("ریال یمن", "🇾🇪"),
    "ZAR": ("راند افریقای جنوبی", "🇿🇦"),
    "ZMW": ("کواچای زامبیا", "🇿🇲"),
    "ZWG": ("زیمبابوه‌گلد", "🇿🇼"),
}


# ════════════════════════════════════════════════════════════════════════
#  مستعارهای ورودی ارزهای فیات / Fiat Input Aliases
#  هر کلمهٔ فارسی یا انگلیسی رایج که کاربر ممکن است بنویسد، اینجا به کد
#  ISO نگاشت می‌شود. پشتیبانی کامل از تمام پول‌های جهان: حتی اگر یک ارز
#  در این فهرست دستی نباشد، با تایپ مستقیم کد سه‌حرفی‌اش (مثل XYZ) یا با
#  نام رسمی فارسی آن (که به‌صورت خودکار تشخیص داده می‌شود) قابل استفاده است.
# ════════════════════════════════════════════════════════════════════════
_FIAT_ALIAS_GROUPS = [
    ("IRT", ["تومان", "تومن", "toman", "irt", "تومان ایران", "تومن ایران"]),
    ("IRR", ["ریال", "ریال ایران", "rial", "irr"]),

    ("USD", ["دلار", "دلار آمریکا", "دلار امریکا", "دلار آمریکایی", "dollar", "usd", "us dollar"]),
    ("EUR", ["یورو", "euro", "eur"]),
    ("GBP", ["پوند", "پوند انگلیس", "پوند انگلستان", "پوند بریتانیا", "استرلینگ", "pound", "gbp", "sterling"]),

    ("TRY", ["لیر", "لیره", "لیر ترکیه", "لیره ترکیه", "lira", "try"]),
    ("LBP", ["لیر لبنان", "لیره لبنان", "lbp"]),
    ("SYP", ["لیر سوریه", "لیره سوریه", "syp"]),

    ("AED", ["درهم", "درهم امارات", "dirham", "aed"]),
    ("MAD", ["درهم مراکش", "mad"]),

    ("INR", ["روپیه", "روپیه هند", "rupee", "inr"]),
    ("IDR", ["روپیه اندونزی", "idr"]),
    ("PKR", ["روپیه پاکستان", "pkr"]),
    ("LKR", ["روپیه سریلانکا", "روپیه سری‌لانکا", "lkr"]),
    ("NPR", ["روپیه نپال", "npr"]),
    ("MUR", ["روپیه موریس", "mur"]),
    ("SCR", ["روپیه سیشل", "scr"]),
    ("MVR", ["روپیه مالدیو", "mvr"]),

    ("CNY", ["یوان", "یوآن", "یوان چین", "رنمینبی", "yuan", "rmb", "cny"]),
    ("MYR", ["رینگیت", "رینگیت مالزی", "ringgit", "myr"]),
    ("CHF", ["فرانک", "فرانک سوئیس", "franc", "chf"]),
    ("JPY", ["ین", "ین ژاپن", "yen", "jpy"]),
    ("RUB", ["روبل", "روبل روسیه", "ruble", "rub"]),
    ("BYN", ["روبل بلاروس", "byn"]),

    ("KWD", ["دینار", "دینار کویت", "dinar", "kwd"]),
    ("IQD", ["دینار عراق", "iqd"]),
    ("JOD", ["دینار اردن", "jod"]),
    ("BHD", ["دینار بحرین", "bhd"]),
    ("DZD", ["دینار الجزایر", "dzd"]),
    ("LYD", ["دینار لیبی", "lyd"]),
    ("TND", ["دینار تونس", "tnd"]),
    ("RSD", ["دینار صربستان", "rsd"]),
    ("MKD", ["دینار مقدونیه", "mkd"]),

    ("SAR", ["ریال سعودی", "ریال عربستان", "riyal", "sar"]),
    ("QAR", ["ریال قطر", "qar"]),
    ("OMR", ["ریال عمان", "omr"]),
    ("YER", ["ریال یمن", "yer"]),

    ("CAD", ["دلار کانادا", "cad"]),
    ("AUD", ["دلار استرالیا", "aud"]),
    ("NZD", ["دلار نیوزیلند", "دلار زلاند نو", "nzd"]),
    ("SGD", ["دلار سنگاپور", "sgd"]),
    ("HKD", ["دلار هنگ کنگ", "دلار هنگ‌کنگ", "hkd"]),
    ("TWD", ["دلار تایوان", "دلار جدید تایوان", "twd"]),
    ("BND", ["دلار برونئی", "bnd"]),
    ("FJD", ["دلار فیجی", "fjd"]),
    ("JMD", ["دلار جامائیکا", "jmd"]),
    ("BBD", ["دلار باربادوس", "bbd"]),
    ("BSD", ["دلار باهاما", "bsd"]),
    ("BZD", ["دلار بلیز", "bzd"]),
    ("GYD", ["دلار گویانا", "gyd"]),
    ("TTD", ["دلار ترینیداد", "دلار ترینیداد و توباگو", "ttd"]),
    ("XCD", ["دلار شرق کارائیب", "xcd"]),
    ("SBD", ["دلار جزایر سلیمان", "sbd"]),
    ("SRD", ["دلار سورینام", "srd"]),
    ("NAD", ["دلار نامیبیا", "nad"]),
    ("LRD", ["دلار لیبریا", "lrd"]),
    ("KYD", ["دلار کیمن", "دلار جزایر کیمن", "kyd"]),
    ("BMD", ["دلار برمودا", "bmd"]),

    ("MXN", ["پزو", "پزو مکزیک", "peso", "mxn"]),
    ("ARS", ["پزو آرژانتین", "ars"]),
    ("CLP", ["پزو شیلی", "clp"]),
    ("COP", ["پزو کلمبیا", "cop"]),
    ("CUP", ["پزو کوبا", "cup"]),
    ("DOP", ["پزو دومینیکن", "dop"]),
    ("UYU", ["پزو اروگوئه", "uyu"]),
    ("PHP", ["پزو فیلیپین", "php"]),

    ("BRL", ["رئال برزیل", "real برزیل", "brl"]),

    ("PLN", ["زلوتی", "زلوتی لهستان", "zloty", "pln"]),
    ("HUF", ["فورینت", "فورینت مجارستان", "forint", "huf"]),
    ("RON", ["لئو رومانی", "لو رومانی", "ron"]),
    ("BGN", ["لو بلغارستان", "bgn"]),
    ("UAH", ["هریونیا", "هریونیا اوکراین", "uah"]),

    ("KZT", ["تنگه قزاقستان", "kzt"]),
    ("AZN", ["منات آذربایجان", "azn"]),
    ("TMT", ["منات ترکمنستان", "tmt"]),
    ("AMD", ["درام ارمنستان", "amd"]),
    ("GEL", ["لاری گرجستان", "gel"]),
    ("UZS", ["سوم ازبکستان", "uzs"]),
    ("KGS", ["سوم قرقیزستان", "kgs"]),
    ("TJS", ["سامانی تاجیکستان", "tjs"]),
    ("AFN", ["افغانی", "افغانی افغانستان", "afn"]),
    ("MNT", ["توگریک مغولستان", "mnt"]),
    ("LAK", ["کیپ لائوس", "lak"]),
    ("KHR", ["ریل کامبوج", "khr"]),
    ("MMK", ["کیات میانمار", "mmk"]),
    ("VND", ["دانگ", "دانگ ویتنام", "dong", "vnd"]),
    ("THB", ["بات", "بات تایلند", "baht", "thb"]),
    ("KRW", ["وون", "وون کره", "وون کره جنوبی", "won", "krw"]),
    ("KPW", ["وون کره شمالی", "kpw"]),

    ("ILS", ["شکل", "شکل اسرائیل", "ils"]),
    ("EGP", ["پوند مصر", "egp"]),
    ("SDG", ["پوند سودان", "sdg"]),
    ("SSP", ["پوند سودان جنوبی", "ssp"]),
    ("GIP", ["پوند جبل الطارق", "gip"]),
    ("FKP", ["پوند فالکلند", "fkp"]),
    ("SHP", ["پوند سنت هلن", "shp"]),
    ("GGP", ["پوند گرنزی", "ggp"]),
    ("IMP", ["پوند جزیره من", "imp"]),
    ("JEP", ["پوند جرزی", "jep"]),

    ("ZAR", ["راند", "راند آفریقای جنوبی", "rand", "zar"]),
    ("NGN", ["نایرا", "نایرا نیجریه", "ngn"]),
    ("GHS", ["سدی غنا", "ghs"]),
    ("KES", ["شیلینگ کنیا", "kes"]),
    ("TZS", ["شیلینگ تانزانیا", "tzs"]),
    ("UGX", ["شیلینگ اوگاندا", "ugx"]),
    ("SOS", ["شیلینگ سومالی", "sos"]),
    ("ETB", ["بیر اتیوپی", "etb"]),

    ("XOF", ["فرانک سی‌اف‌ای غرب آفریقا", "فرانک غرب آفریقا", "xof"]),
    ("XAF", ["فرانک سی‌اف‌ای مرکز آفریقا", "فرانک مرکز آفریقا", "xaf"]),
    ("XPF", ["فرانک اقیانوسیه", "xpf"]),
    ("CDF", ["فرانک کنگو", "cdf"]),
    ("RWF", ["فرانک رواندا", "rwf"]),
    ("BIF", ["فرانک بوروندی", "bif"]),
    ("DJF", ["فرانک جیبوتی", "djf"]),
    ("GNF", ["فرانک گینه", "gnf"]),
    ("KMF", ["فرانک کومور", "kmf"]),

    ("SEK", ["کرون سوئد", "sek"]),
    ("NOK", ["کرون نروژ", "nok"]),
    ("DKK", ["کرون دانمارک", "dkk"]),
    ("ISK", ["کرون ایسلند", "کرونای ایسلند", "isk"]),
    ("CZK", ["کرون چک", "کرونای چک", "czk"]),

    ("ALL", ["لک آلبانی", "all"]),
    ("BAM", ["مارک بوسنی", "bam"]),
    ("ANG", ["گیلدر آنتیل هلند", "ang"]),
    ("AWG", ["فلورین آروبا", "awg"]),
    ("BOB", ["بولیویانو بولیوی", "bob"]),
    ("BTN", ["نگولتروم بوتان", "btn"]),
    ("BWP", ["پولا بوتسوانا", "bwp"]),
    ("CRC", ["کولون کاستاریکا", "crc"]),
    ("CVE", ["اسکودو کیپ ورد", "cve"]),
    ("ERN", ["ناکفا اریتره", "ern"]),
    ("GMD", ["دالاسی گامبیا", "gmd"]),
    ("GTQ", ["کتزال گواتمالا", "gtq"]),
    ("HNL", ["لمپیرا هندوراس", "hnl"]),
    ("HTG", ["گورد هائیتی", "htg"]),
    ("LSL", ["لوتی لسوتو", "lsl"]),
    ("MDL", ["لئو مولداوی", "mdl"]),
    ("MGA", ["آریاری ماداگاسکار", "mga"]),
    ("MOP", ["پاتاکا ماکائو", "mop"]),
    ("MRU", ["اوگوئیا موریتانی", "mru"]),
    ("MWK", ["کواچا مالاوی", "mwk"]),
    ("MZN", ["متیکال موزامبیک", "mzn"]),
    ("NIO", ["کوردوبا نیکاراگوئه", "nio"]),
    ("PAB", ["بالبوا پاناما", "pab"]),
    ("PEN", ["سول پرو", "pen"]),
    ("PGK", ["کینا پاپوآ گینه نو", "pgk"]),
    ("PYG", ["گوارانی پاراگوئه", "pyg"]),
    ("SLE", ["لئون سیرالئون", "sle"]),
    ("STN", ["دوبرا سائوتومه", "stn"]),
    ("SZL", ["لیلانگنی سوازیلند", "szl"]),
    ("TOP", ["پاآنگا تونگا", "top"]),
    ("VES", ["بولیوار ونزوئلا", "ves"]),
    ("VUV", ["واتو وانواتو", "vuv"]),
    ("WST", ["تالا ساموا", "wst"]),
    ("ZMW", ["کواچا زامبیا", "zmw"]),
    ("ZWG", ["زیمبابوه گلد", "zwg"]),
]

FIAT_ALIASES = {}
for _code, _aliases in _FIAT_ALIAS_GROUPS:
    for _a in _aliases:
        FIAT_ALIASES[_a] = _code


# ════════════════════════════════════════════════════════════════════════
#  رمزارزها / Cryptocurrencies
#  دیکشنری نمایش (id → نام فارسی/انگلیسی/نماد) + دیکشنری مستعار ورودی.
#  برای رمزارزهایی که در این فهرست دستی نیستند (تا سقف ۲۰۰ ارز برتر بازار)،
#  جستجوی زندهٔ نام/نماد/شناسهٔ انگلیسی روی فهرست زنده‌ی CoinGecko انجام
#  می‌شود (تابع _resolve_crypto_id) — یعنی عملاً تمام ۲۰۰ ارز برتر، حتی
#  بدون نام فارسی دستی، با تایپ نام یا نماد انگلیسی‌شان کار می‌کنند.
# ════════════════════════════════════════════════════════════════════════
# هر آیتم: (coingecko_id, نام فارسی, نام انگلیسی, نماد/ایموجی, [مستعارهای ورودی])
_CRYPTO_GROUPS = [
    ("bitcoin", "بیت‌کوین", "Bitcoin", "₿", ["بیتکوین", "بیت کوین", "بیت‌کوین", "btc"]),
    ("ethereum", "اتریوم", "Ethereum", "Ξ", ["اتریوم", "اتر", "eth"]),
    ("tether", "تتر", "Tether", "₮", ["تتر", "تتر usdt", "usdt"]),
    ("binancecoin", "بایننس‌کوین", "BNB", "🟡", ["بایننس کوین", "بایننس‌کوین", "بی ان بی", "bnb"]),
    ("ripple", "ریپل", "XRP", "💧", ["ریپل", "ایکس آر پی", "xrp"]),
    ("solana", "سولانا", "Solana", "◎", ["سولانا", "سولاناً", "sol"]),
    ("cardano", "کاردانو", "Cardano", "🔷", ["کاردانو", "ada"]),
    ("dogecoin", "دوج‌کوین", "Dogecoin", "🐶", ["دوج کوین", "دوج‌کوین", "دوج", "doge"]),
    ("polkadot", "پولکادات", "Polkadot", "⚪", ["پولکادات", "پولکادوت", "dot"]),
    ("chainlink", "چین‌لینک", "Chainlink", "🔗", ["چین لینک", "چین‌لینک", "link"]),
    ("litecoin", "لایت‌کوین", "Litecoin", "Ł", ["لایت کوین", "لایت‌کوین", "ltc"]),
    ("avalanche-2", "اولانچ", "Avalanche", "🔺", ["اولانچ", "آوالانچ", "avax"]),
    ("shiba-inu", "شیبا", "Shiba Inu", "🐕", ["شیبا", "شیبا اینو", "shib"]),
    ("tron", "ترون", "TRON", "🔻", ["ترون", "trx"]),
    ("bitcoin-cash", "بیتکوین‌کش", "Bitcoin Cash", "₿", ["بیتکوین کش", "بیت کوین کش", "bch"]),
    ("near", "نیر", "NEAR", "🌐", ["نیر", "near"]),
    ("uniswap", "یونی‌سواپ", "Uniswap", "🦄", ["یونی سواپ", "یونی‌سواپ", "uni"]),
    ("cosmos", "کازموس", "Cosmos", "⚛️", ["کازموس", "کاسموس", "atom"]),
    ("monero", "مونرو", "Monero", "ɱ", ["مونرو", "xmr"]),
    ("polygon-ecosystem-token", "پالیگان", "Polygon", "🟣", ["پالیگان", "پولیگان", "matic", "pol"]),
    ("stellar", "استلار", "Stellar", "✴️", ["استلار", "xlm"]),
    ("algorand", "الگورند", "Algorand", "🔵", ["الگورند", "آلگورند", "algo"]),
    ("vechain", "وی‌چین", "VeChain", "✔️", ["وی چین", "وی‌چین", "vet"]),
    ("filecoin", "فایل‌کوین", "Filecoin", "📁", ["فایل کوین", "فایل‌کوین", "fil"]),
    ("toncoin", "تون‌کوین", "Toncoin", "💎", ["تون کوین", "تون‌کوین", "تون", "ton"]),
    ("aptos", "اپتوس", "Aptos", "🅰️", ["اپتوس", "آپتوس", "apt"]),
    ("arbitrum", "آربیتروم", "Arbitrum", "🔷", ["آربیتروم", "اربیتروم", "arb"]),
    ("optimism", "اپتیمیزم", "Optimism", "🔴", ["اپتیمیزم", "اوپتیمیزم", "op"]),
    ("maker", "میکر", "Maker", "🏛️", ["میکر", "mkr"]),
    ("internet-computer", "اینترنت‌کامپیوتر", "Internet Computer", "♾️", ["اینترنت کامپیوتر", "icp"]),
    ("hedera-hashgraph", "هدرا", "Hedera", "♓", ["هدرا", "hbar"]),
    ("fantom", "فانتوم", "Fantom", "👻", ["فانتوم", "ftm"]),
    ("the-sandbox", "سندباکس", "The Sandbox", "🏖️", ["سندباکس", "sand"]),
    ("decentraland", "دیسنترالند", "Decentraland", "🏙️", ["دیسنترالند", "mana"]),
    ("axie-infinity", "اکسی‌اینفینیتی", "Axie Infinity", "🎮", ["اکسی اینفینیتی", "axs"]),
    ("theta-token", "تتا", "Theta", "📺", ["تتا", "theta"]),
    ("eos", "ایاواس", "EOS", "🟪", ["ایاواس", "eos"]),
    ("tezos", "تزوس", "Tezos", "🔵", ["تزوس", "xtz"]),
    ("zcash", "زی‌کش", "Zcash", "🛡️", ["زی کش", "زدکش", "zec"]),
    ("dash", "دش", "Dash", "💨", ["دش", "dash"]),
    ("neo", "نئو", "NEO", "⬛", ["نئو", "neo"]),
    ("iota", "آیوتا", "IOTA", "🔱", ["آیوتا", "ایوتا", "miota", "iota"]),
    ("bitcoin-sv", "بیتکوین‌اس‌وی", "Bitcoin SV", "₿", ["بیتکوین اس وی", "bsv"]),
    ("dai", "دای", "Dai", "◈", ["دای", "dai"]),
    ("usd-coin", "یواس‌دی‌کوین", "USD Coin", "🔵", ["یو اس دی کوین", "یواسدی", "usdc"]),
    ("wrapped-bitcoin", "رپدبیتکوین", "Wrapped Bitcoin", "₿", ["رپد بیتکوین", "wbtc"]),
    ("leo-token", "لئوتوکن", "LEO Token", "🦁", ["لئو توکن", "leo"]),
    ("okb", "اوکی‌بی", "OKB", "⭕", ["اوکی بی", "okb"]),
    ("crypto-com-chain", "کرونوس", "Cronos", "🔴", ["کرونوس", "cro"]),
    ("kaspa", "کاسپا", "Kaspa", "🟩", ["کاسپا", "kas"]),
    ("sui", "سویی", "Sui", "💧", ["سویی", "sui"]),
    ("pepe", "پپه", "Pepe", "🐸", ["پپه", "pepe"]),
    ("worldcoin-wld", "ورلدکوین", "Worldcoin", "👁️", ["ورلدکوین", "wld"]),
    ("celestia", "سلستیا", "Celestia", "🌌", ["سلستیا", "tia"]),
    ("injective-protocol", "اینجکتیو", "Injective", "💉", ["اینجکتیو", "inj"]),
    ("render-token", "رندر", "Render", "🎨", ["رندر", "rndr", "render"]),
    ("immutable-x", "ایمیوتیبل‌ایکس", "Immutable", "⬜", ["ایمیوتیبل ایکس", "imx"]),
    ("arweave", "آرویو", "Arweave", "🗄️", ["آرویو", "ar"]),
    ("thorchain", "ثورچین", "THORChain", "⚡", ["ثورچین", "rune"]),
    ("flow", "فلو", "Flow", "🌊", ["فلو", "flow"]),
    ("gala", "گالا", "Gala", "🎮", ["گالا", "gala"]),
    ("quant-network", "کوانت", "Quant", "🧮", ["کوانت", "qnt"]),
]

CRYPTO_DISPLAY = {cid: {"fa": fa, "en": en, "sym": sym} for cid, fa, en, sym, _ in _CRYPTO_GROUPS}

CRYPTO_ALIASES = {}
for _cid, _fa, _en, _sym, _aliases in _CRYPTO_GROUPS:
    for _a in _aliases:
        CRYPTO_ALIASES[_a] = _cid
    # نام فارسی و انگلیسی هم به‌عنوان مستعار اضافه می‌شوند
    CRYPTO_ALIASES.setdefault(_fa, _cid)
    CRYPTO_ALIASES.setdefault(_en.lower(), _cid)


# ════════════════════════════════════════════════════════════════════════
#  پرچم کشورها برای دستور طلا (تزئینی — در صورت نبود، 🌍 نشان داده می‌شود)
# ════════════════════════════════════════════════════════════════════════
COUNTRY_FLAGS = {
    "ایران": "🇮🇷", "آمریکا": "🇺🇸", "امریکا": "🇺🇸", "انگلیس": "🇬🇧", "انگلستان": "🇬🇧",
    "بریتانیا": "🇬🇧", "فرانسه": "🇫🇷", "آلمان": "🇩🇪", "ایتالیا": "🇮🇹", "اسپانیا": "🇪🇸",
    "سوئیس": "🇨🇭", "ترکیه": "🇹🇷", "امارات": "🇦🇪", "عربستان": "🇸🇦", "قطر": "🇶🇦",
    "کویت": "🇰🇼", "عمان": "🇴🇲", "بحرین": "🇧🇭", "عراق": "🇮🇶", "چین": "🇨🇳",
    "هند": "🇮🇳", "روسیه": "🇷🇺", "ژاپن": "🇯🇵", "کانادا": "🇨🇦", "استرالیا": "🇦🇺",
    "هلند": "🇳🇱", "بلژیک": "🇧🇪", "سوئد": "🇸🇪", "نروژ": "🇳🇴", "دانمارک": "🇩🇰",
    "اتریش": "🇦🇹", "یونان": "🇬🇷", "پرتغال": "🇵🇹", "مصر": "🇪🇬", "پاکستان": "🇵🇰",
    "افغانستان": "🇦🇫", "آذربایجان": "🇦🇿", "ارمنستان": "🇦🇲", "گرجستان": "🇬🇪",
    "کره جنوبی": "🇰🇷", "کره شمالی": "🇰🇵", "ویتنام": "🇻🇳", "تایلند": "🇹🇭",
    "مالزی": "🇲🇾", "اندونزی": "🇮🇩", "فیلیپین": "🇵🇭", "سنگاپور": "🇸🇬", "برزیل": "🇧🇷",
    "آرژانتین": "🇦🇷", "مکزیک": "🇲🇽", "شیلی": "🇨🇱", "کلمبیا": "🇨🇴", "پرو": "🇵🇪",
    "ونزوئلا": "🇻🇪", "آفریقای جنوبی": "🇿🇦", "نیجریه": "🇳🇬", "کنیا": "🇰🇪",
    "مراکش": "🇲🇦", "الجزایر": "🇩🇿", "تونس": "🇹🇳", "لیبی": "🇱🇾", "سودان": "🇸🇩",
    "نیوزیلند": "🇳🇿", "لبنان": "🇱🇧", "سوریه": "🇸🇾", "اردن": "🇯🇴", "یمن": "🇾🇪",
}

# ════════════════════════════════════════════════════════════════════════
#  کلیدواژه‌های گرامری دستورات / Command Grammar Keywords
# ════════════════════════════════════════════════════════════════════════
BE_WORDS     = {"به", "to", "be"}
GOLD_WORDS   = {"طلا", "gold"}
IRAN_WORDS   = {"ایران", "iran", "irn"}
HELP_WORDS   = {"بازار", "market", "help_market"}
DEBUG_WORDS  = {"دیباگ", "debug"}
FILLER_WORDS = {"آزاد", "بازار", "نقدی", "امروز", "الان", "فعلی", "لحظه‌ای", "جاری", "روز"}

# عبارات راه‌انداز فهرست‌ها → نوع فهرست ("crypto" یا "fiat")
LIST_TRIGGERS = {
    "ارزها": "crypto", "ارز ها": "crypto", "ارزدیجیتال": "crypto",
    "ارز دیجیتال": "crypto", "ارزهای دیجیتال": "crypto", "ارزهای_دیجیتال": "crypto",
    "رمزارزها": "crypto", "رمزارز ها": "crypto", "رمز ارزها": "crypto",
    "رمز ارز ها": "crypto", "کریپتو": "crypto",
    "crypto": "crypto", "cryptos": "crypto", "coins": "crypto", "coin": "crypto",

    "پول": "fiat", "پول ها": "fiat", "پولها": "fiat",
    "money": "fiat", "currencies": "fiat", "currency": "fiat",
}

# ════════════════════════════════════════════════════════════════════════
#  ابزارهای متن / Text Helpers
# ════════════════════════════════════════════════════════════════════════

_ARABIC_FIX = {
    "ك": "ک", "ي": "ی", "ة": "ه", "ۀ": "ه", "إ": "ا", "أ": "ا", "ؤ": "و", "ٱ": "ا",
    "\u200c": " ", "\u200f": "", "\u200e": "",
}
_DIGIT_FIX = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
    "01234567890123456789",
)


def _normalize_text(s: str) -> str:
    """یکسان‌سازی کاراکترهای عربی/فارسی، حذف نیم‌فاصله، یکی‌کردن جداکننده‌ها."""
    s = s.strip()
    for a, b in _ARABIC_FIX.items():
        s = s.replace(a, b)
    s = s.translate(_DIGIT_FIX)
    s = s.replace("_", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s.lower()


def _resolve_alias(tokens: list, alias_dict: dict):
    """طولانی‌ترین تطبیق از ابتدای tokens در alias_dict را برمی‌گرداند.
    خروجی: (مقدار یا None, تعداد توکن‌های مصرف‌شده)"""
    n = len(tokens)
    for length in range(n, 0, -1):
        phrase = " ".join(tokens[:length])
        if phrase in alias_dict:
            return alias_dict[phrase], length
    return None, 0


def _split_at_be(tokens: list):
    """تقسیم توکن‌ها بر اساس اولین واژهٔ «به». اگر یافت نشود، after=None."""
    for i, t in enumerate(tokens):
        if t in BE_WORDS:
            return tokens[:i], tokens[i + 1:]
    return tokens, None


def _strip_fillers(tokens: list) -> list:
    cleaned = [t for t in tokens if t not in FILLER_WORDS]
    return cleaned if cleaned else tokens


def _fa_num(s: str) -> str:
    """تبدیل ارقام لاتین به فارسی"""
    return s.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _fmt_smart(value: float) -> str:
    """فرمت هوشمند عدد بر اساس بزرگی مقدار، با ارقام فارسی"""
    av = abs(value)
    if av == 0:
        s = "0"
    elif av >= 1000:
        s = f"{value:,.0f}"
    elif av >= 1:
        s = f"{value:,.2f}"
    elif av >= 0.001:
        s = f"{value:,.4f}"
    else:
        s = f"{value:,.8f}"
    return _fa_num(s)


def _currency_display(code: str):
    """برمی‌گرداند (نام_فارسی, پرچم) برای یک کد ارز؛ در صورت نبود، خود کد را برمی‌گرداند."""
    info = CURRENCY_INFO.get(code)
    if info:
        return info
    return (code, "🌍")

# ════════════════════════════════════════════════════════════════════════
#  درخواست HTTP با کش و تلاش مجدد / HTTP with Cache & Retry
# ════════════════════════════════════════════════════════════════════════

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
}
_session: aiohttp.ClientSession | None = None


async def _get_session() -> aiohttp.ClientSession:
    """✅ عملکرد: قبلاً هر کش‌میسی یه aiohttp.ClientSession تازه می‌ساخت -
    یعنی هندشیکِ TCP/TLS تکراری برای هر قیمتِ ارز/سکه‌ای که کش نشده بود.
    هدرها همیشه ثابت بودن، پس یه session مشترک که یه‌بار ساخته می‌شه و
    reuse می‌شه، دقیقاً همون رفتار رو با اتصال‌های کمتر می‌ده."""
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession(headers=_HEADERS)
    return _session


async def _get_text(url: str) -> str:
    now = time.time()
    key = ("text", url)
    hit = _cache.get(key)
    if hit and (now - hit[0]) < CACHE_TTL:
        return hit[1]

    session = await _get_session()
    async with session.get(
        url,
        timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
        proxy=PROXY_URL,
    ) as r:
        txt = await r.text()

    _cache[key] = (now, txt)
    return txt


async def _get_text_retry(url: str, retries: int = 2, backoff: float = 0.6) -> str:
    last_exc = None
    for attempt in range(retries + 1):
        try:
            return await _get_text(url)
        except Exception as e:
            last_exc = e
            if attempt < retries:
                await asyncio.sleep(backoff * (attempt + 1))
    raise last_exc


async def _get_json_retry(url: str, retries: int = 2):
    txt = await _get_text_retry(url, retries)
    return json.loads(txt)


# ════════════════════════════════════════════════════════════════════════
#  منابع داده / Data Fetchers
# ════════════════════════════════════════════════════════════════════════

def _extract_tgju_number(html: str):
    """قیمت لحظه‌ای را از HTML صفحهٔ TGJU استخراج می‌کند.

    این تابع قبلاً دنبال برچسب متنی «Last:» می‌گشت، اما با دیباگ مستقیم روی
    صفحهٔ زندهٔ دلار و طلا مشخص شد که این برچسب اصلاً در صفحهٔ فعلی وجود
    ندارد (صفر نتیجه). در عوض، با بررسی واقعی اولین اعداد موجود در صفحه:
    اولین عدد صحیح با جداکنندهٔ هزارگان (بدون اعشار) دقیقاً همان قیمت لحظه‌ای
    صحیح است (برای دلار: 1,596,000 ✓، برای طلای ۱۸: 161,602,000 ✓ — هر دو با
    دیباگ واقعی تأیید شدند). اعداد بعدی در صفحه معمولاً دادهٔ نمودار/چارت با
    اعشار هستند و بی‌ربط به قیمت."""
    pattern = re.compile(r"\d{1,3}(?:,\d{3})+(?!\.\d)")
    m = pattern.search(html)
    if not m:
        return None
    try:
        val = float(m.group().replace(",", ""))
    except ValueError:
        return None
    return val if val >= 1000 else None


async def _tgju_rial(url: str) -> float:
    html = await _get_text_retry(url)
    val = _extract_tgju_number(html)
    if val is None:
        raise RuntimeError("استخراج قیمت از TGJU ناموفق بود")
    return val  # ریال


async def _nobitex_usdt_toman() -> float:
    """قیمت تتر در نوبیتکس به‌عنوان تخمین نرخ دلار/تومان (فالبک)"""
    data = await _get_json_retry(NOBITEX_GLOBAL)
    stats = data.get("stats", {})
    pair = stats.get("usdt-rls") or stats.get("usdt-irr")
    if not pair:
        raise RuntimeError("نرخ usdt-rls در نوبیتکس یافت نشد")
    return float(str(pair["latest"]).replace(",", "")) / 10.0


async def _get_usd_toman() -> float:
    """نرخ دلار به تومان — اول TGJU (بازار آزاد نقدی)، و فقط اگر TGJU کاملاً
    در دسترس نبود از نوبیتکس (نرخ تتر) به‌عنوان فالبک استفاده می‌شود.

    توجه مهم: نرخ تتر/تومان نوبیتکس همیشه معادل دلار نقدی بازار آزاد نیست —
    به‌خصوص وقتی صرافی‌ها به دستور بانک مرکزی جفت تتر/تومان را محدود یا
    متوقف می‌کنند، تتر می‌تواند فاصلهٔ زیادی (حتی ۲۰-۳۰٪) با دلار نقدی
    داشته باشد. به همین دلیل از نوبیتکس به‌عنوان «داور» برای رد کردن مقدار
    صحیح TGJU استفاده نمی‌شود؛ فقط وقتی TGJU خودش کار نکند جایش را می‌گیرد."""
    now = time.time()
    hit = _cache.get(("usd_toman",))
    if hit and (now - hit[0]) < CACHE_TTL:
        return hit[1]

    val = None
    tgju_err = None
    try:
        rial = await _tgju_rial(TGJU_USD)
        toman = rial / 10.0
        if toman > 1000:
            val = toman
    except Exception as e:
        tgju_err = e

    if val is None:
        try:
            val = await _nobitex_usdt_toman()
        except Exception as nb_err:
            prev = _cache.get(("usd_toman",))
            if prev:
                return prev[1]
            raise RuntimeError(
                f"هم TGJU و هم نوبیتکس شکست خوردند — TGJU: {tgju_err} | نوبیتکس: {nb_err}"
            )

    _cache[("usd_toman",)] = (now, val)
    return val


async def _get_exchange_rates() -> dict:
    """نرخ تمام ارزهای فیات نسبت به دلار (۱ دلار = rates[code] واحد).
    مقدار IRT/IRR همیشه از TGJU (نرخ واقعی بازار ایران) گرفته می‌شود،
    نه از APIهای عمومی که معمولاً نرخ رسمی/نیما را برمی‌گردانند.

    برای سرعت بیشتر، دو منبع (نرخ‌های جهانی و دلار/تومان) هم‌زمان و موازی
    واکشی می‌شوند، نه پشت‌سرهم — چون به هم بستگی ندارند."""
    now = time.time()
    hit = _cache.get(("rates",))
    if hit and (now - hit[0]) < RATES_CACHE_TTL:
        return hit[1]

    data_result, usd_toman_result = await asyncio.gather(
        _get_json_retry(EXCHANGERATE_API),
        _get_usd_toman(),
        return_exceptions=True,
    )

    if isinstance(data_result, Exception):
        prev = _cache.get(("rates",))
        rates = dict(prev[1]) if prev else {}
    else:
        rates = dict(data_result.get("rates", {}))

    rates["USD"] = 1.0

    if isinstance(usd_toman_result, Exception):
        if "IRR" in rates and "IRT" not in rates:
            rates["IRT"] = rates["IRR"] / 10.0
    else:
        rates["IRT"] = usd_toman_result
        rates["IRR"] = usd_toman_result * 10.0

    _cache[("rates",)] = (now, rates)
    return rates


async def _get_iran_gold18_toman_per_gram() -> float:
    """طلای ۱۸ عیار ایران (تومان به ازای هر گرم) — از TGJU"""
    rial = await _tgju_rial(TGJU_GOLD18)
    return rial / 10.0


async def _get_gold_usd_per_gram() -> float:
    """قیمت جهانی طلای ۲۴ عیار (خالص) به دلار در هر گرم"""
    now = time.time()
    hit = _cache.get(("gold_usd_gram",))
    if hit and (now - hit[0]) < GOLD_CACHE_TTL:
        return hit[1]

    val = None
    primary_err = None
    try:
        data = await _get_json_retry(GOLD_API_PRIMARY)
        oz = float(data.get("price") or 0)
        if oz > 100:
            val = oz / GRAMS_PER_OUNCE
    except Exception as e:
        primary_err = e

    if val is None:
        try:
            gold18_toman = await _get_iran_gold18_toman_per_gram()
            usd_toman = await _get_usd_toman()
            val = (gold18_toman * (24.0 / 18.0)) / usd_toman
        except Exception as fallback_err:
            prev = _cache.get(("gold_usd_gram",))
            if prev:
                return prev[1]
            raise RuntimeError(
                f"هم API جهانی طلا و هم TGJU شکست خوردند — جهانی: {primary_err} | TGJU: {fallback_err}"
            )

    _cache[("gold_usd_gram",)] = (now, val)
    return val


async def _get_crypto_market(limit: int = 200) -> list:
    """فهرست بازار رمزارزها (id، رتبه، نام، نماد، قیمت دلاری) از CoinGecko"""
    now = time.time()
    key = ("crypto_market", limit)
    hit = _cache.get(key)
    if hit and (now - hit[0]) < CRYPTO_CACHE_TTL:
        return hit[1]

    url = COINGECKO_MARKETS_TMPL.format(n=min(max(limit, 1), 250))
    data = await _get_json_retry(url)
    if not isinstance(data, list):
        raise RuntimeError("پاسخ نامعتبر از CoinGecko")

    _cache[key] = (now, data)
    return data

# ════════════════════════════════════════════════════════════════════════
#  موتور تبدیل (محور دلار) / Conversion Engine (USD Pivot)
# ════════════════════════════════════════════════════════════════════════

async def _fiat_unit_to_usd(code: str) -> float:
    """ارزش یک واحد از ارز `code` بر حسب دلار"""
    rates = await _get_exchange_rates()
    if code not in rates or rates[code] <= 0:
        raise ValueError(f"نرخ ارز «{code}» در دسترس نیست")
    return 1.0 / rates[code]


async def _usd_to_target(usd_value: float, target_code: str) -> float:
    """تبدیل یک مقدار دلاری به ارز هدف"""
    rates = await _get_exchange_rates()
    if target_code not in rates:
        raise ValueError(f"نرخ ارز «{target_code}» در دسترس نیست")
    return usd_value * rates[target_code]


async def _gold_for_country(country_label) -> dict:
    """قیمت طلا برای یک کشور؛ برای ایران از نرخ واقعی بازار داخلی (۱۸ عیار،
    TGJU) و برای سایر کشورها از نرخ جهانی (۲۴ عیار) استفاده می‌شود، چون
    بازار داخلی طلا برای اکثر کشورها به‌صورت جدا رهگیری نمی‌شود."""
    world_usd = await _get_gold_usd_per_gram()
    label_raw = (country_label or "").strip()
    is_iran = (not label_raw) or (label_raw in IRAN_WORDS)

    if is_iran:
        usd_toman = await _get_usd_toman()
        world_18k_usd = world_usd * (18.0 / 24.0)

        usd_per_gram = None
        try:
            iran_toman18 = await _get_iran_gold18_toman_per_gram()
            candidate = iran_toman18 / usd_toman
            # اعتبارسنجی: قیمت داخلی طلای ۱۸ عیار باید در بازهٔ منطقی نسبت
            # به معادل جهانی‌اش باشد (با اجازهٔ حباب/تفاوت بازار داخلی تا
            # ۲ برابر). اگر خارج از این بازه بود، یعنی اسکرپ TGJU به احتمال
            # زیاد عدد غلطی برداشته (مثلاً به‌خاطر تغییر قالب صفحه).
            if 0.5 <= (candidate / world_18k_usd) <= 2.2:
                usd_per_gram = candidate
        except Exception:
            usd_per_gram = None

        is_estimated = usd_per_gram is None
        if is_estimated:
            usd_per_gram = world_18k_usd

        return {
            "label": "ایران",
            "flag": "🇮🇷",
            "is_iran": True,
            "usd_per_gram": usd_per_gram,
            "karat_note": (
                "۱۸ عیار، بازار داخلی" if not is_estimated
                else "۱۸ عیار، برآورد بر مبنای نرخ جهانی (دریافت نرخ داخلی از TGJU ناموفق بود)"
            ),
            "world_usd_per_gram": world_usd,
            "is_estimated": is_estimated,
        }

    label = country_label.strip()
    flag = COUNTRY_FLAGS.get(label, "🌍")
    return {
        "label": label,
        "flag": flag,
        "is_iran": False,
        "usd_per_gram": world_usd,
        "karat_note": "۲۴ عیار، بر مبنای نرخ جهانی",
        "world_usd_per_gram": world_usd,
        "is_estimated": False,
    }


async def _resolve_crypto_id(tokens: list):
    """تشخیص شناسهٔ CoinGecko یک رمزارز از روی توکن‌های ورودی. اول دیکشنری
    دستی CRYPTO_ALIASES، سپس جستجوی زنده روی فهرست ۲۰۰ ارز برتر بازار
    (تطبیق با id/نماد/نام انگلیسی) برای پوشش کامل رمزارزهای بدون نام فارسی."""
    if not tokens:
        return None

    code, used = _resolve_alias(tokens, CRYPTO_ALIASES)
    if code and used == len(tokens):
        return code

    try:
        market = await _get_crypto_market(limit=200)
    except Exception:
        return None

    phrase = " ".join(tokens)
    phrase_dash = phrase.replace(" ", "-")
    for c in market:
        cid = (c.get("id") or "").lower()
        sym = (c.get("symbol") or "").lower()
        name = (c.get("name") or "").lower()
        name_dash = name.replace(" ", "-")
        if phrase in (cid, sym, name) or phrase_dash in (cid, name_dash):
            return c.get("id")

    if len(tokens) == 1:
        t = tokens[0]
        for c in market:
            if t == (c.get("symbol") or "").lower():
                return c.get("id")

    return None

# ════════════════════════════════════════════════════════════════════════
#  ارسال پیام‌های طولانی (تلگرام هر پیام را تا ۴۰۹۶ کاراکتر می‌پذیرد)
# ════════════════════════════════════════════════════════════════════════

async def _send_chunked(event, header: str, items: list, footer: str = "",
                         max_chars: int = 3500, max_items: int = 100):
    """ارسال یک فهرست طولانی در چند پیام متنی.

    دو سقف هم‌زمان اعمال می‌شود: حداکثر `max_items` آیتم در هر پیام، و
    حداکثر `max_chars` کاراکتر در هر پیام — هرکدام زودتر برسد همان مرزِ
    همان پیام است. یک آیتم هیچ‌وقت نیمه‌کاره وسط پیام قطع نمی‌شود (که باعث
    خطای محدودیت تلگرام شود)؛ یا کامل در همان پیام جا می‌گیرد یا کامل به
    پیام بعدی منتقل می‌شود."""
    if not items:
        msg = (header + "\n" if header else "") + "هیچ داده‌ای یافت نشد."
        if footer:
            msg += "\n" + footer
        await event.reply(msg)
        return

    chunks = []
    current = []
    current_len = 0
    for item in items:
        item_len = len(item) + 1
        hits_char_limit = current and (current_len + item_len > max_chars)
        hits_item_limit = len(current) >= max_items
        if current and (hits_char_limit or hits_item_limit):
            chunks.append("\n".join(current))
            current = [item]
            current_len = item_len
        else:
            current.append(item)
            current_len += item_len
    if current:
        chunks.append("\n".join(current))

    if header:
        chunks[0] = header + "\n" + chunks[0]
    if footer:
        chunks[-1] = chunks[-1] + "\n" + footer

    for i, ch in enumerate(chunks):
        # اضافه کردن فرمت کد بلاک و امضا به هر بخش از لیست
        formatted_chunk = f"```{ch}```\n\n**__AXoRA SelF__**"
        await event.reply(formatted_chunk)
        if i < len(chunks) - 1:
            await asyncio.sleep(0.3)


async def _reply_long_text(event, text: str, max_chars: int = 3500):
    if len(text) <= max_chars:
        await event.reply(text)
        return
    parts = text.split("\n\n")
    chunks = []
    current = ""
    for p in parts:
        candidate = (current + "\n\n" + p) if current else p
        if len(candidate) > max_chars and current:
            chunks.append(current)
            current = p
        else:
            current = candidate
    if current:
        chunks.append(current)
    for i, ch in enumerate(chunks):
        await event.reply(ch)
        if i < len(chunks) - 1:
            await asyncio.sleep(0.4)


def _resolve_target_code(target_tokens):
    """توکن‌های بعد از «به» را به کد ارز هدف تبدیل می‌کند.
    اگر چیزی داده نشده باشد، تومان پیش‌فرض است.
    خروجی: (code, error_message_or_None)"""
    if not target_tokens:
        return "IRT", None
    cleaned = _strip_fillers(target_tokens)
    code, used = _resolve_alias(cleaned, FIAT_ALIASES)
    if not code or used != len(cleaned):
        return None, f"❌ واحد پول «{' '.join(target_tokens)}» شناسایی نشد."
    return code, None

# ════════════════════════════════════════════════════════════════════════
#  هندلرها / Command Handlers
# ════════════════════════════════════════════════════════════════════════

def _all_number_candidates(html: str, limit: int = 12):
    """همهٔ اعدادِ سه‌رقمی‌جداشده با کاما را به ترتیب ظهور در صفحه برمی‌گرداند
    (برای دیباگ — تا ببینیم واقعاً چه عددهایی روی صفحه هست)."""
    pattern = re.compile(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?")
    seen = []
    for m in pattern.finditer(html):
        val = m.group()
        if val not in seen:
            seen.append(val)
        if len(seen) >= limit:
            break
    return seen


async def handle_debug(event):
    """/دیباگ — نمایش مقادیر خام هر منبع به‌صورت جدا، برای پیداکردن دقیق
    اینکه قیمت غلط از کجا می‌آید (اسکرپ TGJU، نوبیتکس، یا منطق تبدیل)."""
    lines = ["🔧 دیباگ منابع قیمت", ""]

    # --- دلار ---
    lines.append("— دلار —")
    try:
        rial = await _tgju_rial(TGJU_USD)
        lines.append(f"TGJU خام (ریال): {rial:,.0f}")
        lines.append(f"TGJU → تومان (÷۱۰): {rial / 10.0:,.0f}")
    except Exception as e:
        lines.append(f"TGJU: خطا → {e}")

    try:
        nb = await _nobitex_usdt_toman()
        lines.append(f"نوبیتکس تتر/تومان: {nb:,.0f}")
    except Exception as e:
        lines.append(f"نوبیتکس: خطا → {e}")

    try:
        final_usd_toman = await _get_usd_toman()
        lines.append(f"✅ نرخ نهایی انتخاب‌شده: {final_usd_toman:,.0f} تومان")
    except Exception as e:
        lines.append(f"نرخ نهایی: خطا → {e}")

    try:
        raw_html = await _get_text_retry(TGJU_USD)
        lines.append(f"طول HTML صفحه دلار: {len(raw_html)} کاراکتر")
        nums = _all_number_candidates(raw_html, 12)
        lines.append("اولین اعداد چندرقمی روی صفحه دلار: " + (", ".join(nums) if nums else "هیچ‌کدام پیدا نشد"))
    except Exception as e:
        lines.append(f"دریافت HTML خام صفحهٔ دلار: خطا → {e}")

    lines.append("")
    lines.append("— طلای ۱۸ عیار ایران —")
    try:
        gold_rial = await _tgju_rial(TGJU_GOLD18)
        lines.append(f"TGJU خام (ریال): {gold_rial:,.0f}")
        lines.append(f"TGJU → تومان/گرم (÷۱۰): {gold_rial / 10.0:,.0f}")
    except Exception as e:
        lines.append(f"TGJU: خطا → {e}")

    try:
        raw_html_gold = await _get_text_retry(TGJU_GOLD18)
        lines.append(f"طول HTML صفحه طلا: {len(raw_html_gold)} کاراکتر")
        nums_gold = _all_number_candidates(raw_html_gold, 12)
        lines.append("اولین اعداد چندرقمی روی صفحه طلا: " + (", ".join(nums_gold) if nums_gold else "هیچ‌کدام پیدا نشد"))
    except Exception as e:
        lines.append(f"دریافت HTML خام صفحهٔ طلا: خطا → {e}")

    try:
        world_gram = await _get_gold_usd_per_gram()
        lines.append(f"طلای جهانی ۲۴ عیار (دلار/گرم): {world_gram:,.4f}")
        lines.append(f"معادل جهانی ۱۸ عیار (دلار/گرم): {world_gram * 18 / 24:,.4f}")
    except Exception as e:
        lines.append(f"طلای جهانی: خطا → {e}")

    try:
        info = await _gold_for_country(None)
        lines.append(f"✅ نتیجهٔ نهایی (دلار/گرم): {info['usd_per_gram']:,.4f}")
        lines.append(f"برآوردی بود (یعنی اسکرپ TGJU رد شد)؟ {info.get('is_estimated')}")
    except Exception as e:
        lines.append(f"نتیجهٔ نهایی طلا: خطا → {e}")

    await event.reply("\n".join(lines))

async def handle_gold(event, country_tokens, target_tokens):
    """/طلا [کشور] به <ارز>"""
    try:
        target_code, err = _resolve_target_code(target_tokens)
        if err:
            await event.reply(err)
            return

        country_label = " ".join(country_tokens) if country_tokens else None
        info = await _gold_for_country(country_label)
        to_name, to_flag = _currency_display(target_code)

        country_value = await _usd_to_target(info["usd_per_gram"], target_code)
        world_value = await _usd_to_target(info["world_usd_per_gram"], target_code)

        lines = [f"🥇 طلای {info['label']} {info['flag']} — {info['karat_note']}"]
        lines.append(f"💰 {_fmt_smart(country_value)} {to_name} {to_flag} به ازای هر گرم")
        lines.append("")
        lines.append(f"🌍 قیمت طلای جهانی (۲۴ عیار): {_fmt_smart(world_value)} {to_name} {to_flag} به ازای هر گرم")
        if not info["is_iran"]:
            lines.append(
                "ℹ️ بازار طلای داخلی این کشور به‌طور جداگانه رهگیری نمی‌شود؛ "
                "بنابراین نرخ بر مبنای قیمت جهانی محاسبه شده (فقط ایران نرخ بازار داخلی متفاوت دارد)."
            )
        if info.get("is_estimated"):
            lines.append(
                "⚠️ دریافت نرخ لحظه‌ای طلای داخلی ایران از منبع موفق نبود؛ "
                "عدد بالا صرفاً یک برآورد بر مبنای نرخ جهانی است، نه نرخ واقعی بازار تهران."
            )
        lines.append(f"🕒 {_now_str()}")
        await event.reply(f"```" + "\n".join(lines) + f"```\n\n**__AXoRA SelF__**")
    except Exception as e:
        await event.reply(f"❌ خطا در محاسبهٔ طلا: {e}")

async def handle_fiat_single(event, code: str, target_tokens):
    """/<ارز> [به <ارز دیگر>] — پیش‌فرض تومان"""
    try:
        target_code, err = _resolve_target_code(target_tokens)
        if err:
            await event.reply(err)
            return

        from_name, from_flag = _currency_display(code)
        to_name, to_flag = _currency_display(target_code)

        if code == target_code:
            await event.reply(f"🔄 {from_name} {from_flag} با خودش برابر است (نرخ = ۱)")
            return

        usd_val = await _fiat_unit_to_usd(code)
        value = await _usd_to_target(usd_val, target_code)

        await event.reply(
            f"```💱 ۱ {from_name} {from_flag} = {_fmt_smart(value)} {to_name} {to_flag}\n"
            f"🕒 {_now_str()}```\n\n**__AXoRA SelF__**"
        )
    except Exception as e:
        await event.reply(f"❌ خطا: {e}")

async def handle_crypto_single(event, crypto_id: str, target_tokens):
    """/<رمزارز> [به <ارز>] — بدون «به»، دلار و تومان هر دو نشان داده می‌شود"""
    try:
        market = await _get_crypto_market(limit=200)
        coin = next((c for c in market if c.get("id") == crypto_id), None)
        if not coin:
            await event.reply("❌ این رمزارز در فهرست ۲۰۰ ارز برتر بازار یافت نشد.")
            return

        usd_price = float(coin.get("current_price") or 0)
        rank = coin.get("market_cap_rank")
        sym = (coin.get("symbol") or "").upper()
        name_en = coin.get("name", crypto_id)
        fa_info = CRYPTO_DISPLAY.get(crypto_id, {})
        name_fa = fa_info.get("fa", name_en)
        emoji = fa_info.get("sym", "🪙")
        rank_line = f"📊 رتبه بازار: #{rank}\n" if rank else ""

        if target_tokens:
            target_code, err = _resolve_target_code(target_tokens)
            if err:
                await event.reply(err)
                return
            to_name, to_flag = _currency_display(target_code)
            value = await _usd_to_target(usd_price, target_code)
            await event.reply(
                f"```{emoji} {name_fa} ({name_en} / {sym})\n"
                f"{rank_line}"
                f"💰 ۱ {name_fa} = {_fmt_smart(value)} {to_name} {to_flag}\n"
                f"🕒 {_now_str()}```\n\n**__AXoRA SelF__**"
            )
        else:
            usd_toman = await _get_usd_toman()
            toman_val = usd_price * usd_toman
            await event.reply(
                f"```{emoji} {name_fa} ({name_en} / {sym})\n"
                f"{rank_line}"
                f"💲 {_fmt_smart(usd_price)} دلار\n"
                f"💰 {_fmt_smart(toman_val)} تومان\n"
                f"🕒 {_now_str()}```\n\n**__AXoRA SelF__**"
            )
    except Exception as e:
        await event.reply(f"```❌ متن خطا```\n\n**__AXoRA SelF__**")

async def handle_crypto_list(event, target_tokens):
    """/ارز ها [به <ارز>] — ۲۰۰ رمزارز برتر جهان بر اساس ارزش بازار"""
    try:
        target_code, err = _resolve_target_code(target_tokens)
        if err:
            await event.reply(err)
            return
        to_name, to_flag = _currency_display(target_code)

        # دریافت لیست بازار و نرخ ارزها هم‌زمان (نه پشت‌سرهم) برای سرعت بیشتر
        market, rates = await asyncio.gather(
            _get_crypto_market(limit=200),
            _get_exchange_rates(),
        )
        rate = rates.get(target_code)
        if rate is None:
            await event.reply(f"❌ نرخ ارز «{target_code}» در دسترس نیست")
            return

        lines = []
        for c in market[:200]:
            rank = c.get("market_cap_rank", "؟")
            sym = (c.get("symbol") or "").upper()
            name_en = c.get("name", "")
            cid = c.get("id", "")
            fa = CRYPTO_DISPLAY.get(cid, {}).get("fa", name_en)
            usd_p = float(c.get("current_price") or 0)
            val = usd_p * rate  # تبدیل مستقیم و همگام، بدون await تکراری برای هر سکه
            lines.append(f"#{rank} {sym} {fa} — {_fmt_smart(val)} {to_name}")

        header = f"🏆 ۲۰۰ رمزارز برتر جهان (بر اساس ارزش بازار) — بر حسب {to_name} {to_flag}"
        footer = f"🕒 {_now_str()}"
        await _send_chunked(event, header, lines, footer, max_items=100)
    except Exception as e:
        await event.reply(f"❌ خطا در دریافت فهرست رمزارزها: {e}")


async def handle_fiat_list(event, target_tokens):
    """/پول [به <ارز>] — تمام پول‌های جهان، از باارزش‌ترین تا بی‌ارزش‌ترین"""
    try:
        target_code, err = _resolve_target_code(target_tokens)
        if err:
            await event.reply(err)
            return
        to_name, to_flag = _currency_display(target_code)

        rates = await _get_exchange_rates()
        rate = rates.get(target_code)
        if rate is None:
            await event.reply(f"❌ نرخ ارز «{target_code}» در دسترس نیست")
            return

        ranked = []
        for code, r in rates.items():
            if code == "IRR":
                continue  # تومان (IRT) همین ارز است؛ از تکرار جلوگیری می‌شود
            if not r or r <= 0:
                continue
            ranked.append((code, 1.0 / r))
        ranked.sort(key=lambda x: x[1], reverse=True)

        lines = []
        for i, (code, usd_per_unit) in enumerate(ranked, start=1):
            name, flag = _currency_display(code)
            val = usd_per_unit * rate  # تبدیل مستقیم و همگام، بدون await تکراری برای هر ارز
            lines.append(f"#{i} {flag} {name} ({code}) — {_fmt_smart(val)} {to_name}")

        header = f"💎 ارزش‌گذاری پول کشورها — از باارزش‌ترین تا بی‌ارزش‌ترین (بر حسب {to_name} {to_flag})"
        footer = f"🕒 {_now_str()}"
        await _send_chunked(event, header, lines, footer, max_items=100)
    except Exception as e:
        await event.reply(f"❌ خطا در دریافت فهرست پول‌ها: {e}")

# ════════════════════════════════════════════════════════════════════════
#  راهنمای کاربر / User-Facing Help Text
# ════════════════════════════════════════════════════════════════════════
HELP_TEXT = """```📊 راهنمای ماژول بازار

همهٔ دستورات با ساختار «دارایی به واحد» نوشته می‌شوند (با فاصلهٔ معمولی).

💱 ارز فیات (هر ارزی به هر ارزی، تمام پول‌های جهان)
/<ارز> به <ارز دیگر>
مثال: /دلار به تومن  |  /یورو به پوند  |  /دلار به دینار
بدون «به»، پیش‌فرض تومان است → /دلار

🥇 طلا (هر کشوری، به هر ارزی)
/طلا [کشور] به <ارز>
مثال: /طلا ایران به تومن  |  /طلا ایران به دلار  |  /طلا فرانسه به پوند
برای ایران از نرخ واقعی بازار داخلی (طلای ۱۸ عیار) استفاده می‌شود.
برای سایر کشورها (که بازار داخلی جدا ندارند) نرخ جهانی ۲۴ عیار محاسبه می‌شود.
در هر دو حالت، نرخ جهانیِ هم‌ارز هم زیرش نوشته می‌شود.

🪙 رمزارز (هر رمزارزی، به هر ارزی)
/<رمزارز> به <ارز>
مثال: /بیتکوین به دلار  |  /تتر به تومن  |  /اتریوم به لیر
بدون «به»، هم دلار و هم تومان نشان داده می‌شود → /بیتکوین

📈 فهرست‌های کامل
/ارز ها [به <ارز>] → ۲۰۰ رمزارز برتر جهان بر اساس ارزش بازار
/پول [به <ارز>] → فهرست تمام پول‌های جهان، از باارزش‌ترین تا کم‌ارزش‌ترین

ℹ️ نکته: واحدها را می‌توانید با کلمهٔ فارسیِ روزمره (دلار، یورو، درهم،
دینار کویت، دینار عراق، روپیه هند، ین، یوآن، کرون سوئد، …) یا با کد
سه‌حرفی بین‌المللی (USD, EUR, GBP, …) بنویسید.

این راهنما با دستور /بازار یا /market نمایش داده می‌شود.```

**__AXoRA SelF__**"""

# ════════════════════════════════════════════════════════════════════════
#  پخش‌کننده اصلی دستورات / Main Dispatcher
#  هیچ خطایی در این تابع نباید باعث پاسخ‌دادن به دستورات نامربوط شود؛ به
#  همین دلیل تشخیص نوع دستور کاملاً ساده و بدون شبکه است و فقط هندلرهای
#  داخلی (که خودشان try/except دارند) واقعاً پاسخ می‌دهند.
# ════════════════════════════════════════════════════════════════════════

async def _dispatch(event):
    try:
        raw_cmd = event.pattern_match.group(1)
        norm = _normalize_text(raw_cmd)
        if not norm:
            return
        tokens = norm.split(" ")
        first = tokens[0]

        # راهنما
        if first in HELP_WORDS:
            await _reply_long_text(event, HELP_TEXT)
            return

        # دیباگ منابع داده
        if first in DEBUG_WORDS:
            await handle_debug(event)
            return

        # طلا
        if first in GOLD_WORDS:
            rest = tokens[1:]
            before, after = _split_at_be(rest)
            await handle_gold(event, before, after)
            return

        # فهرست‌ها (رمزارز یا پول)
        kind, used = _resolve_alias(tokens, LIST_TRIGGERS)
        if kind:
            rest = tokens[used:]
            before, after = _split_at_be(rest)
            if kind == "crypto":
                await handle_crypto_list(event, after)
            else:
                await handle_fiat_list(event, after)
            return

        # حالت کلی: یک دارایی (ارز فیات یا رمزارز) به ارز دیگر
        before, after = _split_at_be(tokens)
        before_clean = _strip_fillers(before)

        # سازگاری با گرامر قدیمی بدون «به»: /usd_eur ، /USD_EUR
        if (
            after is None
            and len(before_clean) == 2
            and all(re.fullmatch(r"[a-z]{3}", t) for t in before_clean)
        ):
            c1, c2 = before_clean[0].upper(), before_clean[1].upper()
            try:
                rates_probe = await _get_exchange_rates()
            except Exception:
                rates_probe = {}
            if c1 in rates_probe and c2 in rates_probe:
                await handle_fiat_single(event, c1, [c2.lower()])
                return

        fiat_code, used2 = _resolve_alias(before_clean, FIAT_ALIASES)
        if fiat_code and used2 == len(before_clean):
            await handle_fiat_single(event, fiat_code, after)
            return

        crypto_id = await _resolve_crypto_id(before_clean)
        if crypto_id:
            await handle_crypto_single(event, crypto_id, after)
            return

        # شناسایی نشد — برای جلوگیری از تداخل با سایر ماژول‌ها، بی‌صدا خارج می‌شویم
        return
    except Exception:
        # هرگز روی دستورات نامربوط خطا نمایش نمی‌دهیم؛ خطاهای واقعی داخل
        # هندلرهای بالا با try/except مخصوص خودشان به کاربر گزارش می‌شوند.
        return
    
# ════════════════════════════════════════════════════════════════════════
#  راه‌اندازی / Setup
# ════════════════════════════════════════════════════════════════════════

def setup(client):
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\s*/(.+?)\s*$"))
    async def _market_entry(event):
        await _dispatch(event)