"""
mass_message.py
================
ماژول «پیام همگانی» و «پیام زمان‌دار» — جایگزین دکمه‌ی قدیمی اسپم توی پنل.

⚠️ کاملاً مستقل و self-contained — مستقیم از panel_state.json می‌خونه/می‌نویسه
(دقیقاً مثل forced_join.py)، به core/state.py یا core/utils.py نیازی نداره.

دو بخش:
  1) پیام همگانی  → ارسال یک پیام (با تاخیر دلخواه) به چند نفر همزمان
                     (مخاطبین / چت‌کرده‌ها / همه / انتخاب دستی خودِ کاربر)
  2) پیام زمان‌دار → ارسال یک پیام به یک نفر مشخص، هر روز در ساعت معین،
                     برای ۱ روز / ۲ روز / ۷ روز یا همیشگی
"""

import asyncio
import json
import re
import time
from datetime import datetime
from pathlib import Path

from telethon import events
from telethon.errors import FloodWaitError
from telethon.tl.functions.contacts import GetContactsRequest

from core import panel_state

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

_MM_PROMPT_PRESET_FA = (
    "📝 افزودن پیام همگانی\n\n"
    "فرمت ارسال (هر خط جدا):\n"
    "{زمان – مثلاً: همین حالا / 30 ثانیه / 5 دقیقه / 1 ساعت}\n"
    "متن پیام شما\n\n"
    "اگه نمی‌خوای به بعضی‌ها ارسال شه، آیدی یا یوزرنیمشون رو یکی‌یکی، هرکدوم یک خط، زیرش بفرست "
    "(این لیست یعنی «اینا رو حذف کن»، نه اضافه کن)."
)

_MM_PROMPT_CUSTOM_FA = (
    "📝 افزودن پیام همگانی (انتخاب خودم)\n\n"
    "فرمت ارسال (هر خط جدا):\n"
    "{زمان – مثلاً: همین حالا / 30 ثانیه / 5 دقیقه / 1 ساعت}\n"
    "متن پیام شما\n"
    "@user1\n"
    "@user2\n"
    "...\n\n"
    "آیدی عددی هم قبوله."
)

_TM_PROMPT_FA = (
    "📝 پیام زمان‌دار خود را ارسال کنید\n\n"
    "فرمت ارسال (هر خط جدا):\n"
    "{ساعت ۲۴ ساعته – مثلاً: 23:15 یا 3:05 یا 15:40}\n"
    "متن پیام\n"
    "@username یا آیدی عددی\n"
    "1 روز  (یا 2 روز / 7 روز / همیشگی)"
)

_AUDIENCE_LABEL_FA = {
    "contacts": "مخاطبین",
    "chatted":  "چت‌کرده‌ها",
    "everyone": "همه",
    "custom":   "انتخاب خودم",
}

_handling_mm_add = False
_handling_tm_add = False


# ===================== STATE I/O (مستقیم از panel_state.json) =====================

def _load_all() -> dict:
    """نسخه‌ی سنکرونِ قدیمی - دیگه جایی صدا زده نمی‌شه (نگه داشته شده که چیزی
    حذف نشه)؛ برای خوندن/نوشتنِ واقعی از _load_global/_save_global استفاده کن."""
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_all(data: dict):
    try:
        STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

async def _load_global() -> dict:
    """✅ عملکرد+ایمنی: قبلاً این‌جا و توی _save_global هرکدوم مستقیم و
    سنکرون STATE_FILE.read_text/write_text صدا می‌زدن - یعنی هم هر بار کل
    event loop (همه‌ی ماژول‌های self.py) رو تا تمومِ I/O دیسک بلاک می‌کردن،
    هم چون panel_state.json بینِ ~۲۰ ماژولِ دیگه هم مشترکه، هیچ تضمینی نبود
    که دو ماژول هم‌زمان روش ننویسن. حالا از core/panel_state.py رد می‌شه که
    یه asyncio.Lock مشترک داره - هیچ ماژولی به ماژولِ دیگه وصل نمی‌شه، فقط
    همه از یه نقطه‌ی مشترکِ core/ (دقیقاً مثل core/utils.py) رد می‌شن."""
    data = await panel_state.load()
    return data.get("_global", {})

async def _save_global(g: dict):
    async with panel_state.transaction() as data:
        data["_global"] = g


# ===================== PARSERS =====================

def _parse_delay_seconds(text: str) -> int:
    t = text.strip().strip("{}").strip()
    if "همین" in t or "الان" in t or t in ("0", "now"):
        return 0
    m = re.search(r"(\d+)", t)
    if not m:
        return 0
    n = int(m.group(1))
    low = t.lower()
    if "ثانیه" in t or "sec" in low:
        return n
    if "ساعت" in t or "hour" in low:
        return n * 3600
    # پیش‌فرض دقیقه (هم برای "دقیقه" هم هر چیز نامشخص)
    return n * 60

def _parse_target(token: str):
    """یوزرنیم یا آیدی عددی رو از روی متن تشخیص می‌ده"""
    token = token.strip().lstrip("@")
    if token.isdigit():
        return int(token)
    return token

def _parse_time_hhmm(text: str):
    """فقط فرمت ۲۴ ساعته (مثلاً 23:15 یا 3:05) - بدون AM/PM"""
    t = text.strip().strip("{}").strip()
    m = re.search(r"(\d{1,2}):(\d{2})", t)
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    if not (0 <= h <= 23 and 0 <= mi <= 59):
        return None
    return h, mi

def _parse_duration_days(text: str):
    """None = همیشگی، عدد = چند روز ارسال شه"""
    t = text.strip()
    if "همیش" in t or "forever" in t.lower():
        return None
    m = re.search(r"(\d+)", t)
    if m:
        return max(1, int(m.group(1)))
    return 1


# ===================== AUDIENCE RESOLUTION =====================

async def _resolve_contacts(client) -> list:
    try:
        result = await client(GetContactsRequest(hash=0))
        return list(getattr(result, "users", []))
    except Exception:
        return []

async def _resolve_chatted(client) -> list:
    try:
        out = []
        async for d in client.iter_dialogs():
            if d.is_user and not getattr(d.entity, "bot", False) and not getattr(d.entity, "is_self", False):
                out.append(d.entity)
        return out
    except Exception:
        return []

async def _resolve_audience(client, audience_type: str) -> list:
    if audience_type == "contacts":
        return await _resolve_contacts(client)
    if audience_type == "chatted":
        return await _resolve_chatted(client)
    if audience_type == "everyone":
        contacts = await _resolve_contacts(client)
        chatted  = await _resolve_chatted(client)
        merged = {}
        for u in contacts + chatted:
            merged[u.id] = u
        return list(merged.values())
    return []


# ===================== پیام همگانی: اجرای ارسال =====================

async def _send_one(client, target, text: str) -> bool:
    try:
        await client.send_message(target, text)
        return True
    except FloodWaitError as e:
        try:
            await asyncio.sleep(e.seconds + 1)
            await client.send_message(target, text)
            return True
        except Exception:
            return False
    except Exception:
        return False

async def _mm_execute(client, chat_id, audience_type, message_text, target_tokens, delay_seconds):
    if delay_seconds > 0:
        await asyncio.sleep(delay_seconds)

    if audience_type == "custom":
        targets = target_tokens
    else:
        entities = await _resolve_audience(client, audience_type)
        exclude_ids = set()
        for tok in target_tokens:
            try:
                ent = await client.get_entity(tok)
                exclude_ids.add(ent.id)
            except Exception:
                pass
        targets = [e for e in entities if e.id not in exclude_ids]

    sent = failed = 0
    for t in targets:
        ok = await _send_one(client, t, message_text)
        if ok:
            sent += 1
        else:
            failed += 1
        await asyncio.sleep(1.5)   # ⏱️ جلوگیری از فلود/محدودیت تلگرام

    g     = await _load_global()
    items = g.get("mass_messages", [])
    items.insert(0, {
        "audience": audience_type,
        "message":  message_text,
        "sent":     sent,
        "failed":   failed,
        "total":    sent + failed,
        "ts":       time.time(),
    })
    g["mass_messages"] = items[:30]
    await _save_global(g)

    try:
        await client.send_message(chat_id, f"✅ پیام همگانی ارسال شد\nموفق: {sent} | ناموفق: {failed}")
    except Exception:
        pass


# ===================== پیام همگانی: درخواست از پنل + گرفتن جواب توی چت =====================

async def _mm_process_add_request(client, req: dict):
    global _handling_mm_add
    chat_id  = req.get("chat_id")
    audience = req.get("audience")
    if not chat_id or not audience:
        _handling_mm_add = False
        return
    prompt = _MM_PROMPT_CUSTOM_FA if audience == "custom" else _MM_PROMPT_PRESET_FA
    try:
        msg = await client.send_message(chat_id, prompt)
    except Exception:
        _handling_mm_add = False
        return
    g = await _load_global()
    g.pop("mass_message_add", None)
    g["mass_message_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id, "audience": audience}
    await _save_global(g)
    _handling_mm_add = False


async def _mm_request_loop(client):
    global _handling_mm_add
    while True:
        try:
            g   = await _load_global()
            req = g.get("mass_message_add")
            if req and not _handling_mm_add:
                _handling_mm_add = True
                asyncio.get_event_loop().create_task(_mm_process_add_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(3)


# ===================== پیام زمان‌دار: درخواست از پنل + زمانبند =====================

async def _tm_process_add_request(client, req: dict):
    global _handling_tm_add
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_tm_add = False
        return
    try:
        msg = await client.send_message(chat_id, _TM_PROMPT_FA)
    except Exception:
        _handling_tm_add = False
        return
    g = await _load_global()
    g.pop("timed_message_add", None)
    g["timed_message_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_tm_add = False


async def _tm_request_loop(client):
    global _handling_tm_add
    while True:
        try:
            g   = await _load_global()
            req = g.get("timed_message_add")
            if req and not _handling_tm_add:
                _handling_tm_add = True
                asyncio.get_event_loop().create_task(_tm_process_add_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(3)


async def _tm_scheduler_loop(client):
    """هر ۳۰ ثانیه چک می‌کنه؛ اگه ساعتِ یکی از پیام‌های زمان‌دار رسیده باشه می‌فرسته"""
    while True:
        try:
            g       = await _load_global()
            items   = g.get("timed_messages", [])
            now     = datetime.now()
            today   = now.strftime("%Y-%m-%d")
            changed = False
            keep    = []
            for item in items:
                if (item.get("hour") == now.hour and item.get("minute") == now.minute
                        and item.get("last_sent_date") != today):
                    await _send_one(client, item.get("target"), item.get("message", ""))
                    item["last_sent_date"] = today
                    if item.get("remaining_days") is not None:
                        item["remaining_days"] -= 1
                    changed = True

                if item.get("remaining_days") is not None and item.get("remaining_days", 1) <= 0 \
                        and item.get("last_sent_date") is not None:
                    changed = True
                    continue  # تموم شد، نگهش نمی‌داریم

                keep.append(item)

            if changed:
                g["timed_messages"] = keep
                await _save_global(g)
        except Exception:
            pass
        await asyncio.sleep(30)


# ===================== SETUP =====================

def setup(client):

    @client.on(events.NewMessage(outgoing=True))
    async def mm_add_catcher(event):
        text = (event.raw_text or "").strip()
        if not text:
            return
        g       = await _load_global()
        waiting = g.get("mass_message_waiting")
        if not waiting or event.chat_id != waiting.get("chat_id") or event.id <= waiting.get("prompt_id", 0):
            return

        lines = [l.strip() for l in text.splitlines() if l.strip()]

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if text.lower() in ("لغو", "cancel"):
            g.pop("mass_message_waiting", None)
            await _save_global(g)
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, "❌ لغو شد")
            except Exception:
                pass
            return

        if len(lines) < 2:
            try:
                await event.reply("❌ فرمت درست نیست؛ حداقل زمان و متن پیام لازمه.")
            except Exception:
                pass
            return

        audience      = waiting.get("audience")
        delay_seconds = _parse_delay_seconds(lines[0])
        message_text  = lines[1]
        target_tokens = [_parse_target(l) for l in lines[2:]]

        if audience == "custom" and not target_tokens:
            try:
                await event.reply("❌ برای «انتخاب خودم» حداقل یک آیدی/یوزرنیم لازمه.")
            except Exception:
                pass
            return

        g.pop("mass_message_waiting", None)
        await _save_global(g)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass

        asyncio.get_event_loop().create_task(
            _mm_execute(client, event.chat_id, audience, message_text, target_tokens, delay_seconds)
        )

    @client.on(events.NewMessage(outgoing=True))
    async def tm_add_catcher(event):
        text = (event.raw_text or "").strip()
        if not text:
            return
        g       = await _load_global()
        waiting = g.get("timed_message_waiting")
        if not waiting or event.chat_id != waiting.get("chat_id") or event.id <= waiting.get("prompt_id", 0):
            return

        lines = [l.strip() for l in text.splitlines() if l.strip()]

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if text.lower() in ("لغو", "cancel"):
            g.pop("timed_message_waiting", None)
            await _save_global(g)
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, "❌ لغو شد")
            except Exception:
                pass
            return

        if len(lines) < 4:
            try:
                await event.reply("❌ فرمت درست نیست؛ ۴ خط لازمه: ساعت، متن، آیدی/یوزرنیم، مدت.")
            except Exception:
                pass
            return

        hm = _parse_time_hhmm(lines[0])
        if not hm:
            try:
                await event.reply("❌ فرمت ساعت درست نیست. مثال: 1:15 AM یا 13:15")
            except Exception:
                pass
            return

        message_text = lines[1]
        target        = _parse_target(lines[2])
        days          = _parse_duration_days(lines[3])

        g.pop("timed_message_waiting", None)
        items = g.get("timed_messages", [])
        items.append({
            "chat_id":        event.chat_id,
            "hour":           hm[0],
            "minute":         hm[1],
            "message":        message_text,
            "target":         target,
            "remaining_days": days,
            "last_sent_date": None,
        })
        g["timed_messages"] = items
        await _save_global(g)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass

        dur_label = "همیشگی" if days is None else f"{days} روز"
        try:
            await client.send_message(
                event.chat_id,
                f"✅ پیام زمان‌دار ثبت شد\n⏰ {hm[0]:02d}:{hm[1]:02d} → {target}\n🗓 {dur_label}"
            )
        except Exception:
            pass

    asyncio.get_event_loop().create_task(_mm_request_loop(client))
    asyncio.get_event_loop().create_task(_tm_request_loop(client))
    asyncio.get_event_loop().create_task(_tm_scheduler_loop(client))