# media_toolkit.py
# ماژول یکپارچه‌ی رسانه: تبدیل ویدیو <-> ویدیو مسیج / ویس + کات آهنگ، ویس و ویدیو مسیج
#
# دستورات:
#   ./به ویدیو مسیج    یا   ./to tv        (ریپلای روی ویدیو)
#   ./به ویس           یا   ./to voice     (ریپلای روی ویدیو/ویس/آهنگ)
#   روی هر پیام صوتی، ویس یا ویدیو مسیج ریپلای کن و بنویس:
#       01:10-01:35   یا   از 01:10 تا 01:35
#       (بدون کلمه‌ی حالت -> نوع خودِ پیام تعیین می‌کنه: صدا->ویس، ویدیو->ویدیو)
#   یا با ذکر صریح خروجی دلخواه (فارسی/انگلیسی هر دو قبول است):
#       از 01:10 تا 01:35 ویس     -> همیشه فقط صدا/ویس خروجی می‌دهد
#                                    (حتی اگر ریپلای روی ویدیو یا ویدیو مسیج یا آهنگ باشد، فقط صدایش استخراج می‌شود)
#       از 01:10 تا 01:35 ویدیو   -> ویدیو/ویدیو مسیج را کات می‌کند (روی صدای تنها کار نمی‌کند)
#   ./تغییر نام <اسم جدید>   یا   ./rename <اسم جدید>   (ریپلای روی یک آهنگ؛ عنوان آهنگ را تغییر می‌دهد)
#
# نکات رفع‌شده نسبت به نسخه‌ی قبلی:
#   - import asyncio جمع شد بالای فایل (قبلاً پایین فایل بود و فقط به شانس کار می‌کرد)
#   - فایل‌های موقت با uuid یکتا می‌شوند تا در اجرای هم‌زمان تصادم/کرش پیش نیاد
#   - returncode واقعی ffmpeg چک می‌شود، نه فقط وجود فایل خروجی (قبلاً خروجی خالی/خراب هم "موفق" حساب می‌شد)
#   - خطای ffmpeg (stderr) در پیام خطا نمایش داده می‌شود تا دیباگ راحت باشه، بدون هیچ print روی کنسول
#   - دانلود/پردازش/ارسال هر سه در finally پاک‌سازی می‌شوند حتی روی Exception یا لغو
#   - تشخیص نوع مدیا کامل‌تر شد (video / video_note / voice / audio / document با mime صوتی)
#   - نرمال‌سازی حروف عربی/فارسی برای تشخیص دستور (ك/ي/ة و فاصله‌های اضافه)
#   - سرعت انکود به‌شدت بالا رفت: preset veryfast + threads خودکار + faststart
#   - قابلیت جدید: کات ویدیو مسیج (round video) با ffmpeg -ss سریع و فریم‌accurate

import os
import re
import uuid
import asyncio
import subprocess
import concurrent.futures
from io import BytesIO

from pydub import AudioSegment
from telethon import events
from telethon.tl.types import DocumentAttributeAudio

# ---------------------------------------------------------------------------
# تنظیمات پایه
# ---------------------------------------------------------------------------

TEMP_DIR = "temp_media"
os.makedirs(TEMP_DIR, exist_ok=True)

# ترد جدا برای کار سنگین pydub (دیکود/انکود صدا) که بلاک‌کننده است
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)

TIME_PATTERN = re.compile(
    r"(?:از\s*)?(\d+:\d\d)\s*(?:تا|-|to|–|—)\s*(\d+:\d\d)"
    r"(?:\s+(ویس|voice|ویدیو|ویدئو|video)\b)?",
    re.IGNORECASE
)

_ARABIC_MAP = str.maketrans({
    "ي": "ی", "ك": "ک", "ة": "ه",
    "\u200c": " ",  # نیم‌فاصله -> فاصله برای تطبیق راحت‌تر
})


def normalize_fa(text: str) -> str:
    if not text:
        return ""
    text = text.translate(_ARABIC_MAP)
    text = re.sub(r"\s+", " ", text).strip()
    return text


CMD_TO_NOTE = re.compile(r"^[./](به\s*ویدیو\s*مسیج|to\s*tv)$", re.IGNORECASE)
CMD_TO_VOICE = re.compile(r"^[./](به\s*ویس|to\s*voice)$", re.IGNORECASE)
CMD_RENAME = re.compile(r"^[./](?:تغییر\s*نام|rename)\s+(.+)$", re.IGNORECASE)


def parse_time(t: str) -> int:
    m, s = map(int, t.split(":"))
    return (m * 60 + s) * 1000


def new_temp_path(suffix: str) -> str:
    return os.path.join(TEMP_DIR, f"{uuid.uuid4().hex}{suffix}")


def cleanup(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# اجرای ffmpeg به‌صورت async + گرفتن نتیجه واقعی
# ---------------------------------------------------------------------------

async def run_ffmpeg(cmd: list) -> tuple[bool, str]:
    process = await asyncio.create_subprocess_exec(
        *cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    _, stderr = await process.communicate()
    ok = process.returncode == 0
    err_text = stderr.decode(errors="ignore")[-800:] if stderr else ""
    return ok, err_text


def _short_err(err_text: str) -> str:
    return err_text.strip().splitlines()[-1] if err_text.strip() else "دلیل نامشخص"


# ---------------------------------------------------------------------------
# برش صدا (pydub) - منطق نسخه‌ی قبلی که درست بود، بدون تغییر در الگوریتم
# ---------------------------------------------------------------------------

def cut_audio_sync(audio_bytes: BytesIO, start_ms: int, end_ms: int) -> BytesIO:
    audio = AudioSegment.from_file(audio_bytes)
    clipped = audio[start_ms:end_ms]
    out = BytesIO()
    clipped.export(out, format="ogg", codec="libopus")
    out.seek(0)
    out.name = "voice.ogg"
    return out


# ---------------------------------------------------------------------------
# برش ویدیو / ویدیو مسیج با ffmpeg (سریع + دقیق با -ss قبل از -i)
# ---------------------------------------------------------------------------

async def cut_video_ffmpeg(input_path: str, output_path: str, start_ms: int, end_ms: int):
    start_sec = start_ms / 1000
    duration_sec = max((end_ms - start_ms) / 1000, 0.05)
    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{start_sec:.3f}",
        "-i", input_path,
        "-t", f"{duration_sec:.3f}",
        # preset ultrafast کیفیت رو به‌شدت پایین می‌آورد؛ چون کلیپ کوتاهه، medium
        # سرعت کافی داره و crf پایین یعنی کیفیت تقریباً بدون افت نسبت به منبع
        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-threads", "0",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-ac", "1",
        "-movflags", "+faststart",
        output_path,
    ]
    return await run_ffmpeg(cmd)


# ---------------------------------------------------------------------------
# استخراج فقط صدا از یک بازه‌ی زمانی ویدیو/ویدیو مسیج (حالت «ویس» روی برش)
# ---------------------------------------------------------------------------

async def extract_audio_ffmpeg(input_path: str, output_path: str, start_ms: int, end_ms: int):
    start_sec = start_ms / 1000
    duration_sec = max((end_ms - start_ms) / 1000, 0.05)
    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{start_sec:.3f}",
        "-i", input_path,
        "-t", f"{duration_sec:.3f}",
        "-vn",
        "-c:a", "libopus", "-b:a", "128k", "-vbr", "on",
        "-compression_level", "10", "-application", "audio", "-ac", "1",
        output_path,
    ]
    return await run_ffmpeg(cmd)


def setup(client):

    # -----------------------------------------------------------------
    # ۱. تبدیل ویدیو به ویدیو مسیج (نوت دایره‌ای)
    # -----------------------------------------------------------------
    @client.on(events.NewMessage(outgoing=True))
    async def convert_to_video_note(event):
        text = normalize_fa(event.raw_text or "")
        if not CMD_TO_NOTE.match(text):
            return

        if not event.is_reply:
            await event.edit("❌ لطفاً این دستور را روی یک ویدیو ریپلای کنید!")
            return

        reply_msg = await event.get_reply_message()
        if not reply_msg or not (reply_msg.video or reply_msg.gif):
            await event.edit("❌ پیام ریپلای شده حاوی ویدیو نیست.")
            return

        await event.edit("⏳ در حال دانلود و پردازش ویدیو مسیج...")

        input_path = new_temp_path("_input.mp4")
        output_path = new_temp_path("_note.mp4")

        try:
            await reply_msg.download_media(file=input_path)

            cmd = [
                "ffmpeg", "-y", "-i", input_path,
                # ۱) اول یک مربع دقیقاً از رزولوشن خود ویدیو کراپ می‌کنیم (crop فقط
                #    فریم رو می‌بره، هیچ resample‌ای انجام نمی‌ده -> صفر افت کیفیت)
                # ۲) فقط اگر مربع به‌دست‌آمده از 640 بزرگ‌تر بود (سقف واقع‌بینانه‌ی
                #    ویدیو مسیج تلگرام) با فیلتر lanczos که کمترین افت رو داره
                #    کوچیکش می‌کنیم؛ در غیر این صورت دست‌نخورده می‌مونه
                "-vf",
                "crop='min(iw\\,ih)':'min(iw\\,ih)',"
                "scale='if(gt(iw,640),640,iw)':'if(gt(ih,640),640,ih)':flags=lanczos",
                "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-threads", "0",
                "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", "-ac", "1",
                "-movflags", "+faststart",
                output_path,
            ]
            ok, err = await run_ffmpeg(cmd)

            if not ok or not os.path.exists(output_path):
                await event.edit(f"❌ خطا در پردازش ویدیو:\n{_short_err(err)}")
                return

            await event.edit("🚀 در حال ارسال ویدیو مسیج...")
            await client.send_file(
                event.chat_id,
                output_path,
                video_note=True,
                reply_to=reply_msg.id,
            )
            await event.delete()

        except Exception as e:
            await event.edit(f"❌ خطایی رخ داد: {str(e)}")
        finally:
            cleanup(input_path, output_path)

    # -----------------------------------------------------------------
    # ۲. تبدیل ویدیو/فایل صوتی به ویس
    # -----------------------------------------------------------------
    @client.on(events.NewMessage(outgoing=True))
    async def convert_to_voice(event):
        text = normalize_fa(event.raw_text or "")
        if not CMD_TO_VOICE.match(text):
            return

        if not event.is_reply:
            await event.edit("❌ لطفاً این دستور را روی یک ویدیو یا فایل صوتی ریپلای کنید!")
            return

        reply_msg = await event.get_reply_message()
        is_audio_doc = bool(
            reply_msg and reply_msg.document
            and reply_msg.document.mime_type
            and "audio" in reply_msg.document.mime_type
        )
        if not reply_msg or not (
            reply_msg.video or reply_msg.video_note
            or reply_msg.audio or reply_msg.voice or is_audio_doc
        ):
            await event.edit("❌ پیام ریپلای شده حاوی ویدیو یا صدا نیست.")
            return

        await event.edit("⏳ در حال استخراج و تبدیل به ویس...")

        ext = (reply_msg.file.ext or "") if reply_msg.file else ""
        input_path = new_temp_path(f"_input{ext}")
        output_path = new_temp_path("_voice.ogg")

        try:
            await reply_msg.download_media(file=input_path)

            cmd = [
                "ffmpeg", "-y", "-i", input_path,
                "-vn",
                # application=audio (به‌جای voip) فرکانس‌های صدا رو کات نمی‌کنه،
                # و بیت‌ریت ۱۲۸k یعنی عملاً بدون افت محسوس نسبت به منبع
                "-c:a", "libopus", "-b:a", "128k", "-vbr", "on",
                "-compression_level", "10", "-application", "audio", "-ac", "1",
                output_path,
            ]
            ok, err = await run_ffmpeg(cmd)

            if not ok or not os.path.exists(output_path):
                await event.edit(f"❌ خطا در استخراج صدا:\n{_short_err(err)}")
                return

            await event.edit("🚀 در حال ارسال ویس...")
            await client.send_file(
                event.chat_id,
                output_path,
                voice_note=True,
                reply_to=reply_msg.id,
            )
            await event.delete()

        except Exception as e:
            await event.edit(f"❌ خطایی رخ داد: {str(e)}")
        finally:
            cleanup(input_path, output_path)

    # -----------------------------------------------------------------
    # ۳. کات آهنگ / ویس / ویدیو مسیج / ویدیو با ریپلای + بازه‌ی زمانی در متن
    #    می‌تونی صریحاً بگی خروجی «ویس» باشه یا «ویدیو» باشه؛ اگر نگی،
    #    طبق نوع خودِ پیام ریپلای‌شده انتخاب می‌شه (رفتار نسخه‌ی قبلی)
    # -----------------------------------------------------------------
    @client.on(events.NewMessage(outgoing=True))
    async def media_cutter_handler(event):
        # روی دستورات بالا خودش match نمی‌کند چون آن‌ها الگوی زمانی ندارند
        if not event.is_reply:
            return

        match = TIME_PATTERN.search(event.raw_text or "")
        if not match:
            return

        replied = await event.get_reply_message()
        if not replied:
            return

        is_audio = (
            replied.audio or replied.voice or
            (replied.document and replied.document.mime_type and "audio" in replied.document.mime_type)
        )
        is_video_note = bool(replied.video_note)
        is_video = bool(replied.video) and not is_video_note

        if not (is_audio or is_video_note or is_video):
            return  # پیام نامرتبط -> ساکت برمی‌گردیم، بدون تداخل با ماژول‌های دیگر

        start_str, end_str, mode_raw = match.groups()
        start_ms, end_ms = parse_time(start_str), parse_time(end_str)
        if end_ms <= start_ms:
            await event.reply("❌ زمان پایان باید بعد از زمان شروع باشد.")
            return

        # تشخیص حالت درخواستی از روی کلمه‌ی انتهای متن؛ اگر ذکر نشده بود
        # طبق نوع خودِ پیام ریپلای‌شده تصمیم می‌گیریم (رفتار قدیمی/پیش‌فرض)
        mode = None
        if mode_raw:
            m = mode_raw.strip().lower()
            if m in ("ویس", "voice"):
                mode = "voice"
            elif m in ("ویدیو", "ویدئو", "video"):
                mode = "video"
        if mode is None:
            mode = "voice" if is_audio else "video"

        if mode == "video" and not (is_video or is_video_note):
            await event.reply("❌ این پیام ویدیو ندارد که کات کنم.")
            return

        status = await event.reply("در حال کات کردن... ⚡")

        # --- حالت ویس روی یک پیام صوتی: همون مسیر سریع pydub قبلی ---
        if mode == "voice" and is_audio:
            input_bytes = BytesIO()
            try:
                await replied.download_media(file=input_bytes)
                input_bytes.seek(0)

                loop = asyncio.get_event_loop()
                out = await loop.run_in_executor(
                    _executor, cut_audio_sync, input_bytes, start_ms, end_ms
                )

                await status.edit("در حال ارسال ویس کات‌شده... 🚀")
                await client.send_file(
                    entity=event.chat_id,
                    file=out,
                    voice_note=True,
                    caption=f"✂️ کات شده: {start_str} تا {end_str}",
                    reply_to=replied.id,
                )
                await status.delete()
            except Exception as e:
                await status.edit(f"❌ خطا در کات:\n{str(e)}")
            return

        # --- حالت ویس روی ویدیو/ویدیو مسیج: استخراج صدا با ffmpeg ---
        if mode == "voice":
            input_path = new_temp_path("_input.mp4")
            output_path = new_temp_path("_extract.ogg")
            try:
                await replied.download_media(file=input_path)

                ok, err = await extract_audio_ffmpeg(input_path, output_path, start_ms, end_ms)
                if not ok or not os.path.exists(output_path):
                    await status.edit(f"❌ خطا در استخراج صدا:\n{_short_err(err)}")
                    return

                await status.edit("در حال ارسال ویس... 🚀")
                await client.send_file(
                    entity=event.chat_id,
                    file=output_path,
                    voice_note=True,
                    caption=f"✂️ صدای استخراج‌شده: {start_str} تا {end_str}",
                    reply_to=replied.id,
                )
                await status.delete()
            except Exception as e:
                await status.edit(f"❌ خطا در کات:\n{str(e)}")
            finally:
                cleanup(input_path, output_path)
            return

        # --- حالت ویدیو: کات ویدیو/ویدیو مسیج با ffmpeg ---
        input_path = new_temp_path("_input.mp4")
        output_path = new_temp_path("_cut.mp4")
        try:
            await replied.download_media(file=input_path)

            ok, err = await cut_video_ffmpeg(input_path, output_path, start_ms, end_ms)
            if not ok or not os.path.exists(output_path):
                await status.edit(f"❌ خطا در برش ویدیو:\n{_short_err(err)}")
                return

            await status.edit("در حال ارسال ویدیوی کات‌شده... 🚀")
            await client.send_file(
                entity=event.chat_id,
                file=output_path,
                video_note=is_video_note,
                caption=None if is_video_note else f"✂️ کات شده: {start_str} تا {end_str}",
                reply_to=replied.id,
            )
            await status.delete()
        except Exception as e:
            await status.edit(f"❌ خطا در کات:\n{str(e)}")
        finally:
            cleanup(input_path, output_path)

    # -----------------------------------------------------------------
    # ۴. تغییر نام آهنگ با ریپلای روی یک آهنگ
    # -----------------------------------------------------------------
    @client.on(events.NewMessage(outgoing=True))
    async def rename_audio_handler(event):
        text = normalize_fa(event.raw_text or "")
        match = CMD_RENAME.match(text)
        if not match:
            return

        new_name = match.group(1).strip()
        if not new_name:
            await event.edit("❌ اسم جدید را بعد از دستور بنویس.")
            return

        if not event.is_reply:
            await event.edit("❌ لطفاً این دستور را روی یک آهنگ ریپلای کنید!")
            return

        replied = await event.get_reply_message()
        if not replied or not replied.audio:
            await event.edit("❌ پیام ریپلای‌شده یک آهنگ نیست.")
            return

        await event.edit("⏳ در حال تغییر نام آهنگ...")

        file_bytes = BytesIO()
        try:
            await replied.download_media(file=file_bytes)
            file_bytes.seek(0)

            ext = replied.file.ext or ".mp3"
            file_bytes.name = f"{new_name}{ext}"

            duration = int(replied.file.duration or 0)
            performer = replied.file.performer
            attributes = [DocumentAttributeAudio(
                duration=duration, title=new_name, performer=performer
            )]

            # اگه پیام ریپلای‌شده خودمون فرستادیم، اول سعی می‌کنیم دقیقاً همون
            # پیام رو ادیت کنیم (رنیم واقعی، بدون کپی جدید). اگه ممکن نبود
            # (پیام از طرف دیگری بوده یا زمان ادیت گذشته) یک نسخه‌ی جدید می‌فرستیم
            if replied.out:
                try:
                    await client.edit_message(
                        event.chat_id, replied.id,
                        file=file_bytes, attributes=attributes,
                    )
                    await event.delete()
                    return
                except Exception:
                    file_bytes.seek(0)

            await client.send_file(
                event.chat_id, file=file_bytes, attributes=attributes,
                voice_note=False, reply_to=replied.id,
            )
            await event.delete()

        except Exception as e:
            await event.edit(f"❌ خطایی رخ داد: {str(e)}")