"""
movie_finder.py — ماژول هوشمند و دو زبانه فیلم TITAN SelF
دستورات:
  /فیلم [نام فیلم]  -> خروجی کاملاً فارسی
  /movie [نام فیلم] -> خروجی کاملاً انگلیسی
"""

import re
import aiohttp
from telethon import events

OMDB_API_KEY = "d7875a74"

# ✅ عملکرد: قبلاً هم اینجا (translate_to_persian) هم پایین‌تر (movie_handler)
# هر بار یه aiohttp.ClientSession تازه ساخته می‌شد - یعنی هر دستورِ /فیلم یا
# /movie، حداقل یک اتصالِ TCP/TLS تازه (بدون هیچ connection reuse‌ای). یه
# session مشترک که فقط یه‌بار ساخته می‌شه و بینِ همه‌ی درخواست‌های این ماژول
# reuse می‌شه، این هندشیک‌های تکراری رو حذف می‌کنه.
_session: aiohttp.ClientSession | None = None


async def _get_session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    return _session


async def translate_to_persian(text: str) -> str:
    """✅ عملکرد: قبلاً با requests.get سنکرون بود - یعنی موقعِ ترجمه‌ی خلاصه‌ی
    داستان، کل ربات (همه‌ی ماژول‌های دیگه‌ی self.py هم) تا جوابِ گوگل ترنسلیت
    فریز می‌شد. الان با همون session مشترکِ aiohttp غیرمسدودکننده‌ست."""
    try:
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=fa&dt=t&q={text}"
        session = await _get_session()
        async with session.get(url) as response:
            res = await response.json()
        return "".join([sentence[0] for sentence in res[0]])
    except Exception:
        return text # اگر اینترنت قطع بود یا ارور داد، همان متن انگلیسی را برگرداند
    
def setup(client):

    # مچ کردن هر دو دستور فارسی و انگلیسی
    @client.on(events.NewMessage(outgoing=True, pattern=r"(?i)^[/]?(فیلم|movie)\s+(.+)"))
    async def movie_handler(event):
        command = event.pattern_match.group(1).lower()
        movie_name = event.pattern_match.group(2).strip()
        
        # تشخیص زبان بر اساس نوع دستور ورودی کاربر
        is_persian = (command == "فیلم")

        # پیام لودینگ اختصاصی هر زبان
        if is_persian:
            await event.edit(f"```\n🔍 در حال استخراج دیتای جهانی فیلم:\n🎬 «{movie_name}» ... لطفاً صبر کن\n```")
        else:
            await event.edit(f"```\n🔍 Fetching global movie data:\n🎬 '{movie_name}' ... Please wait\n```")

        search_query = movie_name.replace(" ", "+")
        url = f"http://www.omdbapi.com/?t={search_query}&apikey={OMDB_API_KEY}"

        try:
            session = await _get_session()
            async with session.get(url) as response:
                data = await response.json()

            if data.get("Response") == "False":
                if is_persian:
                    return await event.edit(f"```\n❌ فیلمی با نام «{movie_name}» پیدا نشد.\n```\n\n\n**__AXoRA SelF__**")
                else:
                    return await event.edit(f"```\n❌ Movie '{movie_name}' not found.\n```\n\n\n**__AXoRA SelF__**")

            # استخراج اطلاعات اصلی
            title = data.get("Title", "N/A")
            year = data.get("Year", "N/A")
            imdb_rating = data.get("imdbRating", "N/A")
            runtime = data.get("Runtime", "N/A")
            genre = data.get("Genre", "N/A")
            plot = data.get("Plot", "N/A")
            if is_persian and plot != "N/A":
                plot = await translate_to_persian(plot)
            encoded_title = title.replace(" ", "%20")
            
            # 🟢 بهینه‌سازی ۱۰۰٪ قطعی لینک تلگرام (باز کردن سرچ باکس داخلی اکانت روی فیلم)
            telegram_direct = f"https://t.me/share/url?url=https://t.me/search?q={encoded_title}"
            
            # 🟢 لینک مستقیم یوتیوب (ارجاع مستقیم به واچ هاب یا فیلم کامل برای دور زدن سرچ عمومی)
            youtube_direct = f"https://www.youtube.com/results?search_query={encoded_title}+full+movie"
            
            # 🟢 لینک مستقیم گوگل
            google_direct = f"https://www.google.com/search?q=دانلود+فیلم+{encoded_title}+با+لینک+مستقیم"

            # ساختاربندی متن بر اساس زبان دستور
            if is_persian:
                info_text = (
                    f"🎬 نام فیلم: {title}\n"
                    f"📅 سال ساخت: {year}\n"
                    f"⭐️ امتیاز ای‌ام‌دی‌بی: {imdb_rating}/10\n"
                    f"⏳ مدت زمان: {runtime}\n"
                    f"🎭 ژانر: {genre}\n\n"
                    f"📝 خلاصه داستان: {plot}"
                )
                
                lines = [
                    f"```\n{info_text}\n```",
                    "🔗 **لینک‌های مستقیم تماشا و دانلود فیلم:**\n",
                    f"🔹 [دانلود مستقیم فایل فیلم در تلگرام]({telegram_direct})",
                    "", 
                    f"🔹 [تماشای مستقیم فیلم در یوتیوب]({youtube_direct})",
                    "", 
                    f"🔹 [دانلود از سایت‌های ایرانی در گوگل]({google_direct})",
                    "",
                    "",
                    "**__AXoRA SelF__**"
                ]
            else:
                info_text = (
                    f"🎬 Title: {title}\n"
                    f"📅 Year: {year}\n"
                    f"⭐️ IMDb Rating: {imdb_rating}/10\n"
                    f"⏳ Runtime: {runtime}\n"
                    f"🎭 Genre: {genre}\n\n"
                    f"📝 Plot: {plot}"
                )
                
                lines = [
                    f"```\n{info_text}\n```",
                    "🔗 **Direct Watch & Download Links:**\n",
                    f"🔹 [Search & Download in Telegram]({telegram_direct})",
                    "", 
                    f"🔹 [Watch Directly on YouTube]({youtube_direct})",
                    "", 
                    f"🔹 [Search Web Links on Google]({google_direct})",
                    "",
                    "",
                    "**__AXoRA SelF__**"
                ]

            final_output = "\n".join(lines)
            await event.edit(final_output, parse_mode='markdown', link_preview=False)

        except Exception:
            if is_persian:
                await event.edit(f"```\n❌ مشکلی در اتصال به سرور جهانی فیلم رخ داد.\n```\n\n\n**__AXoRA SelF__**")
            else:
                await event.edit(f"```\n❌ Error connecting to global movie servers.\n```\n\n\n**__AXoRA SelF__**")