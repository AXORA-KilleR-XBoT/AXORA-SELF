import asyncio
import contextlib
import hashlib
import logging
import shutil
import sqlite3
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

import aiofiles
import aiohttp
from shazamio import Shazam
from telethon import TelegramClient, events
from telethon.tl.custom import Message

__all__ = ["setup"]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------

COMMAND_PATTERN: Final[str] = r"^/موزیک\s*$"
TEMP_DIR: Final[Path] = Path(tempfile.gettempdir()) / "tg_music_module"
DOWNLOAD_TIMEOUT: Final[int] = 120
FFMPEG_TIMEOUT: Final[int] = 120
RECOGNITION_TIMEOUT: Final[int] = 40

_DEFAULT_EXTENSIONS: Final[dict[str, str]] = {
    "voice": ".ogg",
    "audio": ".mp3",
    "video": ".mp4",
}

CACHE_DIR: Final[Path] = Path(__file__).resolve().parent.parent / "data" / "music" / "cache"
CACHE_DB_PATH: Final[Path] = CACHE_DIR / "recognition_cache.sqlite3"
MAX_CACHE_ENTRIES: Final[int] = 300  # سقفِ تعدادِ آهنگِ کش‌شده - جلوگیری از رشدِ بی‌حدِ دیسک
PIPELINE_CONCURRENCY: Final[int] = 3
_pipeline_semaphore = asyncio.Semaphore(PIPELINE_CONCURRENCY)

# ---------------------------------------------------------------------------
# User-facing (Persian) messages
# ---------------------------------------------------------------------------

MSG_IDENTIFYING: Final[str] = "🔎 در حال شناسایی موزیک..."
MSG_NO_REPLY: Final[str] = (
    "❌ لطفاً روی یک پیام صوتی، آهنگ یا ویدیو ریپلای کرده و دوباره دستور را ارسال کنید."
)
MSG_UNSUPPORTED_MEDIA: Final[str] = (
    "❌ نوع فایل ریپلای‌شده پشتیبانی نمی‌شود. فقط ویس، آهنگ و ویدیو قابل شناسایی هستند."
)
MSG_DOWNLOAD_FAILED: Final[str] = "❌ دانلود فایل ریپلای‌شده با خطا مواجه شد. لطفاً دوباره تلاش کنید."
MSG_FFMPEG_MISSING: Final[str] = "❌ FFmpeg روی سیستم نصب نیست. لطفاً با مدیر ربات تماس بگیرید."
MSG_FFMPEG_FAILED: Final[str] = "❌ پردازش فایل صوتی با خطا مواجه شد."
MSG_FFMPEG_TIMEOUT: Final[str] = "⏳ پردازش فایل صوتی بیش از حد طول کشید."
MSG_NO_MATCH: Final[str] = "❌ متأسفانه هیچ موزیکی شناسایی نشد."
MSG_SHAZAM_FAILED: Final[str] = "❌ ارتباط با سرویس شناسایی موزیک با خطا مواجه شد."
MSG_UPLOAD_FAILED: Final[str] = "❌ ارسال نتیجه با خطا مواجه شد."
MSG_TIMEOUT: Final[str] = "⏳ عملیات به دلیل کندی شبکه با خطا مواجه شد. دوباره تلاش کنید."
MSG_UNEXPECTED: Final[str] = "❌ خطای غیرمنتظره‌ای رخ داد. لطفاً دوباره تلاش کنید."


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class _MusicError(Exception):
    """Base class for expected, user-facing errors raised by this module."""

    def __init__(self, user_message: str) -> None:
        self.user_message = user_message
        super().__init__(user_message)


class _NoReplyError(_MusicError):
    """Raised when /موزیک is used without replying to a message."""


class _UnsupportedMediaError(_MusicError):
    """Raised when the replied message has no voice/audio/video media."""


class _MediaDownloadError(_MusicError):
    """Raised when the replied media cannot be downloaded."""


class _FFmpegNotFoundError(_MusicError):
    """Raised when the ffmpeg executable is not available on PATH."""


class _FFmpegProcessError(_MusicError):
    """Raised when ffmpeg exits with an error or times out."""


class _RecognitionFailedError(_MusicError):
    """Raised when Shazam recognition errors out or finds no match."""


class _UploadError(_MusicError):
    """Raised when sending the result back to Telegram fails."""


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class _RecognizedTrack:
    """Metadata Shazam returned for a recognized track."""

    title: str
    artist: str
    album: str | None
    cover_url: str | None
    isrc: str | None
    shazam_url: str | None
    apple_music_url: str | None

# ---------------------------------------------------------------------------
# Media helpers
# ---------------------------------------------------------------------------


def _classify_media(message: Message) -> str | None:
    """Classify *message* as ``'voice'``, ``'audio'``, or ``'video'``.

    Returns ``None`` if the message contains none of those media types.
    """
    if message.voice:
        return "voice"
    if message.audio:
        return "audio"
    if message.video:
        return "video"
    return None


def _guess_extension(message: Message, media_kind: str) -> str:
    """Best-effort file extension for the downloaded source file."""
    file_info = message.file
    if file_info is not None and file_info.ext:
        return file_info.ext
    return _DEFAULT_EXTENSIONS[media_kind]


async def _download_media(
    client: TelegramClient,
    message: Message,
    media_kind: str,
    directory: Path,
) -> Path:
    """Download *message*'s media into *directory* and return its path."""
    extension = _guess_extension(message, media_kind)
    destination = directory / f"source{extension}"

    try:
        downloaded = await asyncio.wait_for(
            client.download_media(message, file=str(destination)),
            timeout=DOWNLOAD_TIMEOUT,
        )
    except asyncio.TimeoutError:
        raise
    except Exception as exc:
        raise _MediaDownloadError(MSG_DOWNLOAD_FAILED) from exc

    if not downloaded:
        raise _MediaDownloadError(MSG_DOWNLOAD_FAILED)

    return Path(downloaded)


async def _download_cover(url: str, directory: Path) -> Path | None:
    """Best-effort download of the track's cover art; ``None`` on failure.

    Cover art is a nice-to-have, not a critical step, so failures here are
    logged and swallowed instead of aborting the whole command.
    """
    destination = directory / "cover.jpg"
    timeout = aiohttp.ClientTimeout(total=DOWNLOAD_TIMEOUT)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as response:
                if response.status != 200:
                    return None
                data = await response.read()
        async with aiofiles.open(destination, "wb") as file:
            await file.write(data)
    except Exception:
        logger.warning("Cover art download failed", exc_info=True)
        return None
    return destination


# ---------------------------------------------------------------------------
# FFmpeg helpers (non-blocking subprocess only)
# ---------------------------------------------------------------------------


async def _run_command(command: list[str], timeout: float) -> None:
    """Execute *command* as a non-blocking subprocess; raise on failure.

    Standard output and standard error are always captured, never printed
    to the console. A missing executable raises :class:`_FFmpegNotFoundError`;
    a non-zero exit status or a timeout raises :class:`_FFmpegProcessError`.
    """
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise _FFmpegNotFoundError(MSG_FFMPEG_MISSING) from exc

    try:
        _, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
    except asyncio.TimeoutError as exc:
        process.kill()
        with contextlib.suppress(ProcessLookupError):
            await process.wait()
        raise _FFmpegProcessError(MSG_FFMPEG_TIMEOUT) from exc

    if process.returncode != 0:
        logger.debug(
            "ffmpeg exited with code %s: %s",
            process.returncode,
            stderr.decode(errors="ignore").strip(),
        )
        raise _FFmpegProcessError(MSG_FFMPEG_FAILED)


async def _prepare_audio_for_recognition(source: Path, directory: Path) -> Path:
    """Normalize *source* into a mono 44.1kHz WAV file for Shazam.

    The same FFmpeg pass extracts the audio track from a video container,
    converts a voice note's Opus/OGG stream, and re-encodes a plain audio
    file — one consistent code path for all three supported media kinds.
    """
    destination = directory / "recognition.wav"
    command = [
        "ffmpeg",
        "-y",
        "-nostdin",
        "-loglevel", "error",
        "-i", str(source),
        "-vn",
        "-ac", "1",
        "-ar", "44100",
        str(destination),
    ]
    await _run_command(command, FFMPEG_TIMEOUT)

    if not destination.exists():
        raise _FFmpegProcessError(MSG_FFMPEG_FAILED)

    return destination


# ---------------------------------------------------------------------------
# Shazam helpers
# ---------------------------------------------------------------------------


async def _recognize_track(audio_path: Path) -> _RecognizedTrack:
    """Identify *audio_path* using Shazam and return parsed metadata."""
    try:
        shazam = Shazam()
        response: dict[str, Any] = await asyncio.wait_for(
            shazam.recognize(str(audio_path)),
            timeout=RECOGNITION_TIMEOUT,
        )
    except asyncio.TimeoutError:
        raise
    except Exception as exc:
        raise _RecognitionFailedError(MSG_SHAZAM_FAILED) from exc

    track_data = response.get("track") if isinstance(response, dict) else None
    if not track_data:
        raise _RecognitionFailedError(MSG_NO_MATCH)

    return _parse_track(track_data)


def _parse_track(track_data: dict[str, Any]) -> _RecognizedTrack:
    """Extract the fields this module needs from Shazam's raw track payload."""
    images = track_data.get("images") or {}

    return _RecognizedTrack(
        title=track_data.get("title") or "نامشخص",
        artist=track_data.get("subtitle") or "نامشخص",
        album=_extract_album(track_data.get("sections") or []),
        cover_url=images.get("coverarthq") or images.get("coverart"),
        isrc=track_data.get("isrc"),
        shazam_url=track_data.get("url"),
        apple_music_url=_extract_apple_music_url(track_data.get("hub") or {}),
    )


def _extract_album(sections: list[dict[str, Any]]) -> str | None:
    """Pull the album name out of Shazam's ``sections`` metadata block."""
    for section in sections:
        if section.get("type") != "SONG":
            continue
        for item in section.get("metadata") or []:
            if item.get("title") == "Album":
                return item.get("text")
    return None


def _extract_apple_music_url(hub: dict[str, Any]) -> str | None:
    """Pull an Apple Music deep link out of Shazam's ``hub`` providers block."""
    for provider in hub.get("providers") or []:
        if provider.get("type") != "APPLEMUSIC":
            continue
        for action in provider.get("actions") or []:
            uri = action.get("uri")
            if uri:
                return uri
    return None


# ---------------------------------------------------------------------------
# Recognition cache (two-tier: Telegram document id, then content SHA-256)
# ---------------------------------------------------------------------------


def _cache_connect() -> sqlite3.Connection:
    """Sync connection + schema init. Only ever called via asyncio.to_thread."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(CACHE_DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS file_lookup ("
        "  document_id INTEGER PRIMARY KEY,"
        "  content_hash TEXT NOT NULL"
        ")"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS recognition_cache ("
        "  content_hash TEXT PRIMARY KEY,"
        "  title TEXT, artist TEXT, album TEXT, cover_url TEXT, isrc TEXT,"
        "  shazam_url TEXT, apple_music_url TEXT,"
        "  mp3_path TEXT, cover_path TEXT,"
        "  last_used REAL NOT NULL"
        ")"
    )
    return conn

_cache_lock = asyncio.Lock()


def _row_to_track(row: sqlite3.Row) -> _RecognizedTrack:
    return _RecognizedTrack(
        title=row["title"],
        artist=row["artist"],
        album=row["album"],
        cover_url=row["cover_url"],
        isrc=row["isrc"],
        shazam_url=row["shazam_url"],
        apple_music_url=row["apple_music_url"],
    )


def _cache_lookup_sync(
    *, document_id: int | None = None, content_hash: str | None = None
) -> tuple[_RecognizedTrack, str | None, str | None] | None:
    """Look up a cached recognition by document_id (tier 1) or content_hash
    (tier 2). Exactly one of the two should be given. Bumps ``last_used`` on
    hit so :func:`_cache_store_sync`'s eviction is a real LRU."""
    conn = _cache_connect()
    try:
        conn.row_factory = sqlite3.Row
        if document_id is not None:
            row = conn.execute(
                "SELECT content_hash FROM file_lookup WHERE document_id = ?",
                (document_id,),
            ).fetchone()
            if row is None:
                return None
            content_hash = row["content_hash"]

        row = conn.execute(
            "SELECT * FROM recognition_cache WHERE content_hash = ?",
            (content_hash,),
        ).fetchone()
        if row is None:
            return None

        mp3_path = row["mp3_path"] if row["mp3_path"] and Path(row["mp3_path"]).exists() else None
        cover_path = row["cover_path"] if row["cover_path"] and Path(row["cover_path"]).exists() else None

        conn.execute(
            "UPDATE recognition_cache SET last_used = ? WHERE content_hash = ?",
            (time.time(), row["content_hash"]),
        )
        if document_id is not None:
            conn.execute(
                "INSERT OR REPLACE INTO file_lookup (document_id, content_hash) VALUES (?, ?)",
                (document_id, row["content_hash"]),
            )
        conn.commit()
        return _row_to_track(row), mp3_path, cover_path
    finally:
        conn.close()


def _cache_store_sync(
    *,
    document_id: int | None,
    content_hash: str,
    track: _RecognizedTrack,
    mp3_path: str | None,
    cover_path: str | None,
) -> None:
    conn = _cache_connect()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO recognition_cache "
            "(content_hash, title, artist, album, cover_url, isrc, shazam_url, "
            " apple_music_url, mp3_path, cover_path, last_used) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                content_hash, track.title, track.artist, track.album, track.cover_url,
                track.isrc, track.shazam_url, track.apple_music_url,
                mp3_path, cover_path, time.time(),
            ),
        )
        if document_id is not None:
            conn.execute(
                "INSERT OR REPLACE INTO file_lookup (document_id, content_hash) VALUES (?, ?)",
                (document_id, content_hash),
            )
        conn.commit()

        total = conn.execute("SELECT COUNT(*) FROM recognition_cache").fetchone()[0]
        if total > MAX_CACHE_ENTRIES:
            stale = conn.execute(
                "SELECT content_hash, mp3_path, cover_path FROM recognition_cache "
                "ORDER BY last_used ASC LIMIT ?",
                (total - MAX_CACHE_ENTRIES,),
            ).fetchall()
            for row in stale:
                for p in (row[1], row[2]):
                    if p:
                        with contextlib.suppress(Exception):
                            Path(p).unlink(missing_ok=True)
                conn.execute("DELETE FROM recognition_cache WHERE content_hash = ?", (row[0],))
            conn.commit()
    finally:
        conn.close()


async def _cache_lookup(
    *, document_id: int | None = None, content_hash: str | None = None
) -> tuple[_RecognizedTrack, str | None, str | None] | None:
    async with _cache_lock:
        return await asyncio.to_thread(
            _cache_lookup_sync, document_id=document_id, content_hash=content_hash
        )


async def _cache_store(
    *,
    document_id: int | None,
    content_hash: str,
    track: _RecognizedTrack,
    mp3_path: Path | None,
    cover_path: Path | None,
) -> None:
    async with _cache_lock:
        await asyncio.to_thread(
            _cache_store_sync,
            document_id=document_id,
            content_hash=content_hash,
            track=track,
            mp3_path=str(mp3_path) if mp3_path else None,
            cover_path=str(cover_path) if cover_path else None,
        )


def _document_id_of(message: Message) -> int | None:
    """Stable, low-level Telegram document id (voice/audio/video), suitable
    for user accounts. Deliberately *not* ``message.file.id``: Telethon's own
    docs flag that bot-API-style id as unmaintained and possibly broken under
    user accounts - this uses the raw document id instead."""
    document = message.voice or message.audio or message.video
    return document.id if document else None


def _sha256_of_file_sync(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


async def _sha256_of_file(path: Path) -> str:
    return await asyncio.to_thread(_sha256_of_file_sync, path)


async def _persist_to_cache_dir(src: Path, content_hash: str) -> Path:
    """Copy a temp-session file into the permanent cache dir under a
    content-addressed name, so it survives after the session dir is wiped."""
    dest = CACHE_DIR / f"{content_hash}{src.suffix}"
    if not dest.exists():
        await asyncio.to_thread(shutil.copyfile, src, dest)
    return dest


async def _download_audio_file(query: str, directory: Path) -> Path | None:
    """Download full audio track using yt-dlp with smart client fallback."""
    output_template = str(directory / "track.%(ext)s")
    final_path = directory / "track.mp3"
    search_query = f"{query} audio"

    # مسیر فایل کوکی رو اینجا بگذار
    COOKIES_FILE = r"C:\Users\hp\Desktop\cookies.txt"   # ← مسیر واقعی خودت

    strategies = [
        # ۱. با فایل کوکی (قوی‌ترین حالت)
        [
            "yt-dlp",
            "--extract-audio",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "--no-playlist",
            "--no-warnings",
            "--default-search", "ytsearch1:",
            "--cookies", COOKIES_FILE,
            "-o", output_template,
            search_query,
        ],
        # ۲. کلاینت‌های مختلف یوتیوب
        [
            "yt-dlp",
            "--extract-audio",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "--no-playlist",
            "--no-warnings",
            "--default-search", "ytsearch1:",
            "--extractor-args", "youtube:player_client=tv_downgraded,android_vr,web",
            "-o", output_template,
            search_query,
        ],
        [
            "yt-dlp",
            "--extract-audio",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "--no-playlist",
            "--no-warnings",
            "--default-search", "ytsearch1:",
            "--extractor-args", "youtube:player_client=mweb,android",
            "-o", output_template,
            search_query,
        ],
        # ۳. ساندکلاد
        [
            "yt-dlp",
            "--extract-audio",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "--no-playlist",
            "--no-warnings",
            "--default-search", "scsearch1:",
            "-o", output_template,
            query,
        ],
    ]

    for cmd in strategies:
        if "--cookies" in cmd and not Path(COOKIES_FILE).exists():
            continue

        proc = None
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=DOWNLOAD_TIMEOUT)

            if proc.returncode == 0 and final_path.exists() and final_path.stat().st_size > 0:
                return final_path

            if proc.returncode != 0:
                err_msg = stderr.decode(errors="ignore").strip()
                logger.warning("yt-dlp strategy failed: %s", err_msg)

        except (asyncio.TimeoutError, TimeoutError):
            logger.warning("yt-dlp strategy timed out after %ss", DOWNLOAD_TIMEOUT)
        except Exception as exc:
            logger.warning("yt-dlp command error: %s", exc)
        finally:
            # اگه هنوز زنده‌ست (مثلاً به‌خاطر timeout)، مطمئن شو واقعاً کشته می‌شه —
            # وگرنه در پس‌زمینه به نوشتن روی همین اسم فایل ادامه می‌ده و استراتژی بعدی رو خراب می‌کنه
            if proc is not None and proc.returncode is None:
                proc.kill()
                with contextlib.suppress(Exception):
                    await proc.wait()

        for f in directory.glob("track.*"):
            with contextlib.suppress(Exception):
                f.unlink()

    return None

# ---------------------------------------------------------------------------
# Presentation helpers
# ---------------------------------------------------------------------------


def _build_result_caption(track: _RecognizedTrack) -> str:
    """Compose the Persian result caption shown to the user."""
    lines = ["🎵 موزیک پیدا شد", "", f"🎶 {track.title}", f"🎤 {track.artist}"]
    if track.album:
        lines.append(f"💿 {track.album}")
    if track.shazam_url:
        lines.append(f"🔗 {track.shazam_url}")
    if track.apple_music_url:
        lines.append(f"🍎 {track.apple_music_url}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Telegram-safety helpers
# ---------------------------------------------------------------------------


async def _safe_edit(event: events.NewMessage.Event, text: str) -> None:
    """Edit the triggering message, logging (not raising) on failure."""
    try:
        await event.edit(text, link_preview=False)
    except Exception:
        logger.warning("Failed to edit status message", exc_info=True)


async def _safe_delete(event: events.NewMessage.Event) -> None:
    """Delete the triggering message, logging (not raising) on failure."""
    try:
        await event.delete()
    except Exception:
        logger.warning("Failed to delete status message", exc_info=True)


async def _cleanup(directory: Path) -> None:
    """Remove every temporary file created for a recognition session."""
    if not directory.exists():
        return
    await asyncio.to_thread(shutil.rmtree, directory, True)


# ---------------------------------------------------------------------------
# Command handler
# ---------------------------------------------------------------------------


async def _send_track_result(
    client: TelegramClient,
    event: events.NewMessage.Event,
    reply: Message,
    caption: str,
    mp3_path: Path | str | None,
    cover_path: Path | str | None,
) -> None:
    """ارسالِ نتیجه - چه تازه شناسایی‌شده چه از کش، دقیقاً همون شکلِ خروجیِ
    قبلی: فایلِ موزیک با کاور به‌عنوانِ thumb، یا فقط کاور، یا فقط متن."""
    if mp3_path is not None:
        # ارسال فایل صوتی MP3 به همراه کاور
        await client.send_file(
            event.chat_id,
            file=str(mp3_path),
            caption=caption,
            thumb=str(cover_path) if cover_path else None,
            attributes=[],  # Telethon به صورت خودکار آن را به عنوان موزیک بشناسد
            reply_to=reply.id,
        )
    elif cover_path is not None:
        # اگر فایل صوتی نبود، فقط کاور و متن ارسال شود
        await client.send_file(
            event.chat_id,
            file=str(cover_path),
            caption=caption,
            reply_to=reply.id,
        )
    else:
        # در صورت عدم وجود فایل و کاور، ویرایش همان پیام
        await _safe_edit(event, caption)
        return
    await _safe_delete(event)


async def _handle_music_command(event: events.NewMessage.Event) -> None:
    """Identify the song in the media that the command message replies to."""
    client: TelegramClient = event.client
    session_id = uuid.uuid4().hex[:8]
    session_dir = TEMP_DIR / session_id

    try:
        reply = await event.get_reply_message()
        if reply is None:
            raise _NoReplyError(MSG_NO_REPLY)

        media_kind = _classify_media(reply)
        if media_kind is None:
            raise _UnsupportedMediaError(MSG_UNSUPPORTED_MEDIA)

        document_id = _document_id_of(reply)
        if document_id is not None:
            hit = await _cache_lookup(document_id=document_id)
            if hit is not None:
                track, mp3_path, cover_path = hit
                logger.info(
                    "Track served from cache tier-1 (session=%s): %s - %s",
                    session_id, track.artist, track.title,
                )
                try:
                    await _send_track_result(
                        client, event, reply, _build_result_caption(track), mp3_path, cover_path
                    )
                except Exception as exc:
                    raise _UploadError(MSG_UPLOAD_FAILED) from exc
                return

        await _safe_edit(event, MSG_IDENTIFYING)
        await asyncio.to_thread(session_dir.mkdir, parents=True, exist_ok=True)

        source_path = await _download_media(client, reply, media_kind, session_dir)

        content_hash = await _sha256_of_file(source_path)
        hit = await _cache_lookup(content_hash=content_hash)
        if hit is not None:
            track, mp3_path, cover_path = hit
            logger.info(
                "Track served from cache tier-2 (session=%s): %s - %s",
                session_id, track.artist, track.title,
            )
            if document_id is not None:
                with contextlib.suppress(Exception):
                    await _cache_store(
                        document_id=document_id, content_hash=content_hash, track=track,
                        mp3_path=Path(mp3_path) if mp3_path else None,
                        cover_path=Path(cover_path) if cover_path else None,
                    )
            try:
                await _send_track_result(
                    client, event, reply, _build_result_caption(track), mp3_path, cover_path
                )
            except Exception as exc:
                raise _UploadError(MSG_UPLOAD_FAILED) from exc
            return

        async with _pipeline_semaphore:
            audio_path = await _prepare_audio_for_recognition(source_path, session_dir)
            track = await _recognize_track(audio_path)

            logger.info(
                "Track recognized (session=%s): %s - %s",
                session_id,
                track.artist,
                track.title,
            )

            cover_path = (
                await _download_cover(track.cover_url, session_dir)
                if track.cover_url
                else None
            )
            caption = _build_result_caption(track)

            raw_query = f"{track.title} {track.artist}"
            search_query = "".join(c if c.isalnum() or c.isspace() else " " for c in raw_query)
            search_query = " ".join(search_query.split())
            audio_mp3_path = await _download_audio_file(search_query, session_dir)

        try:
            persisted_mp3 = (
                await _persist_to_cache_dir(audio_mp3_path, content_hash)
                if audio_mp3_path else None
            )
            persisted_cover = (
                await _persist_to_cache_dir(cover_path, content_hash)
                if cover_path else None
            )
            if persisted_mp3 is not None or persisted_cover is not None:
                await _cache_store(
                    document_id=document_id, content_hash=content_hash, track=track,
                    mp3_path=persisted_mp3, cover_path=persisted_cover,
                )
        except Exception:
            logger.warning("Failed to persist recognition cache (session=%s)", session_id, exc_info=True)

        try:
            await _send_track_result(client, event, reply, caption, audio_mp3_path, cover_path)
        except Exception as exc:
            raise _UploadError(MSG_UPLOAD_FAILED) from exc

    except _MusicError as error:
        logger.info(
            "Music command failed (session=%s): %s", session_id, error.user_message
        )
        await _safe_edit(event, error.user_message)
    except asyncio.TimeoutError:
        logger.warning("Music command timed out (session=%s)", session_id)
        await _safe_edit(event, MSG_TIMEOUT)
    except Exception:
        logger.exception("Unexpected error in music command (session=%s)", session_id)
        await _safe_edit(event, MSG_UNEXPECTED)
    finally:
        await _cleanup(session_dir)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def setup(client: TelegramClient) -> None:
    """Register the /موزیک song-recognition handler on an existing client.

    This is the only function this module exposes. Call it once, after the
    host application has created and started its own ``TelegramClient``::

        from modules import music
        music.setup(client)

    This function only registers an event handler; it never creates a
    client, starts one, defines ``main()``, or runs an event loop.
    """

    @client.on(events.NewMessage(pattern=COMMAND_PATTERN, outgoing=True))
    async def _music_command_handler(event: events.NewMessage.Event) -> None:
        await _handle_music_command(event)

    logger.info("music module: /موزیک handler registered")