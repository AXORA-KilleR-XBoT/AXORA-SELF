import json
import asyncio
from pathlib import Path

from telethon import events

from core import panel_state

STATE_FILE  = Path(__file__).resolve().parent.parent / "panel_state.json"
_PROMPT_MSG = "📝 متن آنلاینی را بفرستید:"

_replied_users: set = set()
_handling_request = False


async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


async def _load_online_state() -> tuple:
    g = await _load_global()
    enabled = g.get("online_mode_enabled", False)
    text    = g.get("online_text", "سلام! الان آنلاینم 🟢")
    return enabled, text


async def _process_text_request(client, req: dict):
    """✅ FIX: userbot توی همون چتی که پنل باز شده prompt می‌فرسته (نه ربات توی پیویش)"""
    global _handling_request
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_request = False
        return
    try:
        msg = await client.send_message(chat_id, _PROMPT_MSG)
    except Exception as e:
        print(f"[online_mode] prompt error: {e}")
        _handling_request = False
        return
    g = await _load_global()
    g.pop("online_text_request", None)
    g["online_text_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_request = False


def setup(client):
    @client.on(events.NewMessage(incoming=True))
    async def online_auto_reply(event):
        if not event.is_private:
            return
        enabled, text = await _load_online_state()
        if not enabled:
            return
        sender = await event.get_sender()
        if not sender or getattr(sender, "bot", False):
            return
        uid = sender.id
        if uid in _replied_users:
            return
        try:
            await event.reply(text)
            _replied_users.add(uid)
        except Exception:
            pass

    @client.on(events.NewMessage(outgoing=True))
    async def online_text_catcher(event):
        """صید متن جدید آنلاینی، بعد از اینکه userbot توی همون چت prompt فرستاد"""
        if not event.is_private:
            return
        text = (event.raw_text or "").strip()
        if text == _PROMPT_MSG:
            return

        g       = await _load_global()
        waiting = g.get("online_text_waiting")
        if not waiting:
            return
        if event.chat_id != waiting.get("chat_id"):
            return
        if event.id <= waiting.get("prompt_id", 0):
            return
        if not text:
            return

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if text.lower() in ("لغو", "cancel"):
            g.pop("online_text_waiting", None)
            await _save_global(g)
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, "❌ لغو شد")
            except Exception:
                pass
            return

        g.pop("online_text_waiting", None)
        g["online_text"] = text
        await _save_global(g)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass
        try:
            await client.send_message(event.chat_id, "✅ متن آنلاینی ذخیره شد")
        except Exception:
            pass

    async def _background_loop():
        """هم وضعیت آنلاین رو چک می‌کنه (برای reset لیست) هم درخواست تنظیم متن رو"""
        global _handling_request
        last_state = False
        while True:
            try:
                g = await _load_global()

                current = g.get("online_mode_enabled", False)
                if last_state and not current:
                    _replied_users.clear()
                last_state = current

                req = g.get("online_text_request")
                if req and not _handling_request:
                    _handling_request = True
                    asyncio.get_event_loop().create_task(_process_text_request(client, req))

            except Exception:
                pass
            await asyncio.sleep(3)

    asyncio.get_event_loop().create_task(_background_loop())