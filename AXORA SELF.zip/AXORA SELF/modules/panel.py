import json
from datetime import date, timedelta
from pathlib import Path
from telethon import events, Button

from core import panel_state

BOT_USERNAME = "Nightmare_AXORA_XBoT"
STATE_FILE   = Path(__file__).resolve().parent.parent / "panel_state.json"

# ===================== OWNER ISOLATION =====================
# ✅ چند-اکانتی: پنلِ Nightmare_AXORA_XBoT بینِ چند سلفِ مختلف مشترکه (هرکدوم
# یه اکانتِ تلگرامِ جدا). برای این‌که تنظیماتِ هرکدوم قاطیِ بقیه نشه، هر
# خواندنی که این فایل از panel_state.json انجام می‌ده باید فقط زیرِ کلیدِ
# خودِ همین اکانت رو ببینه، نه ریشه‌ی مشترکِ فایل - دقیقاً همون لایه‌ای که
# panel_bot.py (سمتِ بات) هم اضافه کرده. آیدیِ خودِ اکانت از client.get_me()
# میاد و فقط یک‌بار کش می‌شه (بعد از setup، وقتی اولین ایونتِ واقعی برسه).

_client_ref = None
_my_id: int | None = None

async def _get_my_id() -> int:
    global _my_id
    if _my_id is None and _client_ref is not None:
        try:
            _my_id = (await _client_ref.get_me()).id
        except Exception:
            return 0
    return _my_id or 0

# ===================== STATE HELPERS =====================
# ✅ عملکرد+ایمنی: این فایل توسطِ ۴ ماژولِ دیگه هم import می‌شه (anti_delete,
# limited, profile_checker, viewonce)، و global_message_tracker پایین همین
# فایل رو برای **هر پیامِ خصوصی** (بدون هیچ فیلتری) صدا می‌زنه. یعنی این
# پرتکرارترین نقطه‌ی خوندن/نوشتنِ panel_state.json توی کل رباته - قبلاً
# سنکرون بود، یعنی رو هر پیامِ خصوصی کل ربات فریز می‌شد. حالا از
# core/panel_state.py (قفلِ مشترک + ترد جدا) رد می‌شه.

async def load_panel_state() -> dict:
    return await panel_state.load()

async def get_my_bucket() -> dict:
    """داده‌ی مخصوصِ همین اکانت - نگاه کن به توضیحِ OWNER ISOLATION بالا."""
    return (await load_panel_state()).get(str(await _get_my_id()), {})

async def get_chat_panel(chat_id: int) -> dict:
    return (await get_my_bucket()).get(str(chat_id), {})

async def get_media_flags(chat_id: int) -> dict:
    return (await get_chat_panel(chat_id)).get("media_flags", {})

async def is_viewonce_blocked(chat_id: int) -> bool:
    return (await get_chat_panel(chat_id)).get("viewonce_blocked", False)

async def is_viewonce_all_off() -> bool:
    return (await get_my_bucket()).get("_global", {}).get("viewonce_all_off", False)

async def get_love_mode(chat_id: int) -> str:
    return (await get_chat_panel(chat_id)).get("love_mode", "idle")

async def get_profile_mode(chat_id: int) -> str:
    return (await get_my_bucket()).get("_global", {}).get("profile_mode", "all")

async def is_shield_enabled(chat_id: int) -> bool:
    return (await get_my_bucket()).get("_global", {}).get("shield_enabled", False)

async def is_profile_check_blocked(user_id: int) -> bool:
    return (await get_my_bucket()).get("_global", {}).get("profile_mode", "all") == "off"

async def is_online_mode_enabled() -> bool:
    return (await get_my_bucket()).get("_global", {}).get("online_mode_enabled", False)

async def get_online_text() -> str:
    return (await get_my_bucket()).get("_global", {}).get("online_text", "سلام! الان آنلاینم 🟢")

async def is_auto_reply_enabled() -> bool:
    return (await get_my_bucket()).get("_global", {}).get("auto_reply_enabled", False)

async def get_auto_reply_text() -> str:
    return (await get_my_bucket()).get("_global", {}).get("auto_reply_text", "در حال حاضر پاسخگو نیستم")

async def get_bio_clock_template() -> str:
    return (await get_my_bucket()).get("_global", {}).get("bio_clock_template", "")

# ===================== STATS RESET =====================

def _get_current_saturday() -> str:
    today = date.today()
    days  = (today.weekday() - 5) % 7
    return (today - timedelta(days=days)).strftime("%Y-%m-%d")

async def check_and_reset_stats():
    try:
        async with panel_state.transaction() as data:
            mine      = data.setdefault(str(await _get_my_id()), {})
            s         = mine.setdefault("_stats", {})
            today_str = date.today().strftime("%Y-%m-%d")
            sat_str   = _get_current_saturday()
            if s.get("last_daily_reset") != today_str:
                for k in ("today_deleted","today_viewonce","today_profile"):
                    s[k] = 0
                for uk in ("deleted_users","viewonce_users","profile_users","chat_users"):
                    for uid in s.get(uk, {}):
                        s[uk][uid]["today"] = 0
                s["last_daily_reset"] = today_str
            if s.get("last_weekly_reset") != sat_str:
                for k in ("week_deleted","week_viewonce","week_profile"):
                    s[k] = 0
                for uk in ("deleted_users","viewonce_users","profile_users","chat_users"):
                    for uid in s.get(uk, {}):
                        s[uk][uid]["week"] = 0
                s["last_weekly_reset"] = sat_str
    except Exception:
        pass

# ===================== STATS LOGGING =====================

async def _log_user_event(category: str, user_id: int, name: str = "", username: str = ""):
    try:
        await check_and_reset_stats()
        async with panel_state.transaction() as data:
            mine  = data.setdefault(str(await _get_my_id()), {})
            s     = mine.setdefault("_stats", {})
            s[f"today_{category}"] = s.get(f"today_{category}", 0) + 1
            s[f"week_{category}"]  = s.get(f"week_{category}",  0) + 1
            users = s.setdefault(f"{category}_users", {})
            uid   = str(user_id)
            if uid not in users:
                users[uid] = {"name": name, "username": username, "today": 0, "week": 0}
            if name:     users[uid]["name"]     = name
            if username: users[uid]["username"] = username
            users[uid]["today"] = users[uid].get("today", 0) + 1
            users[uid]["week"]  = users[uid].get("week",  0) + 1
    except Exception:
        pass

async def log_deleted_message(user_id: int, name: str = "", username: str = ""):
    await _log_user_event("deleted", user_id, name, username)

async def log_viewonce_user(user_id: int, name: str = "", username: str = ""):
    await _log_user_event("viewonce", user_id, name, username)

async def log_profile_user(user_id: int, name: str = "", username: str = ""):
    await _log_user_event("profile", user_id, name, username)

async def add_stat(key: str, amount: int = 1):
    try:
        await check_and_reset_stats()
        async with panel_state.transaction() as data:
            mine = data.setdefault(str(await _get_my_id()), {})
            mine.setdefault("_stats", {})[key] = mine["_stats"].get(key, 0) + amount
    except Exception:
        pass

async def log_user_chat_activity(user_id: int, name: str = "", username: str = ""):
    try:
        await check_and_reset_stats()
        async with panel_state.transaction() as data:
            mine  = data.setdefault(str(await _get_my_id()), {})
            s     = mine.setdefault("_stats", {})
            users = s.setdefault("chat_users", {})
            uid   = str(user_id)
            if uid not in users:
                users[uid] = {"name": name, "username": username, "today": 0, "week": 0}
            if name:     users[uid]["name"]     = name
            if username: users[uid]["username"] = username
            users[uid]["today"] = users[uid].get("today", 0) + 1
            users[uid]["week"]  = users[uid].get("week",  0) + 1
    except Exception:
        pass

def tick(val: bool) -> str:
    return "✅" if val else "❌"

# ===================== SETUP & HANDLERS =====================

def setup(client):
    global _client_ref
    _client_ref = client

    @client.on(events.NewMessage)
    async def global_message_tracker(event):
        if not event.is_private:
            return
        try:
            chat  = await event.get_chat()
            if getattr(chat, "bot", False):
                return
            name  = (getattr(chat, "first_name", "") or "").strip()
            last  = (getattr(chat, "last_name",  "") or "").strip()
            full  = f"{name} {last}".strip() or "ناشناس"
            uname = f"@{chat.username}" if getattr(chat, "username", None) else ""
            await log_user_chat_activity(event.chat_id, full, uname)
        except Exception:
            if event.chat_id:
                await log_user_chat_activity(event.chat_id)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^پنل$"))
    async def panel_handler(event):
        chat_id = event.chat_id

        # ✅ جدید: توی گروه/کانال، وضعیت ادمین یا مالک بودنِ خودم رو کش می‌کنیم
        # توی panel_state.json تا وقتی از پنل روی یه قفل (مثلاً گیف) زده می‌شه،
        # panel_bot.py بدونه اجازه داره فلگ اون گروه رو عوض کنه یا نه.
        if not event.is_private:
            try:
                perms = await client.get_permissions(chat_id, "me")
                is_admin_or_owner = bool(perms.is_admin or perms.is_creator)
            except Exception:
                is_admin_or_owner = False
            try:
                async with panel_state.transaction() as data:
                    mine      = data.setdefault(str(await _get_my_id()), {})
                    chat_data = mine.setdefault(str(chat_id), {})
                    chat_data["group_admin"] = is_admin_or_owner
            except Exception:
                pass

        try:
            results = await client.inline_query(BOT_USERNAME, str(chat_id))
            if results:
                await results[0].click(chat_id)
                await event.delete()
                return
        except Exception:
            pass

        try:
            s      = await get_chat_panel(chat_id)
            lang   = s.get("lang", "fa")
            g      = (await get_my_bucket()).get("_global", {})
            shield = g.get("shield_enabled", False)
            online = g.get("online_mode_enabled", False)
            auto_r = g.get("auto_reply_enabled", False)
            fa     = lang == "fa"

            def t(fa_txt, en_txt):
                return fa_txt if fa else en_txt

            buttons = [
                [Button.inline(t("📊 آمار","📊 Stats"), data=f"menu:stats:{chat_id}".encode())],
                [
                    Button.inline(t("⚙️ محدودیت‌ها","⚙️ Restrictions"), data=f"menu:antifuck:{chat_id}".encode()),
                    Button.inline(t("⏳ ذخیره خودتخریب","⏳ Self-Destruct"), data=f"menu:curse:{chat_id}".encode()),
                ],
                [Button.inline(f"🛡️ {t('سپر امنیتی','Security Shield')} {tick(shield)}", data=f"toggle:shield:{chat_id}".encode())],
                [
                    Button.inline(t("👤 تنظیمات پروفایل","👤 Profile Settings"), data=f"menu:profile:{chat_id}".encode()),
                    Button.inline(t("📥 دانلود استوری","📥 Story Download"),      data=f"menu:story:{chat_id}".encode()),
                ],
                [Button.inline(t("⏰ ساعت بیو","⏰ Bio Clock"), data=f"menu:bio:{chat_id}".encode())],
                [
                    Button.inline(f"🟢 {t('آنلاین','Online')} {tick(online)}",      data=f"menu:online:{chat_id}".encode()),
                    Button.inline(f"💬 {t('پاسخ خودکار','Auto Reply')} {tick(auto_r)}", data=f"menu:autoreply:{chat_id}".encode()),
                ],
                [Button.inline(t("📖 راهنما","📖 Help"), data=f"menu:help:{chat_id}".encode())],
                [
                    Button.inline(f"فارسی {tick(fa)}",         data=f"lang:fa:{chat_id}".encode()),
                    Button.inline(f"English {tick(not fa)}",   data=f"lang:en:{chat_id}".encode()),
                ],
                [Button.inline(t("🗑️ بستن پنل","🗑️ Close Panel"), data=f"menu:close:{chat_id}".encode())],
            ]

            title = "❈ پنل به دستور حاکم باز شد ❈" if fa else "❈ Panel Opened by Ruler's Command ❈"
            await event.edit(title, buttons=buttons)

        except Exception as e:
            await event.edit(f"❌ خطا در لود پنل: {e}")