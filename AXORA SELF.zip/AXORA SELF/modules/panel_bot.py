import asyncio
import json
import time
from contextvars import ContextVar
from datetime import date, timedelta, datetime
from pathlib import Path
from aiogram import Bot, Dispatcher, types
from aiogram.types import (InlineKeyboardMarkup, InlineKeyboardButton,
                           InlineQuery, InlineQueryResultArticle, InlineQueryResultCachedPhoto,
                           InputTextMessageContent, Message, FSInputFile,
                           BotCommand, MenuButtonCommands)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.filters import Command

from core import panel_state
from core import group_stats_state
BOT_TOKEN = ""
OWNER_ID  =

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

# ✅ جدید: عکس بالای پنل - یک عکس با همین اسم اینجا بگذار (jpg یا png)، خودش پیدا می‌شه
PANEL_IMAGE_DIR  = Path(__file__).resolve().parent.parent / "panel_assets"
PANEL_IMAGE_PATH = PANEL_IMAGE_DIR / "panel.jpg"

def _panel_image_path():
    """مسیر فایل عکس پنل رو برمی‌گردونه (jpg/jpeg/png) - اگه نبود None"""
    for ext in ("jpg", "jpeg", "png"):
        p = PANEL_IMAGE_DIR / f"panel.{ext}"
        if p.exists():
            return p
    return None

def _get_panel_image() -> "FSInputFile | None":
    """برای ارسال مستقیم (/start) - یک FSInputFile از روی عکس می‌سازه"""
    p = _panel_image_path()
    return FSInputFile(str(p)) if p else None

async def _ensure_panel_image_cached() -> "str | None":
    """✅ جدید: عکس پنل رو یک‌بار به سرور تلگرام آپلود می‌کنه و file_id رو کش می‌کنه.
    کوئری اینلاین فقط با file_id کش‌شده (یا یک URL عمومی) می‌تونه عکس بفرسته، نه مسیر لوکال -
    برای همین بدون این کش، دکمه‌ی «پنل» (که از طریق inline_query کار می‌کنه) عکس رو نشون نمی‌داد.
    اگه فایل عکس عوض شه (mtime فرق کنه)، خودش دوباره آپلود می‌کنه."""
    p = _panel_image_path()
    if p is None:
        return None
    try:
        mtime = p.stat().st_mtime
    except Exception:
        mtime = None

    g     = await get_global_state()
    cache = g.get("panel_image_cache", {})
    if cache.get("path") == str(p) and cache.get("mtime") == mtime and cache.get("file_id"):
        return cache["file_id"]

    if OWNER_ID == 0:
        return None
    try:
        sent    = await bot.send_photo(OWNER_ID, FSInputFile(str(p)))
        file_id = sent.photo[-1].file_id
        g["panel_image_cache"] = {"file_id": file_id, "mtime": mtime, "path": str(p)}
        await set_global_state(g)
        try:
            await sent.delete()
        except Exception:
            pass
        return file_id
    except Exception as e:
        print(f"[panel_image] cache error: {e}")
        return None

PANEL_TITLE_FA = "<i>❈ پنل به دستور حاکم باز شد ❈</i>"
PANEL_TITLE_EN = "<i>❈ Panel Opened by Ruler's Command ❈</i>"

# گزینه‌های مخاطب هدف برای عضویت اجباری
FJ_AUDIENCE_OPTIONS = [
    ("contacts_chatted",    "مخاطبینی که چت داشته‌ام",                                            "Contacts I've chatted with"),
    ("currently_chatting",  "فقط افرادی که با آنها چت می‌کنم",                                    "Only people I currently chat with"),
    ("new_in_private",      "هر فرد جدیدی که در پیوی من بیاید",                                   "Any new person in my private chat"),
    ("anyone_message",      "هر فردی که به من پیام بدهد",                                          "Anyone who messages me"),
    ("new_except_contacts", "هر فرد جدید، به‌غیر از مخاطبینی که هرگز با آنها چتی نداشته‌ام",      "New people, except contacts I've never chatted with"),
    ("everyone",            "برای همه فعال باشد",                                                  "Active for everyone"),
]

# گزینه‌های فاصله زمانی چرخش تبلیغات چنل (ثانیه, متن فارسی, متن انگلیسی)
CA_INTERVAL_OPTIONS = [
    (30,   "۳۰ ثانیه", "30 Seconds"),
    (60,   "۱ دقیقه",  "1 Minute"),
    (300,  "۵ دقیقه",  "5 Minutes"),
    (600,  "۱۰ دقیقه", "10 Minutes"),
    (1800, "۳۰ دقیقه", "30 Minutes"),
    (3600, "۱ ساعت",   "1 Hour"),
]

# برچسب فارسی/انگلیسی نوع مخاطب برای نمایش در لیست پیام همگانی
_AUDIENCE_LABEL_FA_PB = {
    "contacts": "مخاطبین",
    "chatted":  "چت‌کرده‌ها",
    "everyone": "همه",
    "custom":   "انتخاب خودم",
}

# ===================== OWNER ISOLATION =====================
# ✅ چند-اکانتی: وقتی چند نفر (هرکدوم با سلف خودشون) از همین یک بات استفاده
# می‌کنن، باید تنظیماتِ هرکدوم کاملاً از بقیه جدا بمونه - نه فقط توی نمایش،
# بلکه واقعاً روی دیسک. راه‌حل: هر مقداری که توی panel_state.json ذخیره
# می‌شه، یه لایه‌ی اضافه زیرِ آیدیِ «صاحبِ واقعیِ» همون درخواست می‌شینه.
#
# صاحبِ واقعی از کجا میاد؟ از from_user.id - یعنی همون چیزی که خودِ سرورِ
# تلگرام تضمین می‌کنه (نه چیزی که کلاینت ادعا کنه). این آیدی یک‌بار، دقیقاً
# لحظه‌ای که خودِ سلف inline query می‌زنه (query.from_user.id) یا مستقیم به
# بات پیام می‌ده (msg.from_user.id)، به‌عنوان context set می‌شه، و همون لحظه
# روی callback_data تمام دکمه‌های اون پنل مهر می‌خوره. وقتی بعداً کسی
# (هرکسی، حتی توی یه چتِ مشترک) روی یکی از اون دکمه‌ها کلیک می‌کنه،
# callback_handler این مهر رو با from_user.id واقعیِ کلیک‌کننده مقایسه
# می‌کنه - اگه یکی نبود، هیچ اکشنی اجرا نمی‌شه.

_current_owner: ContextVar[int] = ContextVar("current_owner", default=0)

def _owner_bucket(all_state: dict) -> dict:
    """داده‌ی همون owner فعلی (از _current_owner) رو زیرِ ریشه‌ی فایل برمی‌گردونه -
    اگه وجود نداشته باشه می‌سازتش. همه‌ی توابعِ get/set_chat_state و
    get/set_global_state از همین‌جا رد می‌شن، پس خودشون هیچ تغییری توی
    منطق‌شون لازم ندارن به‌جز همین یه لایه‌ی اضافه."""
    return all_state.setdefault(str(_current_owner.get()), {})

def _migrate_legacy_root_state(all_state: dict) -> bool:
    """✅ مهاجرتِ یک‌باره: قبل از این تغییر، همه‌چیز (chat_id ها و _global)
    مستقیم روی ریشه‌ی فایل بود. اگه هنوز اون حالتِ قدیمی دیده بشه (یعنی
    "_global" مستقیم زیرِ ریشه‌ست، نه زیرِ یه owner)، کل ریشه‌ی فعلی رو
    می‌بریم زیرِ OWNER_ID تا هیچ تنظیمِ قبلیِ خودت گم نشه. فقط یک‌بار،
    همون اولین باری که این نسخه فایل رو می‌خونه، اجرا می‌شه."""
    if "_global" not in all_state:
        return False
    legacy = dict(all_state)
    all_state.clear()
    all_state[str(OWNER_ID)] = legacy
    return True

def _stamp_owner(markup: InlineKeyboardMarkup, owner_id: int) -> InlineKeyboardMarkup:
    """روی callback_data تک‌تکِ دکمه‌های این منو، آیدیِ صاحبِ واقعیش رو به‌شکلِ
    پیشوند مهر می‌زنه (owner|data_قبلی). دکمه‌های بدون callback_data (مثلاً
    دکمه‌ی url توی دیوار عضویت اجباری) دست‌نخورده می‌مونن. اگه یه دکمه از قبل
    مهر خورده باشه (idempotent) دوباره مهر نمی‌خوره."""
    prefix = f"{owner_id}|"
    for row in markup.inline_keyboard:
        for btn in row:
            if btn.callback_data and "|" not in btn.callback_data:
                btn.callback_data = prefix + btn.callback_data
    return markup

# ===================== STATE =====================

_state_cache_data = None
_state_cache_time = 0.0
_STATE_CACHE_TTL = 1.0  # ثانیه - هر کلیک معمولاً چندبار load_state صدا می‌زد، این جلوی تکرارش رو می‌گیره

async def load_state() -> dict:
    """✅ فیکسِ سرعت: قبلاً هر بار صدا زده می‌شد، کل فایل panel_state.json از
    دیسک خونده و پارس می‌شد - و یک کلیک معمولاً چندین بار این رو صدا می‌زد
    (یک‌بار توی callback_handler، دوباره توی خودِ تابعِ ساختِ منو). حالا تا
    ۱ ثانیه از آخرین خوندن گذشته باشه، از حافظه برمی‌گرده - بدون I/O.
    ✅ فیکسِ تازه: وقتی کش رد شده و واقعاً باید از دیسک بخونه، قبلاً سنکرون
    بود (کل ربات رو بلاک می‌کرد)؛ حالا از core/panel_state.py رد می‌شه که هم
    غیرمسدودکننده‌ست هم با نوشتنِ ~۲۰ ماژولِ دیگه روی همون فایل قفلِ مشترک داره."""
    global _state_cache_data, _state_cache_time
    now = time.monotonic()
    if _state_cache_data is not None and (now - _state_cache_time) < _STATE_CACHE_TTL:
        return _state_cache_data
    try:
        _state_cache_data = await panel_state.load()
    except Exception:
        _state_cache_data = {}
    if _migrate_legacy_root_state(_state_cache_data):
        await panel_state.save(_state_cache_data)
    _state_cache_time = now
    return _state_cache_data

async def save_state(data: dict):
    global _state_cache_data, _state_cache_time
    await panel_state.save(data)
    # ✅ کش رو همون لحظه با چیزی که نوشتیم آپدیت می‌کنیم تا خودِ همین کلیک هم
    # فوراً تازه‌ترین نسخه رو ببینه، نه نسخه‌ی یک‌ثانیه‌ای قدیمی‌تر
    _state_cache_data = data
    _state_cache_time = time.monotonic()

async def get_chat_state(chat_id: int) -> dict:
    all_state = await load_state()
    bucket = _owner_bucket(all_state)
    key = str(chat_id)
    if key not in bucket:
        bucket[key] = {
            "lang": "fa",
            "media_flags": {
                "gif": False, "sticker": False, "emoji": False,
                "voice": False, "video": False, "photo": False,
                "videonote": False, "silence": False, "message": False,
                # ── جدید: ۱۲ قفل تازه ──
                "file": False, "music": False, "poll": False, "games": False,
                "inline": False, "hashtag": False, "mention": False, "spoiler": False,
                "longmsg": False, "link": False, "forward": False, "bots": False,
            },
            "viewonce_blocked": False,
            "banned_words": [],
            "group_admin": False,  # ── جدید: کش وضعیت ادمین/مالک بودنِ خودم توی این گروه (توسط panel.py نوشته می‌شه) ──
            # ── جدید: گروه (قفل گروه/اسپم/اد اجباری/خوش‌آمد-ترک) ──
            "group_lock": {
                "close_group_enabled": False,
                "antiflood_enabled": False,
                "forced_add_enabled": False,
                "forced_add_links": [],
                "welcome_mode": "off",
                "welcome_messages": [],
                "welcome_random": False,
                "leave_mode": "off",
                "leave_messages": [],
                "leave_random": False,
            },
        }
        await save_state(all_state)
        return bucket[key]
    s = bucket[key]
    if "lang" not in s:
        s["lang"] = "fa"
    if "media_flags" not in s:
        s["media_flags"] = {
            "gif": False, "sticker": False, "emoji": False,
            "voice": False, "video": False, "photo": False,
            "videonote": False, "silence": False, "message": False,
            "file": False, "music": False, "poll": False, "games": False,
            "inline": False, "hashtag": False, "mention": False, "spoiler": False,
            "longmsg": False, "link": False, "forward": False, "bots": False,
        }
    else:
        mf = s["media_flags"]
        for k in ("gif","sticker","emoji","voice","video","photo","videonote","silence","message",
                  "file","music","poll","games","inline","hashtag","mention","spoiler","longmsg","link","forward","bots"):
            if k not in mf:
                mf[k] = False
    if "banned_words" not in s:
        s["banned_words"] = []
    if "group_admin" not in s:
        s["group_admin"] = False
    _gl_defaults = {
        "close_group_enabled": False, "antiflood_enabled": False,
        "forced_add_enabled": False, "forced_add_links": [],
        "welcome_mode": "off", "welcome_messages": [], "welcome_random": False,
        "leave_mode": "off", "leave_messages": [], "leave_random": False,
    }
    if "group_lock" not in s:
        s["group_lock"] = dict(_gl_defaults)
    else:
        gl = s["group_lock"]
        for k, v in _gl_defaults.items():
            if k not in gl:
                gl[k] = v
    return s

async def set_chat_state(chat_id: int, data: dict):
    all_state = await load_state()
    _owner_bucket(all_state)[str(chat_id)] = data
    await save_state(all_state)

async def get_global_state() -> dict:
    all_state = await load_state()
    g = _owner_bucket(all_state).get("_global", {})
    for k, v in {
        "shield_enabled":      False,
        "profile_mode":        "all",
        "viewonce_all_off":    False,
        "online_mode_enabled": False,
        "online_text":         "سلام! الان آنلاینم 🟢",
        "auto_reply_enabled":  False,
        "auto_reply_rules":    [],
        "bio_clock_enabled":   False,
        "bio_clock_template":  "",
        "story_auto_download": False,
        # ── جدید: پیام همگانی + پیام زمان‌دار ──
        "mass_messages":  [],    # تاریخچه‌ی پیام‌های همگانی ارسال‌شده
        "timed_messages": [],    # پیام‌های زمان‌دار فعال [{chat_id,hour,minute,message,target,remaining_days,last_sent_date}]
        # ── جدید: نگهبان سیاه / حالت روح ──
        "ghost_lastseen_hidden": False,
        "ghost_action_type":     None,   # None یا یکی از: ویس/عکس/ویدیو/بازی/تایپ/استیکر (دقیقاً کلیدهای ACTION_MAP توی GHOST_MODE.py)
        "allowed_users":         [],     # ✅ جدید: لیست آیدی عددیِ کاربرهایی که اجازه استفاده از پنل رو دارن (غیر از OWNER_ID)
        # ── جدید: تبلیغات چنل (چرخش لینک توی بیو) ──
        "channel_ads_enabled":          False,
        "channel_ads_channels":         [],     # [{username, title, link}]
        "channel_ads_interval_seconds": 600,    # پیش‌فرض ۱۰ دقیقه
        "channel_ads_current_index":    0,
        "channel_ads_last_switch":      0,
        # ── جدید: عضویت اجباری ──
        "forced_join_enabled":  False,
        "forced_join_channels": [],     # [{username, title, link}]
        "forced_join_message":  "برای اینکه با من صحبت کنید در چنل های زیر عضو شید",
        "forced_join_audience": "everyone",
        "forced_join_wall_data": {},   # داده موقت دیوار عضویت (برای ارسال از طریق بات)
        # ── جدید: سوپر ترک ──
        "super_track_enabled":  False,
        "super_track_channels": [],   # [{chat_id, title, username, kind}] - فقط جوین‌های تازه، از وقتی روشن شده
        "super_track_leave_request": None,   # {"chat_id": ...} - وقتی «ترک جوین اجباری» زده می‌شه
        # ── جدید: انتی حذف ──
        "anti_delete_enabled": False,
        # ── جدید: منشی (فونت‌ساز پیام) ──
        "secretary_font": None,  # None یا یکی از کلیدهای SECRETARY_FONTS (bold/spoil/italic/mono/strike/underline/quote)
        # ── جدید: اسم چرخشی ──
        "rotating_name_enabled":      False,
        "rotating_name_list":         [],   # [{text, seconds, is_clock, clock_country}]
        "rotating_name_current_index": 0,
        "rotating_name_last_switch":  0,
        "rotating_name_add_request":  None,   # {"chat_id": ...}
        "rotating_name_waiting":      None,   # {"chat_id":..., "prompt_id":...}
        # ── جدید: بایگانی ──
        "archive_action_request": None,  # {"chat_id":..., "action": "archive_groups"|"archive_channels"|"unarchive_groups"|"unarchive_channels"|"restore_previous"} - پنل می‌ذاره
        "archive_undo_snapshot":  None,  # {"action":..., "timestamp":..., "peers": {peer_id_str: prev_folder_id}} - آرشیو.py می‌ذاره تا «حالت قبل» بتونه دقیق برگرده
    }.items():
        if k not in g:
            g[k] = v
    return g

async def set_global_state(data: dict):
    all_state = await load_state()
    _owner_bucket(all_state)["_global"] = data
    await save_state(all_state)

# ===================== STATS RESET =====================

def _get_current_saturday() -> str:
    today = date.today()
    days = (today.weekday() - 5) % 7
    return (today - timedelta(days=days)).strftime("%Y-%m-%d")

async def check_and_reset_stats():
    try:
        data      = await load_state()
        s         = data.setdefault("_stats", {})
        today_str = date.today().strftime("%Y-%m-%d")
        sat_str   = _get_current_saturday()
        changed   = False
        if s.get("last_daily_reset") != today_str:
            for k in ("today_deleted", "today_viewonce", "today_profile"):
                s[k] = 0
            for uk in ("deleted_users", "viewonce_users", "profile_users", "chat_users"):
                for uid in s.get(uk, {}):
                    s[uk][uid]["today"] = 0
            s["last_daily_reset"] = today_str
            changed = True
        if s.get("last_weekly_reset") != sat_str:
            for k in ("week_deleted", "week_viewonce", "week_profile"):
                s[k] = 0
            for uk in ("deleted_users", "viewonce_users", "profile_users", "chat_users"):
                for uid in s.get(uk, {}):
                    s[uk][uid]["week"] = 0
            s["last_weekly_reset"] = sat_str
            changed = True
        if changed:
            data["_stats"] = s
            await save_state(data)
    except Exception:
        pass

# ===================== UTILS =====================

def tick(val: bool) -> str:
    return "✅" if val else "❌"

def radio_tick(cur: str, tgt: str) -> str:
    return "🔹" if cur == tgt else "🔸"

def _t(fa_text: str, en_text: str, fa: bool) -> str:
    return fa_text if fa else en_text

# ===================== روشن/خاموش با زیرصفحه (سپر امنیتی / انتی‌حذف / استوری‌دانلودر) =====================
# ✅ به دستور ارباب: این ۳ تا برگشتن به حالت زیرصفحه‌ی جدا (نه فلیپ مستقیم روی گرید).
# کلیک روی دکمه‌ی گرید اصلی، simple_toggle_menu() رو باز می‌کنه - یک دکمه‌ی تک که بین
# «فعال ✔️» و «خاموش ✖️» عوض می‌شه (نگاه کن به اکشن callback به اسم stog پایین‌تر).

_TOGGLE_LABELS = {
    "shield_enabled":      ("سپر امنیتی",    "Security Shield"),
    "story_auto_download": ("استوری دانلودر", "Story Downloader"),
    "anti_delete_enabled": ("انتی حذف",       "Anti-Delete"),
}

def _build_user_list(users: dict, period: str, suffix_fa: str, suffix_en: str, fa: bool) -> str:
    pfx    = "today" if period == "daily" else "week"
    suffix = suffix_fa if fa else suffix_en
    items  = [(uid, info) for uid, info in users.items() if info.get(pfx, 0) > 0]
    items.sort(key=lambda x: x[1].get(pfx, 0), reverse=True)
    if not items:
        return _t("هیچ موردی ثبت نشده", "Nothing logged yet", fa)
    lines = []
    for uid, info in items[:20]:
        name  = info.get("name") or _t("ناشناس", "Unknown", fa)
        count = info.get(pfx, 0)
        lines.append(f"\u200e{name} : {count} {suffix}")
    return "\n".join(lines)

# ===================== KEYBOARDS =====================

_PH = "placeholder"  # برای قابلیت‌هایی که هنوز ساخته نشدن (فعلاً فقط «به‌زودی» نشون می‌دن)

# هر آیتم: (برچسب فارسی, برچسب انگلیسی, کالبک‌بیس بدون chat_id, کلید تیک یا None)
PANEL_PAGES = [
    # ---------------- صفحه ۱ ----------------
    [
        [("انتی حذف",        "Anti-Delete",         "menu:antidelete",   None),
         ("ذخیره خود تخریب", "Self-Destruct Save",  "menu:curse",        None)],
        [("عشق و دشمن",      "Love & Enemy",        f"{_PH}:loveenemy",  None)],
        [("اطلاعات",         "Info",                f"{_PH}:info",       None),
         ("چکر پروفایل",     "Profile Checker",     "menu:profile",      None)],
        [("دانلود",          "Download",             f"{_PH}:download",  None)],
        [("استوری دانلودر",  "Story Downloader",    "menu:storydl",      "story_auto_download"),
         ("محدودیت",         "Restrictions",        "menu:antifuck",     None)],
        [("QR",              "QR",                  f"{_PH}:qr",         None)],
    ],
    # ---------------- صفحه ۲ ----------------
    [
        [("سپر امنیتی",      "Security Shield",     "menu:shield",       "shield_enabled"),
         ("حالت روح",        "Ghost Mode",          "menu:ghost_mode",   None)],
        [("پینگ",            "Ping",                f"{_PH}:ping",       None)],
        [("آنلاین",          "Online",              "menu:online",      "online_mode_enabled"),
         ("پاسخ خودکار",     "Auto Reply",          "menu:autoreply",   "auto_reply_enabled")],
        [("پیام همگانی",     "Mass Message",        "menu:mass_message", None)],
        [("عضویت اجباری",    "Forced Join",          "menu:forced_join", "forced_join_enabled"),
         ("چنل چرخشی",       "Rotating Channel",    "menu:channel_ads", "channel_ads_enabled")],
        [("ترجمه",           "Translate",           f"{_PH}:translate", None)],
    ],
    # ---------------- صفحه ۳ ----------------
    [
        [("GPT",              "GPT",                 f"{_PH}:gpt",        None),
         ("مارکت",           "Market",              f"{_PH}:market",     None)],
        [("اسپم",            "Spam",                f"{_PH}:spam2",      None)],
        [("بن همگانی",       "Mass Ban",            f"{_PH}:massban",    None),
         ("انیمیشن",         "Animation",           f"{_PH}:animation",  None)],
        [("اهنگ",            "Song",                f"{_PH}:song",       None)],
        [("فیلم",            "Movie",               f"{_PH}:movie",      None),
         ("ویس",             "Voice",               f"{_PH}:voicedl",    None)],
        [("نقطه",            "Dot",                 f"{_PH}:dot",        None)],
    ],
    # ---------------- صفحه ۴ ----------------
    [
        [("بایگانی",         "Archive",              "menu:archive",     None),
         ("گروه",            "Group",                "menu:grouplock",  None)],
        [("فضول پروفایل",    "Profile Snooper",     f"{_PH}:snooper",    None)],
        [("ساعت",            "Clock",                "menu:bio",         None),
         ("اسم چرخشی",       "Rotating Name",       "menu:rotating_name", None)],
        [("سوپر ترک",        "Super Track",         "menu:supertrack",   None)],
        [("تبدیل مدیا",      "Media Convert",        f"{_PH}:mediaconvert", None),
         ("منشی",            "Secretary",           "menu:secretary",    None)],
        [("آمار",            "Stats",                "menu:stats",        None)],
    ],
]
PANEL_PAGES_COUNT = len(PANEL_PAGES)


def _page_label(fa_txt: str, en_txt: str, fa: bool, tick_key, g: dict) -> str:
    # ✅ دیگه هیچ ✔️/✖️ داخل دکمه‌های گرید اصلی نشون داده نمی‌شه - روشن/خاموش
    # بودن این‌ها با باز شدن یک صفحه‌ی جدا (دکمه‌ی «روشن»/«خاموش» واقعی) دیده می‌شه.
    label = fa_txt if fa else en_txt
    return f"{{ {label} }}"


async def _set_current_page(chat_id: int, page: int):
    """✅ جدید: یادآوری آخرین صفحه‌ای که این چت دیده - برای حافظه‌ی پنل"""
    s = await get_chat_state(chat_id)
    if s.get("current_page") != page:
        s["current_page"] = page
        await set_chat_state(chat_id, s)


async def page_menu(chat_id: int, page: int = 1) -> InlineKeyboardMarkup:
    s    = await get_chat_state(chat_id)
    g    = await get_global_state()
    fa   = s.get("lang", "fa") == "fa"
    page = ((page - 1) % PANEL_PAGES_COUNT) + 1   # ✅ همیشه بین ۱ تا PANEL_PAGES_COUNT، چرخشی
    await _set_current_page(chat_id, page)              # ✅ هر بار این صفحه نشون داده شد، به‌عنوان «آخرین صفحه» ذخیره می‌شه

    b = InlineKeyboardBuilder()
    for row in PANEL_PAGES[page - 1]:
        btns = [
            InlineKeyboardButton(text=_page_label(fa_txt, en_txt, fa, tick_key, g),
                                  callback_data=f"{cb_base}:{page}:{chat_id}")
            for fa_txt, en_txt, cb_base, tick_key in row
        ]
        b.row(*btns)

    prev_page = page - 1 if page > 1 else PANEL_PAGES_COUNT
    next_page = page + 1 if page < PANEL_PAGES_COUNT else 1
    b.row(
        InlineKeyboardButton(text="<<",                       callback_data=f"page:{prev_page}:{chat_id}"),
        InlineKeyboardButton(text=f"{page}/{PANEL_PAGES_COUNT}", callback_data=f"page:{page}:{chat_id}"),
        InlineKeyboardButton(text=">>",                       callback_data=f"page:{next_page}:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{{ English {'✔️' if not fa else '✖️'} }}",       callback_data=f"lang:en:{chat_id}"),
        InlineKeyboardButton(text=f"{{ {_t('فارسی','فارسی',fa)} {'✔️' if fa else '✖️'} }}", callback_data=f"lang:fa:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("بستن پنل","Close Panel",fa), callback_data=f"menu:close:{chat_id}"))
    return b.as_markup()


async def main_menu(chat_id: int) -> InlineKeyboardMarkup:
    """نگه‌داشته شده برای سازگاری با همه‌ی دکمه‌های 🔙 بازگشت قدیمی که menu:main صدا می‌زنن"""
    return await page_menu(chat_id, 1)


async def send_panel_message(send_to_chat_id: int, state_chat_id: int, page: int = 1):
    """فرستادن پیام پنل (اولین بار، نه ادیت) - اگه panel_assets/panel.jpg|png باشه با عکس می‌فرسته"""
    s   = await get_chat_state(state_chat_id)
    fa  = s.get("lang", "fa") == "fa"
    cap = PANEL_TITLE_FA if fa else PANEL_TITLE_EN
    markup = _stamp_owner(await page_menu(state_chat_id, page), _current_owner.get())
    img = _get_panel_image()
    if img is not None:
        await bot.send_photo(send_to_chat_id, img, caption=cap, reply_markup=markup, parse_mode="HTML")
    else:
        await bot.send_message(send_to_chat_id, cap, reply_markup=markup, parse_mode="HTML")

def _af_mark(active: bool) -> str:
    """برای همه‌ی دکمه‌های محدودیت‌ها: فعال ✔️ / غیرفعال ✖️"""
    return "✔️" if active else "✖️"

async def antifuck_menu(chat_id: int) -> InlineKeyboardMarkup:
    s  = await get_chat_state(chat_id)
    fa = s.get("lang", "fa") == "fa"
    f  = s.get("media_flags", {})
    b  = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=f"{_t('گیف','GIF',fa)} {_af_mark(f.get('gif',False))}",     callback_data=f"af:gif:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('استیکر','Sticker',fa)} {_af_mark(f.get('sticker',False))}",  callback_data=f"af:sticker:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('ایموجی','Emoji',fa)} {_af_mark(f.get('emoji',False))}",      callback_data=f"af:emoji:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('ویس','Voice',fa)} {_af_mark(f.get('voice',False))}",          callback_data=f"af:voice:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('عکس','Photo',fa)} {_af_mark(f.get('photo',False))}",          callback_data=f"af:photo:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('ویدیو','Video',fa)} {_af_mark(f.get('video',False))}",        callback_data=f"af:video:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('ویدیو مسیج','Video Note',fa)} {_af_mark(f.get('videonote',False))}", callback_data=f"af:videonote:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('پیام','Message',fa)} {_af_mark(f.get('message',False))}",            callback_data=f"af:message:{chat_id}"),
    )
    # ── جدید: ۱۲ قفل تازه ──────────────────────────────────
    b.row(
        InlineKeyboardButton(text=f"{_t('فایل','File',fa)} {_af_mark(f.get('file',False))}",           callback_data=f"af:file:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('موسیقی','Music',fa)} {_af_mark(f.get('music',False))}",       callback_data=f"af:music:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('نظرسنجی','Poll',fa)} {_af_mark(f.get('poll',False))}",        callback_data=f"af:poll:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('بازی‌ها','Games',fa)} {_af_mark(f.get('games',False))}",       callback_data=f"af:games:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('اینلاین','Inline',fa)} {_af_mark(f.get('inline',False))}",     callback_data=f"af:inline:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('هشتگ','Hashtag',fa)} {_af_mark(f.get('hashtag',False))}",     callback_data=f"af:hashtag:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('منشن','Mention',fa)} {_af_mark(f.get('mention',False))}",     callback_data=f"af:mention:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('اسپویلر','Spoiler',fa)} {_af_mark(f.get('spoiler',False))}",   callback_data=f"af:spoiler:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('پیام‌های طولانی','Long Msg',fa)} {_af_mark(f.get('longmsg',False))}", callback_data=f"af:longmsg:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('لینک','Link',fa)} {_af_mark(f.get('link',False))}",            callback_data=f"af:link:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('فوروارد','Forward',fa)} {_af_mark(f.get('forward',False))}",   callback_data=f"af:forward:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('ربات‌ها','Bots',fa)} {_af_mark(f.get('bots',False))}",         callback_data=f"af:bots:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=f"{_t('سکوت','Silence',fa)} {_af_mark(f.get('silence',False))}", callback_data=f"af:silence:{chat_id}"),
        InlineKeyboardButton(text=_t("🚫 کلمه غیر مجاز","🚫 Banned Word",fa),                    callback_data=f"menu:banned_words:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def curse_menu(chat_id: int) -> InlineKeyboardMarkup:
    s          = await get_chat_state(chat_id)
    g          = await get_global_state()
    fa         = s.get("lang", "fa") == "fa"
    dont_trust = _t("اعتماد نکن","Don't Trust",fa)
    apply_all  = _t("اعمال روی همه","Apply All",fa)
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=f"{dont_trust} {tick(s.get('viewonce_blocked',False))}", callback_data=f"curse:block:{chat_id}"),
        InlineKeyboardButton(text=f"{apply_all} {tick(g.get('viewonce_all_off',False))}",  callback_data=f"curse:all:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def profile_menu(chat_id: int) -> InlineKeyboardMarkup:
    s  = await get_chat_state(chat_id)
    g  = await get_global_state()
    fa = s.get("lang", "fa") == "fa"
    m  = g.get("profile_mode", "all")
    b  = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=f"{radio_tick(m,'off')} {_t('خاموش کردن چک پروفایل','Disable Profile Checker',fa)}",    callback_data=f"profmod:off:{chat_id}"))
    b.row(InlineKeyboardButton(text=f"{radio_tick(m,'contacts')} {_t('چک فقط مخاطبین','Check Contacts Only',fa)}",           callback_data=f"profmod:contacts:{chat_id}"))
    b.row(InlineKeyboardButton(text=f"{radio_tick(m,'chats')} {_t('فقط چت‌های فعال','Check Active Chats',fa)}",             callback_data=f"profmod:chats:{chat_id}"))
    b.row(InlineKeyboardButton(text=f"{radio_tick(m,'all')} {_t('همه افراد','Check All Users',fa)}",                         callback_data=f"profmod:all:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def online_menu(chat_id: int) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    g       = await get_global_state()
    fa      = s.get("lang", "fa") == "fa"
    enabled = g.get("online_mode_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=f"{_t('حالت انلاین','Online Mode',fa)} {tick(enabled)}", callback_data=f"online:toggle:{chat_id}"),
        InlineKeyboardButton(text=_t("📝 متن انلاینی","📝 Set Text",fa),                    callback_data=f"online:set_text:{chat_id}")
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def autoreply_menu(chat_id: int) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    g       = await get_global_state()
    fa      = s.get("lang", "fa") == "fa"
    enabled = g.get("auto_reply_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=f"{_t('پاسخ خودکار','Auto Reply',fa)} {tick(enabled)}",
        callback_data=f"autoreply:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("➕ افزودن پاسخ","➕ Add Rule",fa),     callback_data=f"arule:add:{chat_id}"),
        InlineKeyboardButton(text=_t("📋 لیست پاسخ‌ها","📋 Rules List",fa), callback_data=f"arule:list:{chat_id}")
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def autoreply_list_menu(chat_id: int) -> tuple:
    s     = await get_chat_state(chat_id)
    g     = await get_global_state()
    fa    = s.get("lang", "fa") == "fa"
    rules = g.get("auto_reply_rules", [])

    if not rules:
        text = _t("📋 هیچ پاسخی تنظیم نشده", "📋 No auto-reply rules set", fa)
    else:
        lines = []
        for i, r in enumerate(rules, start=1):
            kw  = r.get("keyword", "")
            rsp = r.get("response", "")
            lines.append(f"{i}. {kw} : {rsp}")
        title = _t("📋 لیست پاسخ‌های خودکار", "📋 Auto-Reply Rules", fa)
        text  = f"{title}\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i, r in enumerate(rules):
        kw = r.get("keyword", "")
        b.row(InlineKeyboardButton(text=f"🗑 {kw}", callback_data=f"arule:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("➕ افزودن پاسخ","➕ Add Rule",fa), callback_data=f"arule:add:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa),         callback_data=f"menu:autoreply:{chat_id}"))
    return text, b.as_markup()

async def bio_clock_menu(chat_id: int) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    g       = await get_global_state()
    fa      = s.get("lang", "fa") == "fa"
    enabled = g.get("bio_clock_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=f"{_t('فعال','Active',fa)} {tick(enabled)}",
        callback_data=f"bio:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("بدون متن","City Only",fa),  callback_data=f"bio:city_input:{chat_id}"),
        InlineKeyboardButton(text=_t("متن ساعت","Clock Text",fa), callback_data=f"bio:text_input:{chat_id}")
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

# ── جدید: عضویت اجباری ──────────────────────────────────────

async def forced_join_menu(chat_id: int) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    g       = await get_global_state()
    fa      = s.get("lang", "fa") == "fa"
    enabled = g.get("forced_join_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=f"{_t('عضویت اجباری','Forced Join',fa)} {tick(enabled)}",
        callback_data=f"fj:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("📋 چنل‌های انتخاب شده","📋 Selected Channels",fa), callback_data=f"fj:list:{chat_id}"),
        InlineKeyboardButton(text=_t("➕ اضافه کردن چنل","➕ Add Channel",fa),            callback_data=f"fj:add:{chat_id}")
    )
    b.row(InlineKeyboardButton(
        text=_t("👥 برای چه افرادی فعال باشد","👥 Audience",fa),
        callback_data=f"fj:audience:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def forced_join_list_menu(chat_id: int) -> tuple:
    """لیست چنل‌های ذخیره‌شده با دکمه حذف کنار هرکدوم - دقیقا مثل پاسخ خودکار"""
    s        = await get_chat_state(chat_id)
    g        = await get_global_state()
    fa       = s.get("lang", "fa") == "fa"
    channels = g.get("forced_join_channels", [])

    if not channels:
        text = _t("📋 هیچ چنلی اضافه نشده", "📋 No channels added yet", fa)
    else:
        lines = []
        for i, ch in enumerate(channels, start=1):
            title = ch.get("title", ch.get("username", "?"))
            uname = ch.get("username", "")
            lines.append(f"{i}. {title} (@{uname})")
        title_txt = _t("📋 چنل‌های انتخاب شده", "📋 Selected Channels", fa)
        text = f"{title_txt}\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i, ch in enumerate(channels):
        title = ch.get("title", ch.get("username", "?"))
        b.row(InlineKeyboardButton(text=f"🗑 {title}", callback_data=f"fj:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("➕ اضافه کردن چنل","➕ Add Channel",fa), callback_data=f"fj:add:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa),               callback_data=f"menu:forced_join:{chat_id}"))
    return text, b.as_markup()

async def forced_join_audience_menu(chat_id: int) -> InlineKeyboardMarkup:
    s   = await get_chat_state(chat_id)
    g   = await get_global_state()
    fa  = s.get("lang", "fa") == "fa"
    cur = g.get("forced_join_audience", "everyone")
    b   = InlineKeyboardBuilder()
    for key, fa_label, en_label in FJ_AUDIENCE_OPTIONS:
        b.row(InlineKeyboardButton(
            text=f"{radio_tick(cur, key)} {_t(fa_label, en_label, fa)}",
            callback_data=f"fjaud:{key}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:forced_join:{chat_id}"))
    return b.as_markup()

# ── جدید: تبلیغات چنل (چرخش Personal Channel، نه بیو) ──────

async def channel_ads_menu(chat_id: int) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    g       = await get_global_state()
    fa      = s.get("lang", "fa") == "fa"
    enabled = g.get("channel_ads_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=f"{_t('تبلیغات چنل','Channel Ads',fa)} {tick(enabled)}",
        callback_data=f"ca:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("📋 چنل‌های انتخاب شده","📋 Selected Channels",fa), callback_data=f"ca:list:{chat_id}"),
        InlineKeyboardButton(text=_t("➕ اضافه کردن چنل","➕ Add Channel",fa),            callback_data=f"ca:add:{chat_id}")
    )
    b.row(InlineKeyboardButton(
        text=_t("⏱️ زمان سوئیچ","⏱️ Switch Interval",fa),
        callback_data=f"ca:interval:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def channel_ads_list_menu(chat_id: int) -> tuple:
    """لیست چنل‌های چرخش تبلیغات - دقیقا مثل لیست عضویت اجباری/پاسخ خودکار"""
    s        = await get_chat_state(chat_id)
    g        = await get_global_state()
    fa       = s.get("lang", "fa") == "fa"
    channels = g.get("channel_ads_channels", [])
    cur_idx  = g.get("channel_ads_current_index", 0)

    if not channels:
        text = _t("📋 هیچ چنلی اضافه نشده", "📋 No channels added yet", fa)
    else:
        lines = []
        for i, ch in enumerate(channels, start=1):
            title = ch.get("title", ch.get("username", "?"))
            uname = ch.get("username", "")
            mark  = " 🔵" if (i - 1) == (cur_idx % len(channels)) else ""
            lines.append(f"{i}. {title} (@{uname}){mark}")
        title_txt = _t("📋 چنل‌های تبلیغات (🔵 = الان Personal Channel)", "📋 Ad Channels (🔵 = current Personal Channel)", fa)
        text = f"{title_txt}\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i, ch in enumerate(channels):
        title = ch.get("title", ch.get("username", "?"))
        b.row(InlineKeyboardButton(text=f"🗑 {title}", callback_data=f"ca:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("➕ اضافه کردن چنل","➕ Add Channel",fa), callback_data=f"ca:add:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa),               callback_data=f"menu:channel_ads:{chat_id}"))
    return text, b.as_markup()

async def channel_ads_interval_menu(chat_id: int) -> InlineKeyboardMarkup:
    s   = await get_chat_state(chat_id)
    g   = await get_global_state()
    fa  = s.get("lang", "fa") == "fa"
    cur = g.get("channel_ads_interval_seconds", 600)
    b   = InlineKeyboardBuilder()
    for seconds, fa_label, en_label in CA_INTERVAL_OPTIONS:
        mark = "🔹" if cur == seconds else "🔸"
        b.row(InlineKeyboardButton(
            text=f"{mark} {_t(fa_label, en_label, fa)}",
            callback_data=f"caint:{seconds}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:channel_ads:{chat_id}"))
    return b.as_markup()

# ── جدید: سوپر ترک (ردیابی و ترک گروه/کانال‌هایی که تازه عضو شدی) ──
async def supertrack_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa      = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    enabled = (await get_global_state()).get("super_track_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=_t('فعال','Active',fa) if enabled else _t('خاموش','Off',fa),
        callback_data=f"st:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("لیست جوین اجباری","Join List",fa), callback_data=f"st:list:{chat_id}"),
        InlineKeyboardButton(text=_t("ترک جوین اجباری","Leave Joined",fa), callback_data=f"st:leave:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def supertrack_list_menu(chat_id: int) -> tuple:
    g        = await get_global_state()
    fa       = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    enabled  = g.get("super_track_enabled", False)
    channels = g.get("super_track_channels", [])

    status_line = _t("🟢 روشن","🟢 On",fa) if enabled else _t("🔴 خاموش","🔴 Off",fa)
    if not channels:
        body = _t("هنوز هیچ گروه/کانالی از وقتی روشن بوده ثبت نشده.","No group/channel registered while it was on yet.",fa)
    else:
        lines = []
        for i, ch in enumerate(channels, start=1):
            kind_label = _t("گروه","Group",fa) if ch.get("kind") == "group" else _t("کانال","Channel",fa)
            uname = f"@{ch['username']}" if ch.get("username") else str(ch.get("chat_id"))
            lines.append(f"{i}. [{kind_label}] {ch.get('title','?')} ({uname})")
        body = "\n".join(lines)

    title_txt = _t("🛰 سوپر ترک","🛰 Super Track",fa)
    count_txt = _t(f"تعداد ثبت‌شده: {len(channels)}", f"Registered: {len(channels)}", fa)
    text = f"{title_txt} — {status_line}\n{count_txt}\n\n{body}"

    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:supertrack:{chat_id}"))
    return text, b.as_markup()

# ── جدید: اسم چرخشی ──────────────────────────────────────────
def _rn_live_clock(country: str) -> str:
    """محاسبه‌ی زمانِ لحظه‌ای - فقط برای نمایش وضعیت توی پنل (خودِ سوئیچ واقعی رو ماژول یوزربات انجام می‌ده)"""
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo("Asia/Tehran" if country == "iran" else "America/New_York")
    except Exception:
        import pytz
        tz = pytz.timezone("Asia/Tehran" if country == "iran" else "America/New_York")
    return datetime.now(tz).strftime("%H:%M")

def _rn_item_label(item: dict, fa: bool) -> str:
    if item.get("is_clock"):
        country_txt = _t("ساعت ایران","Iran Time",fa) if item.get("clock_country") == "iran" else _t("ساعت آمریکا","USA Time",fa)
        return f"🕐 {country_txt}"
    return item.get("text", "?")

async def rotating_name_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa      = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    enabled = (await get_global_state()).get("rotating_name_enabled", False)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text=_t('فعال','Active',fa) if enabled else _t('خاموش','Off',fa),
        callback_data=f"rn:toggle:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=_t("لیست اسم‌ها","Name List",fa), callback_data=f"rn:list:{chat_id}"),
        InlineKeyboardButton(text=_t("اضافه کردن اسم","Add Name",fa), callback_data=f"rn:add:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def rotating_name_list_menu(chat_id: int) -> tuple:
    g     = await get_global_state()
    fa    = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    items = g.get("rotating_name_list", [])

    if not items:
        body = _t("هنوز هیچ اسمی اضافه نشده.","No names added yet.",fa)
    else:
        lines = []
        for i, it in enumerate(items, start=1):
            lines.append(f"{i}. {_rn_item_label(it, fa)} — {it.get('seconds',60)}s")
        body = "\n".join(lines)

    title_txt = _t("🔤 لیست اسم‌های چرخشی","🔤 Rotating Name List",fa)
    text = f"{title_txt}\n\n{body}"

    b = InlineKeyboardBuilder()
    for i, it in enumerate(items):
        b.row(InlineKeyboardButton(text=f"🗑 {_rn_item_label(it, fa)}", callback_data=f"rn:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("➕ اضافه کردن اسم","➕ Add Name",fa), callback_data=f"rn:add:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa),           callback_data=f"menu:rotating_name:{chat_id}"))
    return text, b.as_markup()

# ── جدید: کلمه غیر مجاز (حذف خودکار پیام‌های حاوی کلمات ممنوعه) ──
async def banned_words_menu(chat_id: int) -> tuple:
    """لیست کلمات غیرمجاز همین چت - دقیقا مثل لیست تبلیغات چنل (🗑 حذف + ➕ افزودن)"""
    s     = await get_chat_state(chat_id)
    fa    = s.get("lang", "fa") == "fa"
    words = s.get("banned_words", [])

    if not words:
        text = _t("📋 هیچ کلمه‌ی غیرمجازی برای این چت تنظیم نشده", "📋 No banned words set for this chat yet", fa)
    else:
        lines     = [f"{i}. {w}" for i, w in enumerate(words, start=1)]
        title_txt = _t("🚫 کلمات غیر مجاز این چت", "🚫 Banned Words For This Chat", fa)
        text      = f"{title_txt}\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i, w in enumerate(words):
        b.row(InlineKeyboardButton(text=f"🗑 {w}", callback_data=f"bw:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("➕ افزودن کلمه","➕ Add Word",fa), callback_data=f"bw:add:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa),         callback_data=f"menu:antifuck:{chat_id}"))
    return text, b.as_markup()


# ── جدید: پیام همگانی + پیام زمان‌دار ──
async def mass_message_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=_t("📋 لیست زمان‌دار","📋 Timed List",fa), callback_data=f"menu:tm_list:{chat_id}"),
        InlineKeyboardButton(text=_t("📋 لیست همگانی","📋 Mass List",fa),    callback_data=f"menu:mm_list:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=_t("➕ افزودن زمان‌دار","➕ Add Timed",fa), callback_data=f"tm:add:{chat_id}"),
        InlineKeyboardButton(text=_t("➕ افزودن همگانی","➕ Add Mass",fa),    callback_data=f"menu:mm_audience:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()


async def mass_message_audience_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=_t("📇 مخاطبین","📇 Contacts",fa), callback_data=f"mm:add:contacts:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("💬 افرادی که با آنها چت می‌کنم","💬 People I've chatted with",fa), callback_data=f"mm:add:chatted:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🌍 همه","🌍 Everyone",fa), callback_data=f"mm:add:everyone:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("✏️ انتخاب خودم","✏️ Custom Selection",fa), callback_data=f"mm:add:custom:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:mass_message:{chat_id}"))
    return b.as_markup()


async def mass_message_list_menu(chat_id: int) -> tuple:
    g   = await get_global_state()
    fa  = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    items = g.get("mass_messages", [])[:15]

    if not items:
        text = _t("📋 هنوز پیام همگانی‌ای ارسال نشده", "📋 No mass messages sent yet", fa)
    else:
        lines = []
        for i, it in enumerate(items, start=1):
            aud = _AUDIENCE_LABEL_FA_PB.get(it.get("audience"), it.get("audience"))
            preview = (it.get("message", "") or "")[:30]
            lines.append(f"{i}. [{aud}] {preview} — ✅{it.get('sent',0)} ❌{it.get('failed',0)}")
        text = _t("📋 لیست پیام‌های همگانی","📋 Mass Message List",fa) + "\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i in range(len(items)):
        b.row(InlineKeyboardButton(text=f"🗑 {i+1}", callback_data=f"mm:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:mass_message:{chat_id}"))
    return text, b.as_markup()


async def timed_message_list_menu(chat_id: int) -> tuple:
    g   = await get_global_state()
    fa  = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    items = g.get("timed_messages", [])

    if not items:
        text = _t("📋 پیام زمان‌دار فعالی نیست", "📋 No active timed messages", fa)
    else:
        lines = []
        for i, it in enumerate(items, start=1):
            dur = _t("همیشگی","forever",fa) if it.get("remaining_days") is None else f"{it.get('remaining_days')} {_t('روز باقی','days left',fa)}"
            lines.append(f"{i}. ⏰ {it.get('hour',0):02d}:{it.get('minute',0):02d} → {it.get('target')} ({dur})")
        text = _t("📋 لیست پیام‌های زمان‌دار","📋 Timed Message List",fa) + "\n\n" + "\n".join(lines)

    b = InlineKeyboardBuilder()
    for i in range(len(items)):
        b.row(InlineKeyboardButton(text=f"🗑 {i+1}", callback_data=f"tm:del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:mass_message:{chat_id}"))
    return text, b.as_markup()


# ── جدید: نگهبان سیاه (سپر امنیتی + حالت روح) ──
# ── حالت روح (شبیه‌سازیِ اکشن‌های آنلاین - دقیقاً همون منطقِ GHOST_MODE.py) ──
# ✅ کلیدها دقیقاً همون رشته‌های فارسیِ ACTION_MAP توی GHOST_MODE.py هستن، تا
# ماژول یوزربات بدون هیچ لایه‌ی ترجمه‌ای مستقیم از panel_state.json بخونتشون.
_GHOST_ACTION_OPTIONS = [
    ("ویس",    "🎙 در حال ضبط ویس",       "🎙 Recording Voice"),
    ("عکس",    "🖼 در حال ارسال عکس",     "🖼 Sending Photo"),
    ("ویدیو",  "🎥 در حال ارسال ویدیو",   "🎥 Sending Video"),
    ("بازی",   "🎮 در حال بازی",          "🎮 Playing Game"),
    ("تایپ",   "✍️ در حال تایپ",          "✍️ Typing"),
    ("استیکر", "🎨 در حال انتخاب استیکر", "🎨 Choosing Sticker"),
]

async def ghost_mode_menu(chat_id: int) -> InlineKeyboardMarkup:
    g            = await get_global_state()
    fa           = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    current_type = g.get("ghost_action_type")

    b = InlineKeyboardBuilder()
    for i in range(0, len(_GHOST_ACTION_OPTIONS), 2):
        row_btns = []
        for key, fa_label, en_label in _GHOST_ACTION_OPTIONS[i:i+2]:
            mark = " ✅" if current_type == key else ""
            row_btns.append(InlineKeyboardButton(
                text=_t(fa_label, en_label, fa) + mark,
                callback_data=f"gm:action:{key}:{chat_id}"))
        b.row(*row_btns)

    # ✅ فیکس باگ: قبلاً به «menu:black_guardian» برمی‌گشت - صفحه‌ای که توی پنل
    # ۴صفحه‌ای جدید اصلاً وجود نداره (سپر امنیتی و حالت روح مستقیم روی صفحه‌ی
    # ۲ هستن). الان به همون صفحه‌ای که واقعاً ازش اومدی برمی‌گرده.
    back_page = (await get_chat_state(chat_id)).get("current_page", 1)
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"page:{back_page}:{chat_id}"))
    return b.as_markup()


# ── جدید: بایگانی (آرشیو دسته‌جمعیِ گروه‌ها و کانال‌ها + بازگشت به حالت قبل) ──
async def archive_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=_t("بایگانی گروه‌ها","Archive Groups",fa),        callback_data=f"arc:ag:{chat_id}"),
        InlineKeyboardButton(text=_t("بایگانی کانال‌ها","Archive Channels",fa),      callback_data=f"arc:ac:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=_t("حذف بایگانی گروه‌ها","Unarchive Groups",fa),    callback_data=f"arc:ug:{chat_id}"),
        InlineKeyboardButton(text=_t("حذف بایگانی کانال‌ها","Unarchive Channels",fa), callback_data=f"arc:uc:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("حالت قبل","Previous State",fa), callback_data=f"arc:restore:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()


async def stats_main_menu(chat_id: int) -> InlineKeyboardMarkup:
    s  = await get_chat_state(chat_id)
    fa = s.get("lang", "fa") == "fa"
    b  = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=_t("📅 آمار روزانه","📅 Daily Stats",fa),  callback_data=f"stats:daily:{chat_id}"),
        InlineKeyboardButton(text=_t("📆 آمار هفته","📆 Weekly Stats",fa),   callback_data=f"stats:weekly:{chat_id}")
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def stats_period_menu(chat_id: int, period: str, st: dict) -> tuple:
    s     = await get_chat_state(chat_id)
    fa    = s.get("lang", "fa") == "fa"
    pfx   = "today" if period == "daily" else "week"
    label = _t("روزانه","Daily",fa) if period == "daily" else _t("هفتگی","Weekly",fa)
    text = (
        f"📊 {_t('آمار','Stats',fa)} {label}\n\n"
        f"🗑️ {_t('پیام های حذف شده','Deleted Messages',fa)}: {st.get(f'{pfx}_deleted', 0)}\n\n\n"
        f"📸 {_t('عکس های تایم دار','ViewOnce Photos',fa)}: {st.get(f'{pfx}_viewonce', 0)}\n\n\n"
        f"👤 {_t('عکس های پروفایل','Profile Photos',fa)}: {st.get(f'{pfx}_profile', 0)}"
    )
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=_t("🗑️ اسامی پیام های حذف شده","🗑️ Deleted Messages List",fa), callback_data=f"sl:del:{period}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("⏳ اسامی خود تخریب ها","⏳ ViewOnce List",fa),               callback_data=f"sl:vo:{period}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("📸 پروفایل ها","📸 Profiles",fa),                            callback_data=f"sl:prof:{period}:{chat_id}"))
    b.row(InlineKeyboardButton(
        text=_t("💬 چت های امروز","💬 Today's Chats",fa) if period=="daily" else _t("💬 چت های هفته","💬 Week's Chats",fa),
        callback_data=f"sl:chat:{period}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"stats:back:{chat_id}"))
    return text, b.as_markup()

# ── جدید: منشی (فونت‌ساز پیام) ────────────────────────────────
# ✅ کاملاً پنلی - هیچ دستور متنی‌ای (/فونت ...) نمونده. کلیدها دقیقاً باید با
# FONT_STYLES توی secretary.py یکی باشن چون از همین کلیدها توی panel_state.json
# (زیر "_global" → "secretary_font") به‌عنوان قرارداد مشترک استفاده می‌شه.
SECRETARY_FONTS = [
    ("bold",      "بولد",      "Bold"),
    ("spoil",     "اسپویل",    "Spoiler"),
    ("italic",    "ایتالیک",   "Italic"),
    ("mono",      "مونو",      "Monospace"),
    ("strike",    "خط خورده",  "Strikethrough"),
    ("underline", "زیرخط",     "Underline"),
    ("quote",     "نقل قول",   "Quote"),
]

async def secretary_menu(chat_id: int) -> InlineKeyboardMarkup:
    """زیرمنوی منشی - دوتا-دوتا تو هر ردیف. فونتِ فعال با ✅ مشخص می‌شه. آخرین
    فونت (نقل قول) با دکمه‌ی خاموش هم‌ردیف شده تا هیچ ردیفی تک نمونه."""
    fa  = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    g   = await get_global_state()
    cur = g.get("secretary_font")

    b = InlineKeyboardBuilder()
    for i in range(0, len(SECRETARY_FONTS) - 1, 2):
        row_btns = []
        for key, fa_label, en_label in SECRETARY_FONTS[i:i + 2]:
            mark = " ✅" if cur == key else ""
            row_btns.append(InlineKeyboardButton(
                text=_t(fa_label, en_label, fa) + mark,
                callback_data=f"sec:font:{key}:{chat_id}"))
        b.row(*row_btns)

    last_key, last_fa, last_en = SECRETARY_FONTS[-1]
    last_mark = " ✅" if cur == last_key else ""
    b.row(
        InlineKeyboardButton(text=_t(last_fa, last_en, fa) + last_mark, callback_data=f"sec:font:{last_key}:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('خاموش','Off',fa)}{' ✅' if cur is None else ''}", callback_data=f"sec:off:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

# ── جدید: زیرصفحه‌ی عمومیِ فعال/خاموش (سپر امنیتی / انتی‌حذف / استوری‌دانلودر) ──
async def simple_toggle_menu(chat_id: int, state_key: str) -> InlineKeyboardMarkup:
    """یک دکمه‌ی تک که بین «فعال ✔️» و «خاموش ✖️» عوض می‌شه. برای هر ۳ فیچری که
    قبلاً فلیپ مستقیم روی گرید اصلی بودن و حالا دوباره زیرصفحه‌ی جدا دارن."""
    fa      = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    g       = await get_global_state()
    enabled = g.get(state_key, False)
    label   = _t("فعال","Active",fa) if enabled else _t("خاموش","Off",fa)
    mark    = "✔️" if enabled else "✖️"
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=f"{label} {mark}", callback_data=f"stog:{state_key}:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

async def group_lock_menu(chat_id: int) -> InlineKeyboardMarkup:
    """زیرمنوی «گروه» - همه‌ی قابلیت‌های مخصوصِ گروه اینجان (نه توی محدودیت‌ها،
    که مالِ قفلِ نوعِ مدیاست)."""
    s  = await get_chat_state(chat_id)
    fa = s.get("lang", "fa") == "fa"
    g  = s.get("group_lock", {})

    def mark(key):
        return _af_mark(g.get(key, False))

    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=f"{_t('قفل گروه','Lock Group',fa)} {mark('close_group_enabled')}", callback_data=f"gl:close_group_enabled:{chat_id}"),
        InlineKeyboardButton(text=_t("💢 اسپم","💢 Spam",fa), callback_data=f"menu:spam:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=_t("👥 اد اجباری","👥 Forced Add",fa), callback_data=f"gl:forcedadd_prompt:{chat_id}"),
        InlineKeyboardButton(text=_t("👋 خوش‌آمد و ترک","👋 Welcome/Leave",fa), callback_data=f"menu:welcome:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=_t("📊 آمار گروه","📊 Group Stats",fa), callback_data=f"menu:groupstats:{chat_id}"),
        InlineKeyboardButton(text=_t("〽️ لیست","〽️ List",fa), callback_data=f"menu:grouplist:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:main:{chat_id}"))
    return b.as_markup()

# ── جدید: اسپم (تکرار + اختیارات بن) ───────────────────
async def spam_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=_t("🔁 اسپم تکراری","🔁 Repeat Spam",fa), callback_data=f"menu:spamrepeat:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("⚔️ اختیارات بن","⚔️ Ban Options",fa), callback_data=f"menu:banoptions:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:grouplock:{chat_id}"))
    return b.as_markup()

async def spam_repeat_menu(chat_id: int) -> InlineKeyboardMarkup:
    s   = await get_chat_state(chat_id)
    fa  = s.get("lang", "fa") == "fa"
    g   = s.get("group_lock", {})
    active = g.get("antiflood_enabled", False)
    threshold = g.get("ban_thresholds", {}).get("spam", 0)

    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=f"{_t('فعال اسپم','Activate Spam',fa)} {_af_mark(active)}", callback_data=f"gl:antiflood_enabled:{chat_id}"))
    ban_label = _t("بن اسپم","Ban Spam",fa) + (f" ({threshold})" if threshold else "")
    b.row(InlineKeyboardButton(text=ban_label, callback_data=f"menu:banpickspam:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:spam:{chat_id}"))
    return b.as_markup()

# ── جدید: انتخابگرِ آستانه‌ی بن (۱ تا ۱۰، مشترک برای اسپم و هر نوع مدیا) ──
async def ban_threshold_picker_menu(chat_id: int, target: str) -> InlineKeyboardMarkup:
    s       = await get_chat_state(chat_id)
    fa      = s.get("lang", "fa") == "fa"
    pending = s.get("pending_ban_pick", {})
    selected = pending.get("number") if pending.get("target") == target else None

    nums = list(range(1, 11))
    rows = [nums[0:4], nums[4:8], nums[8:10]]
    b = InlineKeyboardBuilder()
    for row in rows:
        btns = []
        for n in row:
            label = f"{n} ✅" if selected == n else str(n)
            btns.append(InlineKeyboardButton(text=label, callback_data=f"bnpick:{target}:{n}:{chat_id}"))
        b.row(*btns)
    b.row(
        InlineKeyboardButton(text=_t("✅ تایید","✅ Confirm",fa), callback_data=f"bnconfirm:{target}:{chat_id}"),
        InlineKeyboardButton(text=_t("❌ لغو","❌ Cancel",fa), callback_data=f"bncancel:{target}:{chat_id}"),
    )
    back_to = "menu:spamrepeat" if target == "spam" else "menu:banoptions"
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"{back_to}:{chat_id}"))
    return b.as_markup()

# کلیدها دقیقاً هم‌نام با media_flags توی محدودیت‌ها، برای هماهنگی
_BAN_OPTION_TYPES = [
    ("gif","گیف","GIF"), ("sticker","استیکر","Sticker"), ("emoji","ایموجی","Emoji"),
    ("voice","ویس","Voice"), ("video","ویدیو","Video"), ("photo","عکس","Photo"),
    ("videonote","ویدیو مسیج","Video Note"), ("message","پیام","Message"),
    ("file","فایل","File"), ("music","موسیقی","Music"), ("poll","نظرسنجی","Poll"),
    ("games","بازی‌ها","Games"), ("inline","اینلاین","Inline"), ("hashtag","هشتگ","Hashtag"),
    ("mention","منشن","Mention"), ("spoiler","اسپویلر","Spoiler"),
    ("longmsg","پیام‌های طولانی","Long Msg"), ("link","لینک","Link"),
    ("forward","فوروارد","Forward"), ("bots","ربات‌ها","Bots"),
]

async def ban_options_menu(chat_id: int) -> InlineKeyboardMarkup:
    """همون لیستِ ۲۰تاییِ محدودیت‌ها، ولی این‌بار هرکدوم به‌جای تاگل، انتخابگرِ
    آستانه‌ی بن (۱ تا ۱۰) رو باز می‌کنه."""
    s   = await get_chat_state(chat_id)
    fa  = s.get("lang", "fa") == "fa"
    mbt = s.get("media_ban_thresholds", {})

    b = InlineKeyboardBuilder()
    for i in range(0, len(_BAN_OPTION_TYPES), 2):
        row_btns = []
        for key, fa_l, en_l in _BAN_OPTION_TYPES[i:i + 2]:
            th = mbt.get(key, 0)
            label = _t(fa_l, en_l, fa) + (f" ({th})" if th else "")
            row_btns.append(InlineKeyboardButton(text=label, callback_data=f"menu:banpick_{key}:{chat_id}"))
        b.row(*row_btns)
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:spam:{chat_id}"))
    return b.as_markup()


async def welcome_menu(chat_id: int) -> InlineKeyboardMarkup:
    s  = await get_chat_state(chat_id)
    fa = s.get("lang", "fa") == "fa"
    g  = s.get("group_lock", {})
    w_mode = g.get("welcome_mode", "off")
    l_mode = g.get("leave_mode", "off")

    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=f"{_t('خوش‌آمدگویی','Welcome',fa)} {_af_mark(w_mode == 'auto')}", callback_data=f"gl:welcome_auto:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('پیام خوش‌آمدگویی','Welcome Msg',fa)} {_af_mark(w_mode == 'custom')}", callback_data=f"gl:welcome_custom:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("📋 لیست پیام‌های خوش‌آمدگویی","📋 Welcome Message List",fa), callback_data=f"menu:welcomelist:{chat_id}"))
    b.row(
        InlineKeyboardButton(text=f"{_t('ترک گروه','Leave',fa)} {_af_mark(l_mode == 'auto')}", callback_data=f"gl:leave_auto:{chat_id}"),
        InlineKeyboardButton(text=f"{_t('پیام ترک گروه','Leave Msg',fa)} {_af_mark(l_mode == 'custom')}", callback_data=f"gl:leave_custom:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("📋 لیست پیام‌های ترک گروه","📋 Leave Message List",fa), callback_data=f"menu:leavelist:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:grouplock:{chat_id}"))
    return b.as_markup()

async def _welcome_list_text(chat_id: int, kind: str, fa: bool) -> str:
    g    = (await get_chat_state(chat_id)).get("group_lock", {})
    msgs = g.get(f"{kind}_messages", [])
    if not msgs:
        return _t("هیچ پیامی ذخیره نشده", "No messages saved yet", fa)
    return "\n\n".join(f"{i+1}. {m}" for i, m in enumerate(msgs))

async def welcome_list_menu(chat_id: int, kind: str) -> InlineKeyboardMarkup:
    """kind: 'welcome' یا 'leave' - هردو لیست دقیقاً یک ساختار دارن.
    ✅ به‌جای «حذف همه»، هر پیام دکمه‌ی حذفِ مخصوصِ خودش رو داره."""
    s     = await get_chat_state(chat_id)
    fa    = s.get("lang", "fa") == "fa"
    g     = s.get("group_lock", {})
    msgs  = g.get(f"{kind}_messages", [])
    random_on = g.get(f"{kind}_random", False)

    b = InlineKeyboardBuilder()
    for i, msg_text in enumerate(msgs):
        preview = msg_text if len(msg_text) <= 28 else msg_text[:25] + "..."
        b.row(InlineKeyboardButton(text=f"🗑 {preview}", callback_data=f"gl:{kind}_del:{i}:{chat_id}"))
    b.row(InlineKeyboardButton(text=f"{_t('🎲 رندوم','🎲 Random',fa)} {_af_mark(random_on)}", callback_data=f"gl:{kind}_random:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:welcome:{chat_id}"))
    return b.as_markup()

# ── جدید: آمار گروه - پیام/عکس/ویدیو/ویس/ویدیو مسیج، مخصوصِ همین گروهی که
# پنل توش بازه (جدا از منوی «آمار»ِ کلی که حساب-محورِ همیشگیه) ──
_GROUP_STAT_TYPES = [
    ("photo",     "عکس",         "Photo"),
    ("video",     "ویدیو",       "Video"),
    ("voice",     "ویس",         "Voice"),
    ("videonote", "ویدیو مسیج",  "Video Note"),
    ("message",   "پیام",        "Message"),
]

async def _group_stats_text(chat_id: int, fa: bool) -> str:
    gs    = (await group_stats_state.load()).get(str(chat_id), {})
    total = sum(e.get("count", 0) for e in gs.get("message", {}).values())
    return _t(f"💬 مجموع پیام‌های این گروه: {total}", f"💬 Total messages in this group: {total}", fa)

async def group_stats_menu(chat_id: int) -> InlineKeyboardMarkup:
    fa = (await get_chat_state(chat_id)).get("lang", "fa") == "fa"
    b  = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text=_t("📷 آمار عکس","📷 Photo Stats",fa),      callback_data=f"gst:photo:{chat_id}"),
        InlineKeyboardButton(text=_t("🎥 آمار ویدیو","🎥 Video Stats",fa),     callback_data=f"gst:video:{chat_id}"),
    )
    b.row(
        InlineKeyboardButton(text=_t("🎙 آمار ویس","🎙 Voice Stats",fa),      callback_data=f"gst:voice:{chat_id}"),
        InlineKeyboardButton(text=_t("⭕️ آمار ویدیو مسیج","⭕️ Video Note Stats",fa), callback_data=f"gst:videonote:{chat_id}"),
    )
    b.row(InlineKeyboardButton(text=_t("💬 پیام","💬 Message",fa), callback_data=f"gst:message:{chat_id}"))
    b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:grouplock:{chat_id}"))
    return b.as_markup()

async def group_stats_list_text(chat_id: int, msg_type: str, fa: bool) -> str:
    gs    = (await group_stats_state.load()).get(str(chat_id), {})
    users = gs.get(msg_type, {})
    items = sorted(users.items(), key=lambda x: x[1].get("count", 0), reverse=True)
    if not items:
        return _t("هیچ موردی ثبت نشده", "Nothing logged yet", fa)
    lines = []
    for uid, info in items[:30]:
        uname = info.get("username")
        name  = info.get("name") or uid
        label = f"@{uname}" if uname else name
        lines.append(f"\u200e{label} = {info.get('count', 0)}")
    return "\n".join(lines)



bot = Bot(token=BOT_TOKEN)
dp  = Dispatcher()

@dp.errors()
async def global_error_handler(event):
    """✅ جدید: هر خطای مدیریت‌نشده‌ای توی هر هندلری (ازجمله دکمه‌های پنل)
    این‌جا چاپ می‌شه - قبلاً اگه چیزی توی وسطِ callback_handler exception
    می‌داد، ممکن بود بی‌صدا از دست بره."""
    print(f"[panel_bot ERROR] {event.exception!r}")
    return True

async def is_allowed(user_id: int) -> bool:
    """✅ جدید: مالک + هرکسی که توی لیست allowed_users باشه"""
    if OWNER_ID == 0 or user_id == OWNER_ID:
        return True
    g = await get_global_state()
    return user_id in g.get("allowed_users", [])

async def allowed_only(cb: types.CallbackQuery) -> bool:
    if await is_allowed(cb.from_user.id):
        return True
    await cb.answer("⛔ شما اجازه‌ی استفاده از این پنل را ندارید.", show_alert=True)
    return False

# ===================== INLINE QUERY =====================

@dp.inline_query()
async def inline_handler(query: InlineQuery):
    if not await is_allowed(query.from_user.id):
        return
    _current_owner.set(query.from_user.id)   # ✅ لنگرِ هویت: از سرورِ تلگرام میاد، جعل‌ناپذیره

    q = query.query.strip()

    # ── دیوار عضویت اجباری: userbot نمی‌تونه دکمه شیشه‌ای بفرسته، پس از بات کمک می‌گیریم ──
    if q.startswith("fjwall:"):
        wall_id = q[len("fjwall:"):]
        g = await get_global_state()
        wall_data = g.get("forced_join_wall_data", {}).get(wall_id)
        if not wall_data:
            return  # داده پیدا نشد یا منقضی شده

        text     = wall_data.get("text", "")
        channels = wall_data.get("channels", [])

        b = InlineKeyboardBuilder()
        for ch in channels:
            b.row(InlineKeyboardButton(text=f"📢 {ch.get('title','')}", url=ch.get("link","")))
        markup = b.as_markup()

        await query.answer([
            InlineQueryResultArticle(
                id=f"fjwall:{wall_id}",
                title="🔒 Forced Join Wall",
                description=text[:60],
                input_message_content=InputTextMessageContent(message_text=text),
                reply_markup=markup
            )
        ], cache_time=0, is_personal=True)
        return

    # ── پنل عادی ──
    try:
        chat_id = int(q)
    except ValueError:
        return
    s        = await get_chat_state(chat_id)
    fa       = s.get("lang", "fa") == "fa"
    cur_page = s.get("current_page", 1)
    markup   = await page_menu(chat_id, cur_page)
    caption  = PANEL_TITLE_FA if fa else PANEL_TITLE_EN

    # ✅ جدید: اگه عکس پنل کش شده باشه (panel_assets/panel.jpg|png)، با عکس می‌فرستیم -
    # دقیقاً همون چیزی که توی /start می‌بینی، الان توی همین دکمه‌ی «پنل» (اینلاین) هم می‌آد
    file_id = await _ensure_panel_image_cached()
    if file_id:
        await query.answer([
            InlineQueryResultCachedPhoto(
                id=f"panel:{chat_id}",
                photo_file_id=file_id,
                caption=caption,
                parse_mode="HTML",
                reply_markup=_stamp_owner(markup, query.from_user.id),
            )
        ], cache_time=0, is_personal=True)
        return

    await query.answer([
        InlineQueryResultArticle(
            id=f"panel:{chat_id}",
            title=caption.replace("<i>", "").replace("</i>", ""),
            description=f"مدیریت ابزارها برای چت {chat_id}",
            input_message_content=InputTextMessageContent(
                message_text=caption,
                parse_mode="HTML"),
            reply_markup=_stamp_owner(markup, query.from_user.id)
        )
    ], cache_time=0, is_personal=True)

# ===================== /start & /panel =====================

@dp.message(Command("start"))
@dp.message(Command("panel"))
async def send_panel_cmd(msg: Message):
    if not await is_allowed(msg.from_user.id):
        return
    _current_owner.set(msg.from_user.id)   # ✅ لنگرِ هویت: پیامِ مستقیم به بات، از from_user.id
    chat_id = msg.chat.id
    if msg.text and len(msg.text.split()) > 1:
        try:
            chat_id = int(msg.text.split()[1])
        except ValueError:
            pass
    cur_page = (await get_chat_state(chat_id)).get("current_page", 1)
    await send_panel_message(msg.chat.id, chat_id, cur_page)

# ===================== EDIT HELPERS =====================

async def edit_panel(cb: types.CallbackQuery, text: str, markup: InlineKeyboardMarkup, parse_mode: str = None):
    markup = _stamp_owner(markup, _current_owner.get())
    try:
        if cb.message:
            if cb.message.photo:
                await cb.message.edit_caption(caption=text, reply_markup=markup, parse_mode=parse_mode)
            else:
                await cb.message.edit_text(text, reply_markup=markup, parse_mode=parse_mode)
        else:
            await bot.edit_message_text(text=text, inline_message_id=cb.inline_message_id, reply_markup=markup, parse_mode=parse_mode)
    except Exception as e:
        if "message is not modified" not in str(e).lower():
            print(f"[edit_panel] {e}")

async def close_panel(cb: types.CallbackQuery, lang: str):
    fa  = lang == "fa"
    txt = _t("✅ پنل بسته شد", "✅ Panel closed", fa)
    try:
        if cb.message:
            await cb.message.edit_text(txt, reply_markup=None)
        else:
            await bot.edit_message_text(text=txt, inline_message_id=cb.inline_message_id, reply_markup=None)
    except Exception as e:
        if "message is not modified" not in str(e).lower():
            print(f"[close_panel] {e}")
    await cb.answer(txt)

# ===================== CALLBACKS =====================

@dp.callback_query()
async def callback_handler(cb: types.CallbackQuery):
    if not await allowed_only(cb):
        return

    # ✅ ایزوله‌سازی چند-اکانتی: هر دکمه موقعِ ساخته‌شدن با آیدیِ صاحبِ واقعیش
    # مهر خورده («owner|داده‌ی‌قبلی»). اگه کسی غیر از همون صاحب کلیک کنه -
    # مثلاً طرفِ مقابل توی یه چتِ خصوصیِ مشترک - همین‌جا رد می‌شه و هیچ
    # اکشنی اجرا نمی‌شه، صرف‌نظر از این‌که allowed_only بالا رد شده باشه یا نه.
    raw = cb.data or ""
    if "|" not in raw:
        return
    owner_str, real_data = raw.split("|", 1)
    try:
        owner_id = int(owner_str)
    except ValueError:
        return
    if cb.from_user.id != owner_id:
        await cb.answer("⛔ این پنل مال شما نیست.", show_alert=True)
        return
    _current_owner.set(owner_id)

    parts  = real_data.split(":")
    action = parts[0]
    sub    = parts[1] if len(parts) > 1 else ""

    try:
        chat_id = int(parts[-1])
    except (ValueError, IndexError):
        chat_id = cb.message.chat.id if cb.message else 0
    s    = await get_chat_state(chat_id)
    lang = s.get("lang", "fa")
    fa   = lang == "fa"
    pt   = PANEL_TITLE_FA if fa else PANEL_TITLE_EN

    # ── CLOSE ──────────────────────────────────────────────
    if action == "menu" and sub == "close":
        await close_panel(cb, lang)
        return

    # ── PLACEHOLDER (قابلیت‌هایی که هنوز ساخته نشدن - باز می‌شه، آلارم نمی‌زنه) ──
    if action == "placeholder":
        try:
            origin_page = int(parts[2]) if len(parts) >= 4 else (await get_chat_state(chat_id)).get("current_page", 1)
        except ValueError:
            origin_page = 1

        ph_descriptions = {
            "loveenemy":   ("💘 لیستِ «عشق‌ها» و «دشمن‌ها» - افرادی که تگ می‌کنی و ربات رفتار خاصی (مثل واکنش یا اعلان ویژه) نسبت به پیام‌هاشون داره.",
                             "💘 A tagged list of 'favorites' and 'enemies' - people you flag for special reactions/alerts."),
            "info":        ("ℹ️ اطلاعاتِ کلیِ ربات: نسخه، مدتِ روشن بودن، خلاصه‌ی وضعیتِ ماژول‌ها.",
                             "ℹ️ General bot info: version, uptime, module status summary."),
            "download":    ("📥 دانلودِ عمومی - یه لینک بفرستی، فایلش رو برات می‌گیره (جدا از دانلودرِ فیلم/ویس که مخصوصِ خودشونن).",
                             "📥 General downloader - send a link, get the file (separate from the movie/voice downloaders)."),
            "qr":          ("🔳 ساختنِ کیوآرکد از یه متن یا لینک که بفرستی.",
                             "🔳 Generate a QR code from any text or link you send."),
            "ping":        ("🏓 سرعتِ پاسخ‌دهیِ ربات رو به میلی‌ثانیه نشون می‌ده.",
                             "🏓 Shows the bot's response latency in milliseconds."),
            "translate":   ("🌐 ترجمه‌ی متن بین زبان‌ها - متنی بفرستی/ریپلای کنی، ترجمه‌ش رو می‌گیری.",
                             "🌐 Translate text between languages - send or reply with text to get a translation."),
            "gpt":         ("🤖 یه دستیارِ هوش مصنوعی داخلِ چت - سوال بپرسی، جواب می‌گیری.",
                             "🤖 An AI assistant inside chat - ask a question, get an answer."),
            "market":      ("💰 قیمتِ لحظه‌ای ارز، طلا، و بیش از ۲۰۰ رمزارز (دلار/طلای ایران از TGJU، کریپتو از CoinGecko).",
                             "💰 Live prices for currencies, gold, and 200+ cryptocurrencies."),
            "spam2":       ("📨 ارسالِ پیامِ زیاد به یه هدفِ مشخص (جدا از ضدِ اسپمِ گروه که چیزِ دیگه‌ایه).",
                             "📨 Sends a burst of messages to a target (different from the group anti-spam feature)."),
            "massban":     ("🔨 بن‌کردنِ دسته‌جمعیِ چند کاربر با هم توی یه گروه.",
                             "🔨 Ban multiple users at once in a group."),
            "animation":   ("🎬 فرستادنِ افکت‌های متحرک/انیمیشنی توی چت.",
                             "🎬 Send animated text/visual effects in chat."),
            "song":        ("🎵 تشخیصِ آهنگ - یه ویسِ کوتاه از یه آهنگ بفرستی، اسمش رو پیدا می‌کنه.",
                             "🎵 Song recognition - send a short clip, get the song's name."),
            "movie":       ("🎥 دانلودِ فیلم با فرستادنِ اسم یا لینکش.",
                             "🎥 Download a movie by sending its name or a link."),
            "voicedl":     ("🎙 دانلودِ فایلِ صوتی/ویس با فرستادنِ لینکش.",
                             "🎙 Download a voice/audio file from a link."),
            "dot":         ("❔ این یکی هنوز مشخص نکرده بودیم دقیقاً چیکار کنه - بگو دقیق چی می‌خوای تا بسازمش.",
                             "❔ Purpose not specified yet - let me know exactly what this should do."),
            "snooper":     ("🕵️ رصدِ تغییراتِ پروفایل (اسم/بیو/یوزرنیم) یه کاربر، جدا از چکرِ عکسِ پروفایل که چیزِ دیگه‌ایه.",
                             "🕵️ Tracks a user's profile changes (name/bio/username), separate from the photo checker."),
            "mediaconvert": ("🔄 تبدیلِ فایل‌های مدیا: ویدیو به ویدیومسیج، فایلِ صوتی به ویس، بریدن بخشی از ویدیو/صدا.",
                             "🔄 Media conversion: video to round video-note, audio to voice message, trimming clips."),
            "cheat":       ("🎮 ترفندها/کدهای تقلبِ بازی‌ها.",
                             "🎮 Game cheats/tricks."),
        }
        fa_txt, en_txt = ph_descriptions.get(sub, ("✍️ این قابلیت هنوز ساخته نشده - بگو دقیق چی می‌خوای تا بسازمش.",
                                                     "✍️ Not built yet - tell me exactly what you want and I'll build it."))
        ph_text = _t(fa_txt, en_txt, fa)
        ph_b = InlineKeyboardBuilder()
        ph_b.row(InlineKeyboardButton(text=_t("بازگشت","Back",fa), callback_data=f"page:{origin_page}:{chat_id}"))
        await edit_panel(cb, ph_text, ph_b.as_markup())
        await cb.answer()
        return

    # ── PAGINATION (صفحه‌های پنل اصلی) ──────────────────────
    if action == "page":
        try:
            target_page = int(sub)
        except ValueError:
            target_page = 1
        await edit_panel(cb, pt, await page_menu(chat_id, target_page), parse_mode="HTML")

    # ── MENU NAVIGATION ────────────────────────────────────
    if action == "menu":
        if sub == "main":
            cur_page = (await get_chat_state(chat_id)).get("current_page", 1)
            await edit_panel(cb, pt, await page_menu(chat_id, cur_page), parse_mode="HTML")

        elif sub == "stats":
            await check_and_reset_stats()
            await edit_panel(cb, _t("کدوم یکی؟","Which one?",fa), await stats_main_menu(chat_id))

        elif sub == "antifuck":
            await edit_panel(cb, _t("⚙️ منوی محدودیت‌ها","⚙️ Restrictions Menu",fa), await antifuck_menu(chat_id))

        elif sub == "curse":
            await edit_panel(cb, _t("⏳ ذخیره خودتخریب","⏳ Self-Destruct Menu",fa), await curse_menu(chat_id))

        elif sub == "profile":
            await edit_panel(cb, _t("👤 تنظیمات پروفایل","👤 Profile Settings",fa), await profile_menu(chat_id))

        elif sub == "online":
            await edit_panel(cb, _t("🟢 منوی آنلاین","🟢 Online Menu",fa), await online_menu(chat_id))

        elif sub == "autoreply":
            await edit_panel(cb, _t("💬 پاسخ خودکار","💬 Auto Reply",fa), await autoreply_menu(chat_id))

        elif sub == "bio":
            await edit_panel(cb, _t("⏰ ساعت بیو","⏰ Bio Clock",fa), await bio_clock_menu(chat_id))

        elif sub == "forced_join":
            await edit_panel(cb, _t("🔒 عضویت اجباری","🔒 Forced Join",fa), await forced_join_menu(chat_id))

        elif sub == "channel_ads":
            await edit_panel(cb, _t("📣 تبلیغات چنل","📣 Channel Ads",fa), await channel_ads_menu(chat_id))

        elif sub == "banned_words":
            txt, markup = await banned_words_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "mass_message":
            await edit_panel(cb, _t("📢 پیام همگانی","📢 Mass Message",fa), await mass_message_menu(chat_id))

        elif sub == "mm_audience":
            await edit_panel(cb, _t("👥 برای چه کسانی ارسال شود؟","👥 Send To Whom?",fa), await mass_message_audience_menu(chat_id))

        elif sub == "mm_list":
            txt, markup = await mass_message_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "tm_list":
            txt, markup = await timed_message_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "ghost_mode":
            await edit_panel(cb, _t("👻 حالت روح","👻 Ghost Mode",fa), await ghost_mode_menu(chat_id))

        elif sub == "supertrack":
            await edit_panel(cb, _t("🛰 سوپر ترک","🛰 Super Track",fa), await supertrack_menu(chat_id))

        elif sub == "rotating_name":
            await edit_panel(cb, _t("🔤 اسم چرخشی","🔤 Rotating Name",fa), await rotating_name_menu(chat_id))

        elif sub == "archive":
            await edit_panel(cb, _t("🗄 بایگانی","🗄 Archive",fa), await archive_menu(chat_id))

        elif sub == "secretary":
            await edit_panel(cb, _t("🪄 منشی","🪄 Secretary",fa), await secretary_menu(chat_id))

        elif sub == "grouplock":
            await edit_panel(cb, _t("🔐 گروه","🔐 Group",fa), await group_lock_menu(chat_id))

        elif sub == "spam":
            await edit_panel(cb, _t("💢 اسپم","💢 Spam",fa), await spam_menu(chat_id))

        elif sub == "spamrepeat":
            await edit_panel(cb, _t("🔁 اسپم تکراری","🔁 Repeat Spam",fa), await spam_repeat_menu(chat_id))

        elif sub == "banoptions":
            await edit_panel(cb, _t("⚔️ اختیارات بن","⚔️ Ban Options",fa), await ban_options_menu(chat_id))

        elif sub == "banpickspam":
            await edit_panel(cb, _t("🎯 آستانه‌ی بن اسپم","🎯 Spam Ban Threshold",fa), await ban_threshold_picker_menu(chat_id, "spam"))

        elif sub.startswith("banpick_"):
            target = sub[len("banpick_"):]
            label_map = {k: (fa_l, en_l) for k, fa_l, en_l in _BAN_OPTION_TYPES}
            fa_l, en_l = label_map.get(target, (target, target))
            await edit_panel(cb, _t(f"🎯 آستانه‌ی بن {fa_l}", f"🎯 {en_l} Ban Threshold", fa), await ban_threshold_picker_menu(chat_id, target))

        elif sub == "groupstats":
            await edit_panel(cb, await _group_stats_text(chat_id, fa), await group_stats_menu(chat_id))

        elif sub == "grouplist":
            cache = (await get_chat_state(chat_id)).get("group_list_cache", {})
            txt   = cache.get("fa" if fa else "en") or _t(
                "هنوز آماده نشده، چند ثانیه دیگه دوباره امتحان کن.",
                "Not ready yet, try again in a few seconds.", fa)
            back_kb = InlineKeyboardBuilder()
            back_kb.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:grouplock:{chat_id}"))
            await edit_panel(cb, txt, back_kb.as_markup())

        elif sub == "welcome":
            await edit_panel(cb, _t("👋 خوش‌آمد و ترک گروه","👋 Welcome & Leave",fa), await welcome_menu(chat_id))

        elif sub == "welcomelist":
            await edit_panel(cb, await _welcome_list_text(chat_id, "welcome", fa), await welcome_list_menu(chat_id, "welcome"))

        elif sub == "leavelist":
            await edit_panel(cb, await _welcome_list_text(chat_id, "leave", fa), await welcome_list_menu(chat_id, "leave"))

        elif sub in ("shield", "antidelete", "storydl"):
            state_key = {"shield": "shield_enabled", "antidelete": "anti_delete_enabled", "storydl": "story_auto_download"}[sub]
            fa_label, en_label = _TOGGLE_LABELS.get(state_key, (state_key, state_key))
            await edit_panel(cb, _t(fa_label, en_label, fa), await simple_toggle_menu(chat_id, state_key))

    # ── STATS PERIOD ───────────────────────────────────────
    elif action == "stats":
        await check_and_reset_stats()
        st = (await load_state()).get("_stats", {})
        if sub == "back":
            await edit_panel(cb, _t("کدوم یکی؟","Which one?",fa), await stats_main_menu(chat_id))
        elif sub in ("daily", "weekly"):
            txt, markup = await stats_period_menu(chat_id, sub, st)
            await edit_panel(cb, txt, markup)

    # ── STATS LIST ─────────────────────────────────────────
    elif action == "sl":
        if len(parts) < 4:
            await cb.answer()
            return
        await check_and_reset_stats()
        st     = (await load_state()).get("_stats", {})
        period = parts[2]
        label  = _t("امروز","Today",fa) if period == "daily" else _t("این هفته","This Week",fa)
        KEYS     = {"del":"deleted_users","vo":"viewonce_users","prof":"profile_users","chat":"chat_users"}
        TITLE_FA = {"del":f"🗑️ پیام های حذف شده {label}","vo":f"⏳ خود تخریب های {label}","prof":f"📸 پروفایل های {label}","chat":f"💬 چت های {label}"}
        TITLE_EN = {"del":f"🗑️ Deleted Messages {label}","vo":f"⏳ ViewOnce {label}","prof":f"📸 Profile Photos {label}","chat":f"💬 Chats {label}"}
        SUFFIXES = {"del":("پیام حذف شد","deleted"),"vo":("😍🐺","😍🐺"),"prof":(f"زیبایی های {label} 🐺",f"beauties {label} 🐺"),"chat":("پیام","messages")}
        if sub not in KEYS:
            await cb.answer()
            return
        s_fa, s_en = SUFFIXES[sub]
        body  = _build_user_list(st.get(KEYS[sub],{}), period, s_fa, s_en, fa)
        title = TITLE_FA[sub] if fa else TITLE_EN[sub]
        b = InlineKeyboardBuilder()
        b.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"stats:{period}:{chat_id}"))
        await edit_panel(cb, f"{title}:\n\n{body}", b.as_markup())

    # ── LANGUAGE ───────────────────────────────────────────
    elif action == "lang":
        if sub in ("fa", "en"):
            s["lang"] = sub
            await set_chat_state(chat_id, s)
        new_fa   = sub == "fa"
        cur_page = s.get("current_page", 1)
        await edit_panel(cb, PANEL_TITLE_FA if new_fa else PANEL_TITLE_EN, await page_menu(chat_id, cur_page), parse_mode="HTML")

    # ✅ سپر امنیتی/انتی‌حذف/استوری‌دانلودر دیگه فلیپ مستقیم روی گرید نیستن؛ از طریق
    # «menu» بالا وارد simple_toggle_menu می‌شن و این اکشن همون دکمه‌ی تکِ فعال/خاموشِ
    # داخلِ اون زیرصفحه رو toggle می‌کنه.
    elif action == "stog":
        if sub in _TOGGLE_LABELS:
            g = await get_global_state()
            g[sub] = not g.get(sub, False)
            await set_global_state(g)
        fa_label, en_label = _TOGGLE_LABELS.get(sub, (sub, sub))
        await edit_panel(cb, _t(fa_label, en_label, fa), await simple_toggle_menu(chat_id, sub))

    # ── منشی (فونت‌ساز پیام) - انتخاب فونت یا خاموش کردن ────
    elif action == "sec":
        g = await get_global_state()
        if sub == "font" and len(parts) >= 4:
            chosen     = parts[2]
            valid_keys = {k for k, _, _ in SECRETARY_FONTS}
            if chosen in valid_keys:
                current = g.get("secretary_font")
                g["secretary_font"] = None if chosen == current else chosen
                await set_global_state(g)
            await edit_panel(cb, _t("🪄 منشی","🪄 Secretary",fa), await secretary_menu(chat_id))
        elif sub == "off":
            g["secretary_font"] = None
            await set_global_state(g)
            await edit_panel(cb, _t("🪄 منشی","🪄 Secretary",fa), await secretary_menu(chat_id))

    # ── قفل گروه (ضد اسپم/مدیریت اعضا) - همه‌جا فقط توی گروه/کانال معنی داره ──
    elif action == "gl":
        if chat_id < 0 and not s.get("group_admin", False):
            await cb.answer(_t(
                "🚫 برای تنظیمِ قفل گروه باید توی این گروه ادمین یا مالک باشی.",
                "🚫 You must be an admin or owner of this group.", fa
            ), show_alert=True)
            await edit_panel(cb, _t("🔐 گروه","🔐 Group",fa), await group_lock_menu(chat_id))
            return

        simple_toggle_keys = {"close_group_enabled", "antiflood_enabled"}

        if sub in simple_toggle_keys:
            gl = s.get("group_lock", {})
            gl[sub] = not gl.get(sub, False)
            s["group_lock"] = gl
            await set_chat_state(chat_id, s)
            if sub == "antiflood_enabled":
                await edit_panel(cb, _t("🔁 اسپم تکراری","🔁 Repeat Spam",fa), await spam_repeat_menu(chat_id))
            else:
                await edit_panel(cb, _t("🔐 گروه","🔐 Group",fa), await group_lock_menu(chat_id))

        elif sub == "forcedadd_prompt":
            g = await get_global_state()
            g["forced_add_request"] = {"chat_id": chat_id}
            await set_global_state(g)
            await cb.answer(_t("📝 یه پیام توی همین چت می‌فرستم، روش ریپلای کن و لینک‌ها رو بفرست.",
                                "📝 I'll send a message in this chat, reply to it with the links.", fa), show_alert=True)
            await edit_panel(cb, _t("🔐 گروه","🔐 Group",fa), await group_lock_menu(chat_id))

        elif sub in ("welcome_auto", "leave_auto"):
            key = "welcome_mode" if sub == "welcome_auto" else "leave_mode"
            gl  = s.get("group_lock", {})
            gl[key] = "off" if gl.get(key) == "auto" else "auto"
            s["group_lock"] = gl
            await set_chat_state(chat_id, s)
            await edit_panel(cb, _t("👋 خوش‌آمد و ترک گروه","👋 Welcome & Leave",fa), await welcome_menu(chat_id))

        elif sub in ("welcome_custom", "leave_custom"):
            purpose = "welcome" if sub == "welcome_custom" else "leave"
            g = await get_global_state()
            g["welcome_leave_request"] = {"chat_id": chat_id, "purpose": purpose}
            await set_global_state(g)
            await cb.answer(_t("📝 یه پیام توی همین چت می‌فرستم، روش ریپلای کن و متن رو بفرست.",
                                "📝 I'll send a message in this chat, reply to it with the text.", fa), show_alert=True)
            await edit_panel(cb, _t("👋 خوش‌آمد و ترک گروه","👋 Welcome & Leave",fa), await welcome_menu(chat_id))

        elif sub in ("welcome_del", "leave_del"):
            kind = "welcome" if sub == "welcome_del" else "leave"
            try:
                idx = int(parts[2])
            except (IndexError, ValueError):
                idx = -1
            gl   = s.get("group_lock", {})
            msgs = gl.get(f"{kind}_messages", [])
            if 0 <= idx < len(msgs):
                msgs.pop(idx)
                gl[f"{kind}_messages"] = msgs
                if not msgs:
                    gl[f"{kind}_mode"] = "off"
                s["group_lock"] = gl
                await set_chat_state(chat_id, s)
            await edit_panel(cb, await _welcome_list_text(chat_id, kind, fa), await welcome_list_menu(chat_id, kind))

        elif sub in ("welcome_random", "leave_random"):
            kind = "welcome" if sub == "welcome_random" else "leave"
            gl = s.get("group_lock", {})
            gl[f"{kind}_random"] = not gl.get(f"{kind}_random", False)
            s["group_lock"] = gl
            await set_chat_state(chat_id, s)
            await edit_panel(cb, await _welcome_list_text(chat_id, kind, fa), await welcome_list_menu(chat_id, kind))

    # ── انتخابگرِ آستانه‌ی بن (مشترک بین اسپم و ۲۰ نوعِ مدیا) ──
    elif action == "bnpick":
        target = sub
        try:
            number = int(parts[2])
        except (IndexError, ValueError):
            number = None
        if number is not None:
            s["pending_ban_pick"] = {"target": target, "number": number}
            await set_chat_state(chat_id, s)
        await edit_panel(cb, _t("🎯 عددی رو انتخاب کن و تایید بزن","🎯 Pick a number and confirm",fa), await ban_threshold_picker_menu(chat_id, target))

    elif action == "bnconfirm":
        target  = sub
        pending = s.get("pending_ban_pick", {})
        if pending.get("target") == target and pending.get("number"):
            if target == "spam":
                gl = s.get("group_lock", {})
                gl.setdefault("ban_thresholds", {})["spam"] = pending["number"]
                s["group_lock"] = gl
            else:
                mbt = s.get("media_ban_thresholds", {})
                mbt[target] = pending["number"]
                s["media_ban_thresholds"] = mbt
        s.pop("pending_ban_pick", None)
        await set_chat_state(chat_id, s)
        if target == "spam":
            await edit_panel(cb, _t("🔁 اسپم تکراری","🔁 Repeat Spam",fa), await spam_repeat_menu(chat_id))
        else:
            await edit_panel(cb, _t("⚔️ اختیارات بن","⚔️ Ban Options",fa), await ban_options_menu(chat_id))

    elif action == "bncancel":
        target = sub
        s.pop("pending_ban_pick", None)
        if target == "spam":
            gl = s.get("group_lock", {})
            gl.setdefault("ban_thresholds", {})["spam"] = 0
            s["group_lock"] = gl
        else:
            mbt = s.get("media_ban_thresholds", {})
            mbt[target] = 0
            s["media_ban_thresholds"] = mbt
        await set_chat_state(chat_id, s)
        if target == "spam":
            await edit_panel(cb, _t("🔁 اسپم تکراری","🔁 Repeat Spam",fa), await spam_repeat_menu(chat_id))
        else:
            await edit_panel(cb, _t("⚔️ اختیارات بن","⚔️ Ban Options",fa), await ban_options_menu(chat_id))

    # ── آمار گروه (پیام/عکس/ویدیو/ویس/ویدیو مسیج) ─────────
    elif action == "gst":
        if sub in ("photo", "video", "voice", "videonote", "message"):
            back_kb = InlineKeyboardBuilder()
            back_kb.row(InlineKeyboardButton(text=_t("🔙 بازگشت","🔙 Back",fa), callback_data=f"menu:groupstats:{chat_id}"))
            label_map = {k: (fa_l, en_l) for k, fa_l, en_l in _GROUP_STAT_TYPES}
            fa_l, en_l = label_map.get(sub, (sub, sub))
            title = _t(f"📊 آمار {fa_l}", f"📊 {en_l} Stats", fa)
            body  = await group_stats_list_text(chat_id, sub, fa)
            await edit_panel(cb, f"{title}\n\n{body}", back_kb.as_markup())

    # ── MEDIA FLAGS ────────────────────────────────────────
    elif action == "af":
        flags = s.get("media_flags", {})
        valid_af_keys = {
            "gif","sticker","emoji","voice","video","photo","videonote","silence","message",
            "file","music","poll","games","inline","hashtag","mention","spoiler","longmsg","link","forward","bots",
        }
        if sub in valid_af_keys:
            # ✅ جدید: توی گروه/کانال فقط اگه ادمین یا مالک باشم اجازه‌ی قفل/باز دارم
            # (وضعیتش رو panel.py هر بار که «پنل» زده می‌شه توی همین چت کش می‌کنه)
            if chat_id < 0 and not s.get("group_admin", False):
                await cb.answer(_t(
                    "🚫 برای قفل/باز کردن محدودیت‌ها باید توی این گروه ادمین یا مالک باشی.",
                    "🚫 You must be an admin or owner of this group to lock/unlock restrictions.", fa
                ), show_alert=True)
            else:
                flags[sub] = not flags.get(sub, False)
                s["media_flags"] = flags
                await set_chat_state(chat_id, s)
        await edit_panel(cb, _t("⚙️ منوی محدودیت‌ها","⚙️ Restrictions Menu",fa), await antifuck_menu(chat_id))

    # ── CURSE ──────────────────────────────────────────────
    elif action == "curse":
        if sub == "block":
            s["viewonce_blocked"] = not s.get("viewonce_blocked", False)
            await set_chat_state(chat_id, s)
        elif sub == "all":
            g = await get_global_state()
            g["viewonce_all_off"] = not g.get("viewonce_all_off", False)
            await set_global_state(g)
        await edit_panel(cb, _t("⏳ ذخیره خودتخریب","⏳ Self-Destruct Menu",fa), await curse_menu(chat_id))

    # ── PROFILE MODE ───────────────────────────────────────
    elif action == "profmod":
        if sub in ("off","contacts","chats","all"):
            g = await get_global_state()
            g["profile_mode"] = sub
            await set_global_state(g)
        await edit_panel(cb, _t("👤 تنظیمات پروفایل","👤 Profile Settings",fa), await profile_menu(chat_id))

    # ── ONLINE ─────────────────────────────────────────────
    elif action == "online":
        g = await get_global_state()
        if sub == "toggle":
            g["online_mode_enabled"] = not g.get("online_mode_enabled", False)
            await set_global_state(g)
            await edit_panel(cb, _t("🟢 منوی آنلاین","🟢 Online Menu",fa), await online_menu(chat_id))
        elif sub == "set_text":
            all_state = await load_state()
            all_state.setdefault("_global", {})["online_text_request"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

    # ── AUTO REPLY (toggle) ──────────────────────────────────
    elif action == "autoreply":
        g = await get_global_state()
        if sub == "toggle":
            g["auto_reply_enabled"] = not g.get("auto_reply_enabled", False)
            await set_global_state(g)
            await edit_panel(cb, _t("💬 پاسخ خودکار","💬 Auto Reply",fa), await autoreply_menu(chat_id))

    # ── AUTO REPLY RULES ─────────────────────────────────────
    elif action == "arule":
        g     = await get_global_state()
        rules = g.get("auto_reply_rules", [])
        if sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["auto_reply_add"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return
        elif sub == "list":
            txt, markup = await autoreply_list_menu(chat_id)
            await edit_panel(cb, txt, markup)
        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx = int(parts[2])
                    if 0 <= idx < len(rules):
                        rules.pop(idx)
                        g["auto_reply_rules"] = rules
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await autoreply_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

    # ── BIO CLOCK ─────────────────────────────────────────
    elif action == "bio":
        g = await get_global_state()
        if sub == "toggle":
            g["bio_clock_enabled"] = not g.get("bio_clock_enabled", False)
            await set_global_state(g)
            await edit_panel(cb, _t("⏰ ساعت بیو","⏰ Bio Clock",fa), await bio_clock_menu(chat_id))
        elif sub == "city_input":
            all_state = await load_state()
            all_state.setdefault("_global", {})["bio_input"] = {"type": "city", "chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return
        elif sub == "text_input":
            all_state = await load_state()
            all_state.setdefault("_global", {})["bio_input"] = {"type": "text", "chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

    # ── FORCED JOIN ─────────────────────────────────────────
    elif action == "fj":
        g        = await get_global_state()
        channels = g.get("forced_join_channels", [])

        if sub == "toggle":
            g["forced_join_enabled"] = not g.get("forced_join_enabled", False)
            await set_global_state(g)
            await edit_panel(cb, _t("🔒 عضویت اجباری","🔒 Forced Join",fa), await forced_join_menu(chat_id))

        elif sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["forced_join_add"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

        elif sub == "list":
            txt, markup = await forced_join_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx = int(parts[2])
                    if 0 <= idx < len(channels):
                        channels.pop(idx)
                        g["forced_join_channels"] = channels
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await forced_join_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "audience":
            await edit_panel(cb, _t("👥 برای چه افرادی فعال باشد","👥 Audience",fa), await forced_join_audience_menu(chat_id))

    # ── FORCED JOIN AUDIENCE CHOICE ──────────────────────────
    elif action == "fjaud":
        valid_keys = {k for k, _, _ in FJ_AUDIENCE_OPTIONS}
        if sub in valid_keys:
            g = await get_global_state()
            g["forced_join_audience"] = sub
            await set_global_state(g)
        await edit_panel(cb, _t("👥 برای چه افرادی فعال باشد","👥 Audience",fa), await forced_join_audience_menu(chat_id))

    # ── CHANNEL ADS ───────────────────────────────────────────
    elif action == "ca":
        g        = await get_global_state()
        channels = g.get("channel_ads_channels", [])

        if sub == "toggle":
            g["channel_ads_enabled"] = not g.get("channel_ads_enabled", False)
            if g["channel_ads_enabled"]:
                # وقتی روشن میشه، چرخش از همین لحظه شروع شه (نه منتظر اولین interval)
                g["channel_ads_last_switch"] = 0
            await set_global_state(g)
            await edit_panel(cb, _t("📣 تبلیغات چنل","📣 Channel Ads",fa), await channel_ads_menu(chat_id))

        elif sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["channel_ads_add"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

        elif sub == "list":
            txt, markup = await channel_ads_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx = int(parts[2])
                    if 0 <= idx < len(channels):
                        channels.pop(idx)
                        g["channel_ads_channels"] = channels
                        # ایندکس فعلی رو هم تنظیم کن که از بازه خارج نشه
                        if channels:
                            g["channel_ads_current_index"] = g.get("channel_ads_current_index", 0) % len(channels)
                        else:
                            g["channel_ads_current_index"] = 0
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await channel_ads_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "interval":
            await edit_panel(cb, _t("⏱️ زمان سوئیچ","⏱️ Switch Interval",fa), await channel_ads_interval_menu(chat_id))

    # ── CHANNEL ADS INTERVAL CHOICE ──────────────────────────
    elif action == "caint":
        valid_seconds = {s for s, _, _ in CA_INTERVAL_OPTIONS}
        try:
            chosen = int(sub)
        except ValueError:
            chosen = None
        if chosen in valid_seconds:
            g = await get_global_state()
            g["channel_ads_interval_seconds"] = chosen
            await set_global_state(g)
        await edit_panel(cb, _t("⏱️ زمان سوئیچ","⏱️ Switch Interval",fa), await channel_ads_interval_menu(chat_id))

    # ── BANNED WORDS (کلمه غیر مجاز) ──────────────────────────
    elif action == "bw":
        if sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["banned_words_add"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx   = int(parts[2])
                    words = s.get("banned_words", [])
                    if 0 <= idx < len(words):
                        words.pop(idx)
                        s["banned_words"] = words
                        await set_chat_state(chat_id, s)
                except ValueError:
                    pass
            txt, markup = await banned_words_menu(chat_id)
            await edit_panel(cb, txt, markup)

    # ── پیام همگانی (MASS MESSAGE) ─────────────────────────────
    elif action == "mm":
        if sub == "add":
            if len(parts) >= 4:
                audience = parts[2]
                all_state = await load_state()
                all_state.setdefault("_global", {})["mass_message_add"] = {"chat_id": chat_id, "audience": audience}
                await save_state(all_state)
                await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx   = int(parts[2])
                    g     = await get_global_state()
                    items = g.get("mass_messages", [])
                    if 0 <= idx < len(items):
                        items.pop(idx)
                        g["mass_messages"] = items
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await mass_message_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

    # ── پیام زمان‌دار (TIMED MESSAGE) ───────────────────────────
    elif action == "tm":
        if sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["timed_message_add"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Please wait...",fa), show_alert=True)
            return

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx   = int(parts[2])
                    g     = await get_global_state()
                    items = g.get("timed_messages", [])
                    if 0 <= idx < len(items):
                        items.pop(idx)
                        g["timed_messages"] = items
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await timed_message_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

    # ── نگهبان سیاه / حالت روح (GHOST MODE) ────────────────────
    elif action == "gm":
        if sub == "action":
            if len(parts) >= 4:
                chosen = parts[2]
                g = await get_global_state()
                current = g.get("ghost_action_type")
                # ✅ اگه روی همون گزینه‌ی فعال دوباره بزنه، خاموش می‌شه
                g["ghost_action_type"] = None if (chosen == current) else chosen
                await set_global_state(g)
            await edit_panel(cb, _t("👻 حالت روح","👻 Ghost Mode",fa), await ghost_mode_menu(chat_id))

    # ── سوپر ترک (لیست + ترک همگانی) ──────────────────────────
    elif action == "st":
        if sub == "toggle":
            g = await get_global_state()
            g["super_track_enabled"] = not g.get("super_track_enabled", False)
            # ✅ هر بار این دکمه زده شه (روشن یا خاموش، فرقی نداره)، لیست ردیابی‌شده پاک می‌شه
            g["super_track_channels"] = []
            await set_global_state(g)
            await edit_panel(cb, _t("🛰 سوپر ترک","🛰 Super Track",fa), await supertrack_menu(chat_id))

        elif sub == "list":
            txt, markup = await supertrack_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "leave":
            all_state = await load_state()
            all_state.setdefault("_global", {})["super_track_leave_request"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("🚀 در حال ترک کردن، نتیجه همینجا فرستاده می‌شه...","🚀 Leaving now, result will be sent here...",fa), show_alert=True)
            return

    # ── اسم چرخشی ────────────────────────────────────────────
    elif action == "rn":
        if sub == "toggle":
            g = await get_global_state()
            g["rotating_name_enabled"] = not g.get("rotating_name_enabled", False)
            if g["rotating_name_enabled"]:
                # وقتی روشن میشه، چرخش از همین لحظه شروع شه (نه منتظر اولین interval)
                g["rotating_name_last_switch"] = 0
            await set_global_state(g)
            await edit_panel(cb, _t("🔤 اسم چرخشی","🔤 Rotating Name",fa), await rotating_name_menu(chat_id))

        elif sub == "list":
            txt, markup = await rotating_name_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

        elif sub == "add":
            all_state = await load_state()
            all_state.setdefault("_global", {})["rotating_name_add_request"] = {"chat_id": chat_id}
            await save_state(all_state)
            await cb.answer(_t("کمی صبر کنید...","Userbot will prompt in this chat 📝",fa), show_alert=True)
            return

        elif sub == "del":
            if len(parts) >= 4:
                try:
                    idx   = int(parts[2])
                    g     = await get_global_state()
                    items = g.get("rotating_name_list", [])
                    if 0 <= idx < len(items):
                        items.pop(idx)
                        g["rotating_name_list"] = items
                        await set_global_state(g)
                except ValueError:
                    pass
            txt, markup = await rotating_name_list_menu(chat_id)
            await edit_panel(cb, txt, markup)

    # ── بایگانی (آرشیو دسته‌جمعیِ گروه‌ها/کانال‌ها - اجرای واقعی روی یوزربات) ──
    elif action == "arc":
        ARC_ACTIONS = {
            "ag":      "archive_groups",
            "ac":      "archive_channels",
            "ug":      "unarchive_groups",
            "uc":      "unarchive_channels",
            "restore": "restore_previous",
        }
        if sub in ARC_ACTIONS:
            all_state = await load_state()
            all_state.setdefault("_global", {})["archive_action_request"] = {
                "chat_id": chat_id,
                "action":  ARC_ACTIONS[sub],
            }
            await save_state(all_state)
            await cb.answer(_t("⏳ در حال انجام، نتیجه همینجا فرستاده می‌شه...","⏳ Working on it, result will be sent here...",fa), show_alert=True)
            return

    await cb.answer()

# ===================== RUNNER =====================

async def _setup_bot_menu():
    """✅ جدید: منوی پایین چت (دکمه‌ی کنار آیکون پیوست) - لیست دستورات بات"""
    try:
        await bot.set_my_commands([
            BotCommand(command="start", description="باز کردن پنل"),
            BotCommand(command="panel", description="باز کردن پنل"),
        ])
        await bot.set_chat_menu_button(menu_button=MenuButtonCommands())
    except Exception as e:
        print(f"[bot_menu] setup error: {e}")

async def _run_bot():
    print("AXoRA SelF🌹")
    await _setup_bot_menu()
    await _ensure_panel_image_cached()   # ✅ از همین اول عکس رو کش می‌کنیم تا کوئری اینلاین معطل نمونه
    await dp.start_polling(bot)

def setup(client=None):
    asyncio.get_event_loop().create_task(_run_bot())

if __name__ == "__main__":
    asyncio.run(_run_bot())