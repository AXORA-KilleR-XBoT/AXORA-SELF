import os
import json
import uuid
import asyncio
from pathlib import Path
from datetime import datetime

from telethon import events
from telethon.tl.types import User, UserProfilePhoto, DocumentAttributeVideo
from telethon.tl.functions.photos import GetUserPhotosRequest
from telethon.tl.functions.contacts import GetContactsRequest
from telethon.tl.functions.messages import GetPeerDialogsRequest
from config import settings
from core import panel_state

try:
    from modules.panel import add_stat, log_profile_user
    PANEL_AVAILABLE = True
except ImportError:
    PANEL_AVAILABLE = False
    async def add_stat(key, amount=1): pass
    async def log_profile_user(user_id, name="", username=""): pass
# ===================== تنظیمات =====================

MODE_POLL_INTERVAL = 3    # هر چند ثانیه فقط وضعیت مود پنل چک بشه (سبک - فقط خوندن یک فایل)
SYNC_INTERVAL       = 3  # هر چند ثانیه لیست مخاطبین/چت‌های فعال واقعاً از نو گرفته بشه
STORE_FLUSH_INTERVAL = 3  # هر چند ثانیه tracker روی دیسک ذخیره بشه (اگه چیزی عوض شده باشه)
REPORT_CONCURRENCY  = 8  # حداکثر دانلود/ارسالِ هم‌زمان

_STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"
_STORE_FILE = Path(__file__).resolve().parent.parent / "profile_tracker.json"

_me_id: int | None = None
_photo_dir_ready = False

# tracker داخلی: user_id -> {"photo_id": int, "username": str|None, "name": str}
_tracker: dict[int, dict] = {}
_store_dirty = False
_download_sem = asyncio.Semaphore(REPORT_CONCURRENCY)


# ===================== خوندن مود از پنل =====================

async def _get_profile_mode() -> str:
    """✅ عملکرد+ایمنی: panel_state.json بینِ ~۲۰ ماژول مشترکه - از core/panel_state.py
    رد می‌شه (قفلِ مشترک + ترد جدا) تا نه بلاک کنه نه با نوشتنِ یه ماژولِ دیگه تصادم کنه."""
    try:
        data = await panel_state.load()
        return data.get("_global", {}).get("profile_mode", "all")
    except Exception:
        pass
    return "all"


# ===================== ذخیره‌سازی دائمی (JSON) =====================

def _load_store() -> dict:
    try:
        if _STORE_FILE.exists():
            return json.loads(_STORE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save_store_sync():
    try:
        data = {
            str(uid): {
                "photo_id": info.get("photo_id", 0),
                "username": info.get("username"),
                "name":     info.get("name", ""),
            }
            for uid, info in _tracker.items()
        }
        _STORE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print("profile checker - store save error:", e)


async def _save_store():
    """✅ عملکرد: profile_tracker.json مخصوصِ همین ماژوله (جای دیگه‌ای مشترک
    نیست)، پس نیازی به قفلِ core/panel_state.py نداره - فقط asyncio.to_thread
    تا نوشتنِ دیسک هر ۳ ثانیه (وقتی چیزی عوض شده) کل ربات رو فریز نکنه."""
    await asyncio.to_thread(_save_store_sync)


def _mark_dirty():
    global _store_dirty
    _store_dirty = True


def _load_initial_tracker():
    """موقع استارت، آخرین baseline هرکسی (photo_id/username/name) از دیسک لود
    می‌شه تا با ری‌استارت یوزربات، عکسِ فعلیِ همه به‌اشتباه baseline جدید حساب
    نشه و گزارش‌های تکراری/گم‌شده نداشته باشیم."""
    global _tracker
    stored = _load_store()
    tracker: dict[int, dict] = {}
    for uid_str, info in stored.items():
        try:
            uid = int(uid_str)
        except (TypeError, ValueError):
            continue
        tracker[uid] = {
            "photo_id": info.get("photo_id", 0),
            "username": info.get("username"),
            "name":     info.get("name", ""),
        }
    _tracker = tracker


async def _store_flush_loop():
    global _store_dirty
    while True:
        await asyncio.sleep(STORE_FLUSH_INTERVAL)
        if _store_dirty:
            await _save_store()
            _store_dirty = False


# ===================== ابزارهای کمکی =====================

async def _ensure_me_id(client) -> int:
    global _me_id
    if _me_id is None:
        _me_id = (await client.get_me()).id
    return _me_id


def _extract_photo_id(user: User) -> int:
    photo = getattr(user, "photo", None)
    if isinstance(photo, UserProfilePhoto):
        return int(photo.photo_id)
    return 0


def _display_name(user: User) -> str:
    return f"{getattr(user, 'first_name', '') or ''} {getattr(user, 'last_name', '') or ''}".strip() or "Unknown"


# ===================== Tracker: sync خودکار مخاطبین + چت‌های فعال =====================

async def _sync_tracker(client, mode: str):
    """بر اساس مود فعلی، لیست تحت‌نظرها رو از نو با تلگرام تطبیق می‌ده:
    - contacts/all: مخاطبین واقعی با GetContactsRequest (یک فراخوانی دسته‌ای)
    - chats/all: چت‌های فعال با iter_dialogs (بدون هیچ محدودیت عددی)
    کسی که دیگه توی دامنه نیست حذف می‌شه، تازه‌ها با baseline فعلیشون اضافه
    می‌شن. چون این‌جا داریم عکسِ فعلیِ همه رو هم می‌گیریم (بدون فراخوانی اضافه)،
    هر تغییری که مسیر real-time به هر دلیلی از دست داده باشه این‌جا هم گرفته
    می‌شه - یک شبکه‌ی ایمنیِ رایگان، نه یک polling جدا برای عکس."""
    global _tracker
    me_id = await _ensure_me_id(client)

    if mode == "off":
        if _tracker:
            _tracker = {}
            _mark_dirty()
        return

    live_users: dict[int, User] = {}

    if mode in ("contacts", "all"):
        try:
            result = await client(GetContactsRequest(hash=0))
            for u in getattr(result, "users", []):
                if isinstance(u, User) and not u.bot and u.id != me_id:
                    live_users[u.id] = u
        except Exception as e:
            print("profile checker - contacts sync error:", e)

    if mode in ("chats", "all"):
        try:
            async for dialog in client.iter_dialogs():
                u = dialog.entity
                if isinstance(u, User) and not u.bot and u.id not in (777000, me_id):
                    live_users[u.id] = u
        except Exception as e:
            print("profile checker - dialogs sync error:", e)

    changed: list[User] = []

    for uid in list(_tracker.keys()):
        if uid not in live_users:
            del _tracker[uid]
            _mark_dirty()

    for uid, u in live_users.items():
        cur_photo = _extract_photo_id(u)
        uname     = u.username or None
        name      = _display_name(u)

        if uid in _tracker:
            entry = _tracker[uid]
            if entry.get("username") != uname or entry.get("name") != name:
                entry["username"] = uname
                entry["name"]     = name
                _mark_dirty()
            if entry.get("photo_id", 0) != cur_photo:
                entry["photo_id"] = cur_photo
                _mark_dirty()
                if cur_photo:
                    changed.append(u)
        else:
            _tracker[uid] = {"photo_id": cur_photo, "username": uname, "name": name}
            _mark_dirty()

    for u in changed:
        asyncio.get_event_loop().create_task(_report_profile_change(client, u))


async def periodic_check(client):
    """✅ فیکس: self.py مستقیم این تابع رو به اسم periodic_check صدا می‌زنه
    (asyncio.create_task(profile_checker.periodic_check(client)))، برای همین
    اسمش دقیقاً همین باید بمونه. کارش همون sync دوره‌ای مخاطبین/چت‌های فعاله."""
    last_mode = None
    last_full_sync = 0.0
    while True:
        try:
            mode = await _get_profile_mode()
            now  = asyncio.get_event_loop().time()
            if mode != last_mode or (now - last_full_sync) >= SYNC_INTERVAL:
                await _sync_tracker(client, mode)
                last_mode = mode
                last_full_sync = now
        except Exception as e:
            print("profile checker - tracker sync loop error:", e)
        await asyncio.sleep(MODE_POLL_INTERVAL)


# ===================== گزارش (دانلود + ارسال، پس‌زمینه) =====================

async def _mux_silent_audio(input_path: str) -> str:
    """تلگرام ویدیوهای کاملاً بی‌صدا رو گیف حساب می‌کنه - فارغ از اینکه چه
    attribute ای بفرستیم. یه ترک صدای بی‌صدا اضافه می‌کنیم تا واقعاً به چشمِ
    تلگرام «ویدیو» بیاد. -c:v copy یعنی خودِ ویدیو دست‌نخورده کپی می‌شه (بدون
    ری‌انکود)، برای همین این مرحله سریعه، معمولاً کمتر از ۱ ثانیه."""
    output_path = input_path.rsplit(".", 1)[0] + "_av.mp4"
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono",
        "-c:v", "copy", "-c:a", "aac", "-shortest",
        output_path,
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
        )
        await proc.wait()
        if proc.returncode == 0 and os.path.exists(output_path):
            try:
                os.remove(input_path)
            except Exception:
                pass
            return output_path
    except Exception as e:
        print("profile checker - ffmpeg mux error:", e)
    return input_path


async def _download_profile_media(client, user: User, file_path: str):
    """اگه پروفایل ویدیوییه، کل ویدیو رو دانلود می‌کنه (نه یه فریم عکس).
    وگرنه دقیقاً همون روال قبلی (عکس ساده). is_video هم برمی‌گردونه تا موقع
    ارسال به‌جای گیف، درست به‌عنوان ویدیو تگ بشه."""
    try:
        full = await client(GetUserPhotosRequest(user_id=user, offset=0, max_id=0, limit=1))
        if full.photos and getattr(full.photos[0], "video_sizes", None):
            photo = full.photos[0]
            video_size = photo.video_sizes[-1]
            video_path = file_path.rsplit(".", 1)[0] + ".mp4"
            ok = await client.download_media(photo, file=video_path, thumb=video_size)
            if not ok:
                return False, video_path, True
            video_path = await _mux_silent_audio(video_path)
            return True, video_path, True
    except Exception as e:
        print("profile checker - video photo check error:", e)

    ok = await client.download_profile_photo(user, file=file_path, download_big=True)
    return bool(ok), file_path, False


async def _report_profile_change(client, user: User) -> None:
    global _photo_dir_ready
    async with _download_sem:
        if not _photo_dir_ready:
            os.makedirs(settings.PHOTO_DIR, exist_ok=True)
            _photo_dir_ready = True

        # ✅ اسم فایل یکتا (uuid) - چند دانلود هم‌زمان روی هم سوار نمی‌شن
        file_path = os.path.join(settings.PHOTO_DIR, f"{user.id}_{uuid.uuid4().hex}.jpg")
        try:
            downloaded, file_path, is_video = await _download_profile_media(client, user, file_path)
            if not downloaded:
                return

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            name  = _display_name(user)
            uname = user.username or None

            caption = (
                "🖼 Profile Photo Changed\n"
                f"👤 Name: {name}\n"
                f"🔗 Username:{('@' + uname) if uname else '—'}\n"
                f"🆔 User ID:{user.id}\n"
                f"⏰ Time:{timestamp}"
            )
            send_kwargs = {"caption": caption}
            if is_video:
                send_kwargs["attributes"] = [DocumentAttributeVideo(duration=0, w=0, h=0, supports_streaming=False)]
            await client.send_file(settings.REPORT_CHAT_ID_PROFILE, file_path, **send_kwargs)

            await log_profile_user(user.id, name, uname or "")
        except Exception as e:
            print("profile checker - report error:", e)
        finally:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                pass


# ===================== مسیر Real-Time =====================

async def _live_check_contact(client, user_id: int) -> bool:
    """چک مستقیم و سریع مخاطب بودن - یک GetContactsRequest تنها (نه پیمایش
    دیالوگ‌ها، همون فراخوانی دسته‌ای سریعی که برای sync هم استفاده می‌شه)."""
    try:
        result = await client(GetContactsRequest(hash=0))
        return any(isinstance(u, User) and u.id == user_id for u in getattr(result, "users", []))
    except Exception as e:
        print("profile checker - live contact check error:", e)
        return False


async def _live_check_dialog(client, user_id: int) -> bool:
    """چک مستقیم و سریع «آیا دیالوگ فعال دارم» - فقط برای همین یک نفر، بدون
    پیمایش کل دیالوگ‌ها (که کند بود و باعث تاخیر می‌شد)."""
    try:
        input_peer = await client.get_input_entity(user_id)
        result = await client(GetPeerDialogsRequest(peers=[input_peer]))
        return bool(getattr(result, "dialogs", None))
    except Exception as e:
        print("profile checker - live dialog check error:", e)
        return False


async def _resolve_scope_live(client, user_id: int, mode: str) -> bool:
    """✅ فیکس اصلی: تصمیمِ «توی محدوده هست یا نه» دیگه به tracker/sync وابسته
    نیست - یه چک زنده و مستقیمِ همون یک کاربره، برای همین آنیه."""
    if mode == "off":
        return False
    if mode == "contacts":
        return await _live_check_contact(client, user_id)
    if mode == "chats":
        return await _live_check_dialog(client, user_id)
    if mode == "all":
        if await _live_check_contact(client, user_id):
            return True
        return await _live_check_dialog(client, user_id)
    return False


async def _handle_user_photo(client, user: User) -> None:
    """✅ آپدیتِ photo_id همین‌جا و بدون هیچ awaitای قبلش انجام می‌شه (خودِ
    دیکشنری اتمیکه، قفل لازم نداره) تا اگه ۱ ثانیه بعد دوباره عکس عوض بشه،
    اون‌یکی هم جدا و درست تشخیص داده بشه - نه گم بشه، نه صبر کنه."""
    entry = _tracker.get(user.id)
    if entry is None:
        return  # توی دامنه‌ی مود فعلی نیست

    current_photo_id  = _extract_photo_id(user)
    previous_photo_id = entry.get("photo_id", 0)

    entry["photo_id"] = current_photo_id
    entry["username"] = user.username or None
    entry["name"]     = _display_name(user)
    _mark_dirty()

    if previous_photo_id == current_photo_id:
        return

    if current_photo_id:
        asyncio.get_event_loop().create_task(_report_profile_change(client, user))


def setup(client):
    _load_initial_tracker()
    asyncio.get_event_loop().create_task(_store_flush_loop())

    @client.on(events.Raw)
    async def profile_photo_raw(event):
        update = getattr(event, "update", event)
        if type(update).__name__ != "UpdateUserPhoto":
            return

        mode = await _get_profile_mode()
        if mode == "off":
            return

        user_id = getattr(update, "user_id", None)
        if not isinstance(user_id, int):
            return

        me_id = await _ensure_me_id(client)
        if user_id in (777000, me_id):
            return

        # ✅ فیکس: دیگه منتظر sync نمی‌مونیم و تراکر فقط برای ذخیره state
        # استفاده می‌شه، نه فیلتر کردن. اگه از قبل شناخته‌شده‌ست، مسیر سریع؛
        # وگرنه یه چک زنده و مستقیم (نه پیمایش کامل) همین‌جا و همین لحظه.
        if user_id in _tracker:
            try:
                user = await client.get_entity(user_id)
            except Exception:
                return
            if not isinstance(user, User) or user.bot:
                return
        else:
            in_scope = await _resolve_scope_live(client, user_id, mode)
            if not in_scope:
                return
            try:
                user = await client.get_entity(user_id)
            except Exception:
                return
            if not isinstance(user, User) or user.bot:
                return
            # ✅ عمداً photo_id=0: همین الان یه UpdateUserPhoto واقعی گرفتیم،
            # پس این تغییر باید گزارش بشه، نه فقط baseline بی‌صدا مثل sync.
            _tracker[user_id] = {
                "photo_id": 0,
                "username": user.username or None,
                "name":     _display_name(user),
            }
            _mark_dirty()

        await _handle_user_photo(client, user)