"""
proxy_ping.py — اسکنر و تستر پروکسی تلگرام (نسخه هوشمند AXoRA SelF)
"""

import asyncio
import re
import time
import os
from telethon import events
from telethon.tl.functions import PingRequest # برای سنجش دقیق و واقعی پینگ بدون تاخیر گروه

# ───────────────────────────── تنظیمات ────────────────────────────────────
PROXY_CHANNELS = [
    "chat_nakoni",
    "iMTProto",
    "gargabil",
    "kanfing_proxyy",
    "configsmeli",
    "mitivpn",
]

PROXY_PER_CHANNEL  = 20     
TOTAL_PROXY_TARGET = 30     
SCAN_MSGS_PER_CH   = 150    
CONNECT_TIMEOUT    = 4.0    
RESPONSE_TIMEOUT   = 2.5    
MAX_CONCURRENCY    = 30     
MAX_PING_MS        = 700    

# ────────────────────────────── Regex ──────────────────────────────────────
_MT_RE = re.compile(
    r"(?:tg://|https?://t\.me/)proxy\?server=([^&\s]+)&port=(\d+)&secret=([0-9a-fA-F]{32,})",
    re.IGNORECASE,
)
_SOCKS_RE = re.compile(
    r"(?:tg://|https?://t\.me/)socks\?server=([^&\s]+)&port=(\d+)",
    re.IGNORECASE,
)

_MT_BAD_FIRST = frozenset({
    0x16, 0x44, 0x54, 0x47, 0x50, 0x48, 0x43, 0x45, 0xef, 0xee, 0xdd,
})

# ──────────────────────── Helpers ──────────────────────────────────────────

def _extract_proxies(text: str) -> list:
    if not text:
        return []
    out = []
    for m in _MT_RE.finditer(text):
        srv, port, secret = m.group(1), int(m.group(2)), m.group(3)
        out.append({
            "type": "mtproto",
            "server": srv, "port": port, "secret": secret,
            "link": f"tg://proxy?server={srv}&port={port}&secret={secret}",
        })
    for m in _SOCKS_RE.finditer(text):
        srv, port = m.group(1), int(m.group(2))
        out.append({
            "type": "socks5",
            "server": srv, "port": port, "secret": "",
            "link": f"tg://socks?server={srv}&port={port}",
        })
    return out

async def _close(writer):
    try:
        writer.close()
        await asyncio.wait_for(writer.wait_closed(), timeout=0.5)
    except Exception:
        pass

def _format_titan(text: str) -> str:
    return f"```\n{text}\n```\n\n**__AXoRA SelF__**"

# ─────────────────────── Core Checker ─────────────────────────────────────

async def _check_proxy(p: dict) -> "dict | None":
    server, port = p["server"], p["port"]
    try:
        t0 = time.perf_counter()
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(server, port),
            timeout=CONNECT_TIMEOUT,
        )
        ping_ms = (time.perf_counter() - t0) * 1000.0

        if ping_ms > MAX_PING_MS:
            await _close(writer)
            return None

        valid = False

        if p["type"] == "socks5":
            writer.write(b"\x05\x01\x00")
            await asyncio.wait_for(writer.drain(), timeout=2.0)
            data = await asyncio.wait_for(reader.read(2), timeout=RESPONSE_TIMEOUT)
            valid = len(data) == 2 and data[0] == 0x05 and data[1] == 0x00
        else:
            nonce = bytearray(os.urandom(64))
            while nonce[0] in _MT_BAD_FIRST:
                nonce[0] = os.urandom(1)[0]

            writer.write(bytes(nonce))
            try:
                await asyncio.wait_for(writer.drain(), timeout=2.0)
            except Exception:
                await _close(writer)
                return None

            try:
                data = await asyncio.wait_for(reader.read(1), timeout=RESPONSE_TIMEOUT)
                valid = len(data) > 0 and not reader.at_eof()
            except asyncio.TimeoutError:
                valid = not reader.at_eof()

        await _close(writer)
        if not valid:
            return None

        return {**p, "ping_ms": round(ping_ms, 1)}
    except Exception:
        return None

# ─────────────────────── Channel Scanner ───────────────────────────────────

async def _scan_channel(client, channel: str) -> list:
    result = []
    try:
        async for msg in client.iter_messages(channel, limit=SCAN_MSGS_PER_CH):
            if msg and msg.message:
                result.extend(_extract_proxies(msg.message))
                if len(result) >= PROXY_PER_CHANNEL:
                    return result[:PROXY_PER_CHANNEL]
    except Exception:
        pass
    return result

async def _gather_proxies(client) -> list:
    channel_results = await asyncio.gather(
        *[_scan_channel(client, ch) for ch in PROXY_CHANNELS],
        return_exceptions=True,
    )

    seen = set()
    all_proxies = []
    for batch in channel_results:
        if isinstance(batch, Exception):
            continue
        for p in batch:
            key = (p["server"].lower(), p["port"], p.get("secret", "").lower())
            if key not in seen:
                seen.add(key)
                all_proxies.append(p)

    if not all_proxies:
        return []

    sem = asyncio.Semaphore(MAX_CONCURRENCY)
    async def _one(p):
        async with sem:
            return await _check_proxy(p)

    results = await asyncio.gather(
        *[_one(p) for p in all_proxies],
        return_exceptions=True,
    )

    good = [r for r in results if isinstance(r, dict)]
    good.sort(key=lambda x: x["ping_ms"])
    return good[:TOTAL_PROXY_TARGET]

# ──────────────────────────── Handlers ─────────────────────────────────────

def setup(client):

    @client.on(events.NewMessage(
        outgoing=True,
        pattern=r"(?i)^[/]?(?:ping|پینگ)$",
    ))
    async def ping_handler(event):
        is_persian = "پینگ" in event.raw_text
        
        await event.edit(_format_titan("..."), parse_mode='markdown')
        
        t0 = time.perf_counter()
        try:
            await client(PingRequest(ping_id=0))
            ms = (time.perf_counter() - t0) * 1000.0
        except Exception:
            ms = 150.0

        if is_persian:
            ping_text = f"پینگ سرور:\n⚡ {ms:.0f} میلی‌ثانیه"
        else:
            ping_text = f"Server Ping:\n⚡ {ms:.0f} mS"
            
        await event.edit(_format_titan(ping_text), parse_mode='markdown')

    @client.on(events.NewMessage(
        outgoing=True,
        pattern=r"(?i)^[/]?(?:proxy|prx|پروکسی)$",
    ))
    async def proxy_handler(event):
        if not PROXY_CHANNELS:
            return

        is_persian = "پروکسی" in event.raw_text
        
        # نمایش متن لودینگ اولیه درون کادر مشکی تیتان
        if is_persian:
            await event.edit(_format_titan("⏳ در حال دریافت و تست پروکسی‌ها... لطفاً صبر کن"), parse_mode='markdown')
        else:
            await event.edit(_format_titan("⏳ Gathering and testing proxies... Please wait"), parse_mode='markdown')
            
        proxies = await _gather_proxies(client)

        if not proxies:
            if is_persian:
                return await event.edit(_format_titan("❌ هیچ پروکسی فعال و مناسبی پیدا نشد."), parse_mode='markdown')
            else:
                return await event.edit(_format_titan("❌ No active proxies found."), parse_mode='markdown')

        # کلمه‌ی آبی بر اساس زبان درخواستی کاربر
        anchor_word = "پروکسی" if is_persian else "proxy"
        
        lines = []
        for p in proxies:
            # ساخت لینک آبی به همراه مقدار پینگ با دو لاین فاصله (\n\n)
            lines.append(f"⚡ {p['ping_ms']:.0f}ms ➔ [{anchor_word}]({p['link']})")

        # ادیت نهایی به صورت متن عادی (بدون قالب تیتان) جهت فعال ماندن لینک‌های آبی مارک‌داون
        final_text = "\n\n".join(lines)
        await event.edit(final_text, parse_mode='markdown')