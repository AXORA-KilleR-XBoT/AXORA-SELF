"""
rotating_name.py — اسم چرخشی
==============================
چرخشِ خودکار «نام» (first_name) اکانت بین چند مقدار، هرکدوم با زمانِ ماندگاریِ
مخصوصِ خودش. هر آیتم می‌تواند یک متنِ ثابت باشد، یا یکی از دو کلیدواژه‌ی ویژه‌ی
«ساعت ایران» / «ساعت امریکا» که در لحظه‌ی سوئیچ، با ساعتِ زنده‌ی همان کشور
جایگزین می‌شود (نه یک مقدار ثابتی که فقط موقعِ افزودن محاسبه شده باشد).

⚠️ کاملاً مستقل و self-contained (دقیقاً مثل forced_join.py / mass_message.py) —
مستقیم با panel_state.json مشترک کار می‌کند؛ بدون دستور متنی، همه‌چیز از
دکمه‌های پنل کنترل می‌شود:

    { اسم چرخشی }
        ├─ روشن/خاموش
        ├─ لیست اسم‌ها
        ├─ اضافه کردن اسم
        └─ تایم اسم   (وضعیتِ لحظه‌ای - چه اسمی الان فعاله و چند ثانیه تا سوئیچِ بعدی)

فرمتِ افزودن (کاربر بعد از دیدنِ پرامپت، دقیقاً همین‌طور می‌فرستد):
    نامِ دلخواه  (یا: ساعت ایران / ساعت امریکا)
    30 ثانیه     (یا: 2 دقیقه)

مدل داده (در panel_state.json → _global):
    rotating_name_enabled        : bool
    rotating_name_list           : [{text, seconds, is_clock, clock_country}]
    rotating_name_current_index  : int
    rotating_name_last_switch    : float (timestamp)
    rotating_name_add_request    : {"chat_id": ...} یا None   - پنل می‌گذارد
    rotating_name_waiting        : {"chat_id":..., "prompt_id":...} یا None - این ماژول می‌گذارد
"""

import asyncio
import json
import re
import time
from datetime import datetime
from pathlib import Path

from telethon import events, functions
from telethon.errors import FloodWaitError

from core import panel_state

STATE_FILE = Path(__file__).resolve().parent.parent / "panel_state.json"

# ✅ طبق قرارداد جدید: هر پیامی که این ماژول توی چت می‌فرسته، متنِ اصلی داخل
# کدبلاک (` ``` `) و امضا بعدش، دقیقاً با همون سینتکس که خودت مشخص کردی.
_SIGNATURE = "**__AXoRA SelF__**"

def _fmt(body: str) -> str:
    return f"```{body}```\n\n{_SIGNATURE}"


_ADD_PROMPT_FA = _fmt("📝 لطفا یک اسم را وارد کنید")

# حداقلِ زمانِ مجاز بین سوئیچ‌ها - محافظتی در برابر FloodWait تلگرام روی
# آپدیتِ پروفایل (این عملیات به‌شدت ریت‌لیمیت‌شده است)
_MIN_SECONDS = 10

_handling_add = False


# ===================== STATE I/O (مستقیم از panel_state.json) =====================

async def _load_global() -> dict:
    """✅ async + قفلِ مشترک (core/panel_state.py) - قبلاً سنکرون بود و
    چون panel_state.json بینِ ~۲۰ ماژول مشترکه، بدونِ قفل هم بلاک‌کننده
    بود هم در معرضِ رقابت. رفتار برای صدا‌زننده‌ها یکیه، فقط await لازمه."""
    data = await panel_state.load()
    return data.get("_global", {})


async def _save_global(g: dict) -> None:
    async with panel_state.transaction() as data:
        data["_global"] = g


# ===================== پارسِ ورودی کاربر =====================

def _normalize_fa(text: str) -> str:
    t = (text or "").strip().lower()
    t = t.replace("ي", "ی").replace("ك", "ک")
    return t


def _detect_clock_country(text: str):
    """اگه متن دقیقاً «ساعت ایران» یا «ساعت امریکا/آمریکا» باشه، کشور رو برمی‌گردونه، وگرنه None"""
    compact = _normalize_fa(text).replace(" ", "").replace("‌", "")
    if compact == "ساعتایران":
        return "iran"
    if compact in ("ساعتامریکا", "ساعتآمریکا"):
        return "usa"
    return None


def _parse_seconds(text: str) -> int:
    """«30 ثانیه» یا «2 دقیقه» یا «1 ساعت» رو به ثانیه تبدیل می‌کنه؛ بدونِ واحد = ثانیه در نظر گرفته می‌شه"""
    t = _normalize_fa(text)
    m = re.search(r"(\d+)", t)
    n = int(m.group(1)) if m else 60
    if "ساعت" in t or "hour" in t or "hr" in t:
        n *= 3600
    elif "دقیقه" in t or "min" in t:
        n *= 60
    return max(_MIN_SECONDS, n)


def _live_clock_text(country: str) -> str:
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo("Asia/Tehran" if country == "iran" else "America/New_York")
    except Exception:
        import pytz
        tz = pytz.timezone("Asia/Tehran" if country == "iran" else "America/New_York")
    return datetime.now(tz).strftime("%H:%M")


def _resolve_display(item: dict) -> str:
    if item.get("is_clock"):
        return _live_clock_text(item.get("clock_country"))
    return item.get("text", "")


def _country_label(country: str) -> str:
    return "🕐 ساعت ایران" if country == "iran" else "🕐 ساعت آمریکا"


def _split_names_and_duration(args: str):
    """ورودیِ دستور /اسم رو به (لیست اسم‌ها, ثانیه) می‌شکنه.
    آخرین توکن یا دو توکنِ آخر، زمانه: «...20» یا «...20 ثانیه/دقیقه/ساعت».
    هر توکنِ باقیمانده قبل از اون، یک اسمِ جداگانه است."""
    tokens = args.split()
    if len(tokens) < 2:
        return None

    if re.match(r"^\d+$", tokens[-1]):
        names   = tokens[:-1]
        seconds = _parse_seconds(tokens[-1])
    elif len(tokens) >= 2 and re.match(r"^\d+$", tokens[-2]):
        names   = tokens[:-2]
        seconds = _parse_seconds(f"{tokens[-2]} {tokens[-1]}")
    else:
        return None

    if not names:
        return None
    return names, seconds


# ===================== حلقه‌ی چرخش =====================

async def _rotation_loop(client) -> None:
    while True:
        try:
            g = await _load_global()
            if g.get("rotating_name_enabled", False):
                items = g.get("rotating_name_list", [])
                if items:
                    idx         = g.get("rotating_name_current_index", 0) % len(items)
                    item        = items[idx]
                    duration    = max(_MIN_SECONDS, item.get("seconds", 60))
                    last_switch = g.get("rotating_name_last_switch", 0)
                    now         = time.time()
                    if now - last_switch >= duration:
                        display = _resolve_display(item)
                        try:
                            await client(functions.account.UpdateProfileRequest(first_name=display))
                        except FloodWaitError:
                            pass   # دور بعدی دوباره تلاش می‌شه؛ لازم نیست همینجا صبر کنیم و حلقه رو قفل کنیم
                        except Exception:
                            pass
                        g["rotating_name_current_index"] = (idx + 1) % len(items)
                        g["rotating_name_last_switch"]   = now
                        await _save_global(g)
        except Exception:
            pass
        await asyncio.sleep(5)


# ===================== درخواستِ افزودن (از پنل) =====================

async def _process_add_request(client, req: dict) -> None:
    global _handling_add
    chat_id = req.get("chat_id")
    if not chat_id:
        _handling_add = False
        return
    try:
        msg = await client.send_message(chat_id, _ADD_PROMPT_FA)
    except Exception:
        _handling_add = False
        return
    g = await _load_global()
    g.pop("rotating_name_add_request", None)
    g["rotating_name_waiting"] = {"chat_id": chat_id, "prompt_id": msg.id}
    await _save_global(g)
    _handling_add = False


async def _request_loop(client) -> None:
    global _handling_add
    while True:
        try:
            g   = await _load_global()
            req = g.get("rotating_name_add_request")
            if req and not _handling_add:
                _handling_add = True
                asyncio.get_event_loop().create_task(_process_add_request(client, req))
        except Exception:
            pass
        await asyncio.sleep(3)


def setup(client):

    # ✅ جدید: دستور سریع /اسم نام1 نام2 ... N ثانیه/دقیقه/ساعت
    # اگه لیست خالی بود: اسمِ فعلیِ اکانت رو هم به لیست اضافه می‌کنه تا چرخش
    # بین «اسم الان» و «اسم(های) جدید» معنادار باشه. اگه لیست از قبل چیزی
    # داشت، فقط اسم‌های جدید با همون تایمِ داده‌شده به همون لیست اضافه می‌شن.
    @client.on(events.NewMessage(outgoing=True, pattern=r'(?i)^[./]اسم\s+(.+)$'))
    async def quick_name_handler(event):
        args   = event.pattern_match.group(1).strip()
        parsed = _split_names_and_duration(args)
        if not parsed:
            try:
                await event.edit(_fmt("❌ فرمت اشتباهه؛ به این شکل بفرست:\n/اسم نام1 نام2 ... 20 ثانیه"))
            except Exception:
                pass
            return

        names, seconds = parsed
        g        = await _load_global()
        existing = g.get("rotating_name_list", [])
        new_items = []

        if not existing:
            current_name = ""
            try:
                me = await client.get_me()
                current_name = (me.first_name or "").strip()
            except Exception:
                current_name = ""
            if current_name:
                new_items.append({
                    "text": current_name, "seconds": seconds,
                    "is_clock": False, "clock_country": None,
                })

        for name in names:
            country = _detect_clock_country(name)
            new_items.append({
                "text": name,
                "seconds": seconds,
                "is_clock": country is not None,
                "clock_country": country,
            })

        g["rotating_name_list"] = existing + new_items
        g["rotating_name_enabled"] = True
        g["rotating_name_last_switch"] = time.time()
        if not existing:
            g["rotating_name_current_index"] = 0
        await _save_global(g)

        try:
            await event.edit(_fmt(f"✅ {len(new_items)} اسم اضافه شد و چرخش هر {seconds} ثانیه فعال شد"))
        except Exception:
            pass

    @client.on(events.NewMessage(outgoing=True))
    async def add_catcher(event):
        text = (event.raw_text or "").strip()
        if not text or text == _ADD_PROMPT_FA:
            return

        g       = await _load_global()
        waiting = g.get("rotating_name_waiting")
        if not waiting or event.chat_id != waiting.get("chat_id") or event.id <= waiting.get("prompt_id", 0):
            return

        # ✅ لغو فرآیند با نوشتن «لغو» یا «cancel»
        if _normalize_fa(text) in ("لغو", "cancel"):
            g.pop("rotating_name_waiting", None)
            await _save_global(g)
            try:
                await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
            except Exception:
                pass
            try:
                await event.delete()
            except Exception:
                pass
            try:
                await client.send_message(event.chat_id, _fmt("❌ لغو شد"))
            except Exception:
                pass
            return

        lines = [l.strip() for l in text.splitlines() if l.strip()]
        if len(lines) < 2:
            try:
                await event.reply(_fmt("❌ فرمت اشتباهه؛ اسم رو خط اول، زمان رو خط دوم بفرست"))
            except Exception:
                pass
            return   # حالت انتظار رو نگه می‌داریم تا دوباره تلاش کنه

        name_line = lines[0]
        seconds   = _parse_seconds(lines[1])
        country   = _detect_clock_country(name_line)

        item = {
            "text":          name_line,
            "seconds":       seconds,
            "is_clock":      country is not None,
            "clock_country": country,
        }

        items = g.get("rotating_name_list", [])
        items.append(item)
        g["rotating_name_list"] = items
        g.pop("rotating_name_waiting", None)
        await _save_global(g)

        try:
            await client.delete_messages(event.chat_id, [waiting.get("prompt_id")])
        except Exception:
            pass
        try:
            await event.delete()
        except Exception:
            pass

        shown = _country_label(country) if country else name_line
        try:
            await client.send_message(event.chat_id, _fmt(f"✅ اضافه شد: {shown} ({seconds} ثانیه)"))
        except Exception:
            pass

    asyncio.get_event_loop().create_task(_rotation_loop(client))
    asyncio.get_event_loop().create_task(_request_loop(client))