import re
import json
import asyncio
from pathlib import Path
from telethon import TelegramClient, events

from core import panel_state

_client_ref = None
_my_id: int | None = None

async def _get_my_id() -> int:
    global _my_id
    if _my_id is None and _client_ref is not None:
        try:
            _my_id = (await _client_ref.get_me()).id
        except Exception:
            return 0
    return _my_id or 0

# ---------------------------------------------------------------------------
# ماژول منشی (فونت‌ساز) - دو راه برای اعمال فونت:
#
#   ۱) سراسری/دائمی - از دکمه‌های پنل (منشی → یکی از فونت‌ها) روشن می‌شه و
#      روی همه‌ی پیام‌های بعدی اعمال می‌شه تا خودت از پنل خاموشش کنی. هیچ
#      دستور متنی‌ای برای این حالت نیست، فقط دکمه.
#   ۲) تک‌پیامی - همون لحظه که پیامت رو با /بولد یا /اسپویل و... شروع کنی
#      (اسم خودِ فونت، بدون کلمه‌ی «فونت»)، فقط همون یک پیام به اون فونت در
#      میاد - کاملاً مستقل از اینکه فونت سراسری روشنه یا نه.
#
# قرارداد استیت سراسری (این کلید توسط panel_bot.py نوشته می‌شه):
#   panel_state.json → { "_global": { ..., "secretary_font": "<key>" یا null }, ... }
#   <key> یکی از: bold, spoil, italic, mono, strike, underline, quote
# ---------------------------------------------------------------------------

STATE_KEY     = "secretary_font"
POLL_INTERVAL = 2  # ثانیه


async def _load_global() -> dict:
    """✅ عملکرد+ایمنی: این تابع هر ۲ ثانیه از _poll_panel_state صدا زده
    می‌شه - یعنی همیشه، تا وقتی رباته روشنه، نه فقط وقتی کاربر کاری می‌کنه.
    قبلاً سنکرون بود (هر ۲ ثانیه بلاک می‌کرد)؛ حالا از core/panel_state.py
    رد می‌شه که هم غیرمسدودکننده‌ست هم با نوشتنِ ~۲۰ ماژولِ دیگه روی همون
    فایل قفلِ مشترک داره."""
    try:
        all_state = await panel_state.load()
        return all_state.get(str(await _get_my_id()), {}).get("_global", {})
    except Exception:
        return {}


async def _save_global(data: dict):
    """اگه لازم شد این ماژول چیزی توی "_global" ذخیره کنه - بقیه‌ی استیت
    (چت‌ها/آمار) دست‌نخورده می‌مونه، فقط "_global" جایگزین می‌شه."""
    try:
        async with panel_state.transaction() as all_state:
            all_state.setdefault(str(await _get_my_id()), {})["_global"] = data
    except Exception:
        pass


# کلید انگلیسی → لیبل فارسی (همون چیزی که پنل نشون می‌ده) + قالب فرمت‌دهی
FONT_STYLES = {
    "bold":      {"label": "بولد",      "template": "**{}**"},
    "spoil":     {"label": "اسپویل",    "template": "||{}||"},
    "italic":    {"label": "ایتالیک",   "template": "__{}__"},
    "mono":      {"label": "مونو",      "template": "`{}`"},
    "strike":    {"label": "خط خورده",  "template": "~~{}~~"},
    "underline": {"label": "زیرخط",     "template": "<u>{}</u>"},
    "quote":     {"label": "نقل قول",   "template": "> {}"},
}

CURRENT_GLOBAL_FONT = None  # یکی از کلیدهای FONT_STYLES یا None (خاموش)

# ── دستور تک‌پیامی: /بولد متن یا /bold text و... (بدون کلمه‌ی «فونت») ──
_TRIGGER_TO_KEY = {}
for _key, _style in FONT_STYLES.items():
    _TRIGGER_TO_KEY[_style["label"]] = _key   # فارسی: بولد, اسپویل, ...
    _TRIGGER_TO_KEY[_key.lower()]    = _key   # انگلیسی: bold, spoil, ...

_SINGLE_SHOT_PATTERN = re.compile(
    r"^/(" + "|".join(re.escape(w) for w in sorted(_TRIGGER_TO_KEY, key=len, reverse=True)) + r")\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)


def setup(client: TelegramClient):
    global CURRENT_GLOBAL_FONT

    async def _poll_panel_state():
        global CURRENT_GLOBAL_FONT
        while True:
            try:
                g = await _load_global()
                font_key = g.get(STATE_KEY)
                CURRENT_GLOBAL_FONT = font_key if font_key in FONT_STYLES else None
            except Exception:
                pass
            await asyncio.sleep(POLL_INTERVAL)

    asyncio.get_event_loop().create_task(_poll_panel_state())

    @client.on(events.NewMessage(outgoing=True))
    async def auto_font_changer(event):
        text = event.raw_text
        if not text or not text.strip():
            return

        # ── تک‌پیامی: /بولد متن، /اسپویل متن و... - مستقل از فونت سراسری ──
        m = _SINGLE_SHOT_PATTERN.match(text)
        if m:
            trigger  = m.group(1)
            font_key = _TRIGGER_TO_KEY.get(trigger) or _TRIGGER_TO_KEY.get(trigger.lower())
            if font_key:
                await apply_font(event, font_key, m.group(2))
                return

        # به دستورهای سایر ماژول‌ها کاری نداشته باش
        if text.startswith(('/', '.')):
            return

        # ── سراسری: از پنل (منشی) روشن شده باشه ──
        if CURRENT_GLOBAL_FONT:
            await apply_font(event, CURRENT_GLOBAL_FONT, text)


async def apply_font(event, font_key: str, content: str):
    style = FONT_STYLES.get(font_key)
    if not style:
        return
    try:
        if font_key == "underline":
            await event.edit(style["template"].format(content), parse_mode="html")
        else:
            await event.edit(style["template"].format(content), parse_mode="md")
    except Exception:
        pass

def setup(client):
    global _client_ref
    _client_ref = client