import asyncio
from telethon import events
from telethon.errors import (
    FloodWaitError,
    ChatAdminRequiredError,
    UserAdminInvalidError,
    UserNotParticipantError,
    ChatNotModifiedError,
)
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.types import ChatBannedRights
from telethon.tl.functions.contacts import BlockRequest
from telethon.tl.functions.messages import DeleteHistoryRequest

# Full ban: حتی دیدن پیام‌ها هم ممنوع
BAN_RIGHTS = ChatBannedRights(until_date=None, view_messages=True)

# حداکثر درخواست همزمان — از FloodWait جلوگیری می‌کنه
_SEM = asyncio.Semaphore(15)


async def _ban_one(client, entity, user_input):
    """بن کردن user_input در یک entity — کاملاً concurrent‌safe."""
    async with _SEM:
        try:
            perms = await client.get_permissions(entity, "me")
            if not (perms.is_admin and perms.ban_users):
                return False
            await client(EditBannedRequest(entity, user_input, BAN_RIGHTS))
            return True
        except FloodWaitError as e:
            await asyncio.sleep(e.seconds + 1)
            try:
                await client(EditBannedRequest(entity, user_input, BAN_RIGHTS))
                return True
            except Exception:
                return False
        except (
            ChatAdminRequiredError,
            UserAdminInvalidError,
            UserNotParticipantError,
            ChatNotModifiedError,
        ):
            return False
        except Exception:
            return False


async def _ban_all(client, user_input):
    """
    همه دیالوگ‌ها رو می‌گیره و همزمان بن می‌کنه.
    برمی‌گردونه: تعداد گروه/کانال‌هایی که موفق بودن.
    """
    dialogs = await client.get_dialogs()
    entities = [
        d.entity
        for d in dialogs
        if d.is_group or d.is_channel
    ]

    results = await asyncio.gather(
        *[_ban_one(client, e, user_input) for e in entities],
        return_exceptions=True,
    )

    return sum(1 for r in results if r is True)


def setup(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^SIK$"))
    async def sik_handler(event):
        if not event.is_reply:
            return await event.edit("⚠️ ریپلای کن روی طرف")

        reply = await event.get_reply_message()
        sender = await reply.get_sender()

        # input entity برای کمترین overhead در درخواست‌های موازی
        try:
            user_input = await client.get_input_entity(sender.id)
        except Exception:
            user_input = sender.id

        await event.edit("⏳ در حال بن کردن از همه گروه‌ها...")

        count = await _ban_all(client, user_input)
        await event.edit(f"✅ از {count} گروه/کانال بن شد")


    @client.on(events.NewMessage(outgoing=True, pattern=r"^SIKTIR$"))
    async def siktir_handler(event):
        if not event.is_reply:
            return await event.edit("⚠️ ریپلای کن روی طرف")

        reply = await event.get_reply_message()
        sender = await reply.get_sender()

        try:
            user_input = await client.get_input_entity(sender.id)
        except Exception:
            user_input = sender.id

        await event.edit("⏳ در حال اجرا...")

        async def _block():
            try:
                await client(BlockRequest(user_input))
                return True
            except Exception:
                return False

        async def _delete_history():
            try:
                # max_id=0 → فقط پیام‌های موجود؛ revoke=True → دوطرفه پاک می‌شه
                await client(DeleteHistoryRequest(
                    peer=user_input, max_id=0, revoke=True
                ))
                return True
            except Exception:
                return False

        # بن + بلاک + پاک کردن چت — همه با هم
        count, blocked, deleted = await asyncio.gather(
            _ban_all(client, user_input),
            _block(),
            _delete_history(),
        )

        parts = [f"از {count} گروه/کانال بن شد"]
        if blocked:
            parts.append("بلاک شد")
        if deleted:
            parts.append("چت دوطرفه پاک شد")

        await event.edit(" + ".join(parts) + " ✅")