import asyncio
import re
from telethon import events
from telethon.errors import FloodWaitError

active_spams = {}

def parse_time_to_seconds(time_str):
    time_str = time_str.lower().strip()
    match = re.match(r'^(\d+(?:\.\d+)?)', time_str)
    if not match:
        return None
    
    value = float(match.group(1))
    
    if any(u in time_str for u in ['ثانیه', 's', 'sec', 'second']):
        return value
    elif any(u in time_str for u in ['دقیقه', 'm', 'min', 'minute']):
        return value * 60
    elif any(u in time_str for u in ['ساعت', 'h', 'hr', 'hour']):
        return value * 3600
    
    return value

async def _respond_flood_safe(event, msg_text: str):
    """✅ قدرت: قبلاً هر دو ورکر فقط asyncio.CancelledError می‌گرفتن - یعنی
    اولین FloodWaitError (که برای ارسال پشت‌سرهم تقریباً حتمیه) کل تسکِ اسپم
    رو بی‌صدا می‌کشت، بدون خطا به کاربر و بدون تلاش دوباره. حالا صبر می‌کنه
    و همون پیام رو دوباره می‌فرسته - نه پیامی جا می‌مونه نه تسک بی‌دلیل می‌میره."""
    while True:
        try:
            await event.respond(msg_text)
            return
        except FloodWaitError as e:
            await asyncio.sleep(e.seconds)


def setup(client):
    
    # ==================== توقف اسپم ====================
    @client.on(events.NewMessage(pattern=r'^توقف اسپم', outgoing=True))
    async def stop_spam(event):
        chat_id = event.chat_id
        await event.delete()
        
        if chat_id in active_spams and not active_spams[chat_id].done():
            active_spams[chat_id].cancel()
            try:
                await active_spams[chat_id]
            except asyncio.CancelledError:
                pass
            active_spams.pop(chat_id, None)
            msg = await event.respond("🛑 **اسپم متوقف شد.**")
            await asyncio.sleep(2)
            await msg.delete()
        else:
            msg = await event.respond("❌ **اسپم فعالی وجود ندارد.**")
            await asyncio.sleep(2)
            await msg.delete()

    # ==================== اسپم زمان‌دار (اصلی) ====================
    @client.on(events.NewMessage(pattern=r'^اسپم (\d+(?:\.\d+)?\s*[\w\u0600-\u06FF]+)\s+(\d+)\s+(.+)', outgoing=True))
    async def start_timed_spam(event):
        chat_id = event.chat_id
        time_raw = event.pattern_match.group(1).strip()
        count = int(event.pattern_match.group(2))
        text = event.pattern_match.group(3).strip()

        delay = parse_time_to_seconds(time_raw)
        if not delay or delay <= 0 or count < 1:
            msg = await event.respond("❌ فرمت اشتباه! مثال:\n`اسپم 8 ثانیه 6 دوستت دارم`")
            await asyncio.sleep(3)
            await msg.delete()
            return

        await event.delete()

        # توقف اسپم قبلی
        if chat_id in active_spams and not active_spams[chat_id].done():
            active_spams[chat_id].cancel()
            try:
                await active_spams[chat_id]
            except asyncio.CancelledError:
                pass

        async def timed_worker():
            try:
                for i in range(count):
                    await _respond_flood_safe(event, text)
                    if i < count - 1:
                        await asyncio.sleep(delay)
            except asyncio.CancelledError:
                pass
            finally:
                active_spams.pop(chat_id, None)

        task = asyncio.create_task(timed_worker())
        active_spams[chat_id] = task

    # ==================== اسپم سریع ====================
    @client.on(events.NewMessage(pattern=r'^اسپم (\d+) (.+)', outgoing=True))
    async def start_fast_spam(event):
        # فقط اگر هیچ واحد زمانی نداشته باشه اجرا بشه
        text = event.text
        if any(u in text for u in ['ثانیه', 'دقیقه', 'ساعت', 's ', 'm ', 'h ']) or text.startswith('اسپم یکجا') or text.lower().startswith('spam'):
            return

        chat_id = event.chat_id
        count = int(event.pattern_match.group(1))
        message = event.pattern_match.group(2).strip()

        await event.delete()

        if chat_id in active_spams and not active_spams[chat_id].done():
            active_spams[chat_id].cancel()
            try:
                await active_spams[chat_id]
            except asyncio.CancelledError:
                pass

        async def fast_worker():
            try:
                for _ in range(count):
                    await _respond_flood_safe(event, message)
                    await asyncio.sleep(0.5)
            except asyncio.CancelledError:
                pass
            finally:
                active_spams.pop(chat_id, None)

        task = asyncio.create_task(fast_worker())
        active_spams[chat_id] = task

    # ==================== اسپم یکجا با پشتیبانی انگلیسی و محدودکننده طول ====================
    # با قرار دادن (?i) در ابتدای پترن، بزرگ یا کوچک بودن حروف انگلیسی نادیده گرفته می‌شود
    @client.on(events.NewMessage(pattern=r'(?i)^(?:اسپم یکجا|!?spam)\s+(\d+)\s+(.+)', outgoing=True))
    async def start_single_message_spam(event):
        count = int(event.pattern_match.group(1))
        message = event.pattern_match.group(2).strip()

        if count < 1:
            return

        await event.delete()
        
        # ساخت پیام با تکرار کلمه و ایجاد فاصله بین آن‌ها
        final_message = " ".join([message] * count)
        
        # کنترل سقف مجاز تلگرام (۴۰۹۶ کاراکتر)
        if len(final_message) > 4096:
            final_message = final_message[:4096]
        
        # ارسال پیام واحد
        await _respond_flood_safe(event, final_message)