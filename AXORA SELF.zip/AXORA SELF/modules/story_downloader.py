# -*- coding: utf-8 -*-
# ===================== ذخیره‌ی خودکار استوری‌ها در Saved Messages =====================
#
# منطق:
#   هر کسی (کانتکت یا کانالی که عضوشی) استوری بذاره، تلگرام یه UpdateStory برای اکانتت
#   می‌فرسته. همون لحظه مدیای استوری دانلود می‌شه و توی «پیام‌های ذخیره‌شده» (Saved
#   Messages) با این کپشن ذخیره می‌شه:
#
#       📸 استوری جدید
#       👤 نام: مهسا
#       🆔 آیدی عددی: 123456789
#       🔖 یوزر آیدی: @mahsa
#       🕒 زمان گذاشتن: 21:14 - 2026/10/13
#       💬 متن استوری: ...        (فقط اگه خودِ استوری متن داشته باشه)
#
# کنترل از پنل:
#   کلیدِ story_auto_download توی بخشِ مخصوصِ همین اکانت در panel_state.json
#   (تاگلِ «دانلود خودکار» استوری). پیش‌فرض خاموشه.
#
# نکته‌های فنی:
#   - هندلر فقط روی UpdateStory اجرا می‌شه (نه روی هر آپدیتِ خام) و کارِ سنگین توی
#     تسکِ جدا انجام می‌شه تا صفِ آپدیت‌های تلگرام معطل نشه.
#   - state ها (دِدوپ، سمافور) برای هر اکانت جدان — مناسبِ حالتِ چندکاربره.
#   - ادیت/پینِ همون استوری دوباره ذخیره نمی‌شه (دِدوپ، حتی بعد از ری‌استارت).
#   - مقصد Saved Messages خودِ اکانته، نه یه چتِ مشترک.

import os
import json
import html
import asyncio
import tempfile
from pathlib import Path
from datetime import datetime, timedelta, timezone

from telethon import events, functions, utils
from telethon.errors import FloodWaitError
from telethon.tl import types as tl_types

from core import panel_state

try:
    from zoneinfo import ZoneInfo
    LOCAL_TZ = ZoneInfo("Asia/Tehran")
except Exception:                                    # ویندوزِ بدون پکیج tzdata
    LOCAL_TZ = timezone(timedelta(hours=3, minutes=30))

# ===================== SETTINGS =====================

TOGGLE_KEY             = "story_auto_download"   # کلیدِ تاگل توی بخشِ هر اکانت در panel_state.json
SAVE_TARGET            = "me"                    # Saved Messages
MAX_PARALLEL           = 4                       # حداکثر دانلود/آپلودِ هم‌زمانِ استوری‌ها
SAVE_PROTECTED_STORIES = False                   # True → استوری‌های «محافظت‌شده» (noforwards) هم ذخیره بشن
MAX_STORY_TEXT         = 600                     # حداکثر طولِ متنِ خودِ استوری توی کپشن
FLOOD_MAX_WAIT         = 120                     # FloodWait بلندتر از این (ثانیه) → ردّ کن
RETRY_DELAY            = 3                       # ثانیه‌ی صبر قبل از تلاشِ دوم (فقط وقتی دانلود/ارسال خطا بده)
SEEN_LIMIT             = 3000                    # تعدادِ آخرین استوری‌هایی که برای دِدوپ یادش می‌مونه

SEEN_DIR = Path(__file__).resolve().parent.parent        # کنارِ panel_state.json
TMP_DIR  = Path(tempfile.gettempdir()) / "story_saver"   # فایل‌های موقتِ دانلود (بعد از ارسال پاک می‌شن)


# ===================== HELPERS =====================

def _fmt_time(dt) -> str:
    """زمانِ گذاشته‌شدنِ استوری (UTC) → وقتِ تهران"""
    try:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(LOCAL_TZ).strftime("%H:%M - %Y/%m/%d")
    except Exception:
        return datetime.now(LOCAL_TZ).strftime("%H:%M - %Y/%m/%d")


def _esc(s) -> str:
    return html.escape(str(s), quote=False)


def _pick_username(entity) -> str:
    uname = getattr(entity, "username", None)
    if uname:
        return uname
    for u in getattr(entity, "usernames", None) or []:          # یوزرنیم‌های چندگانه / کالکتیبل
        if getattr(u, "active", False) and getattr(u, "username", None):
            return u.username
    return ""


def _build_caption(name, peer_id, username, when, story_text=None) -> str:
    lines = [
        "📸 <b>استوری جدید</b>",
        f"👤 نام: {_esc(name)}",
        f"🆔 آیدی عددی: <code>{peer_id}</code>",
        f"🔖 یوزر آیدی: @{_esc(username)}" if username else "🔖 یوزر آیدی: ندارد",
        f"🕒 زمان گذاشتن: {when}",
    ]
    text = (story_text or "").strip()
    if text:
        if len(text) > MAX_STORY_TEXT:
            text = text[:MAX_STORY_TEXT].rstrip() + "…"
        lines.append(f"💬 متن استوری: {_esc(text)}")
    return "\n".join(lines)


def _video_kwargs(media) -> dict:
    """مدت و ابعادِ ویدیو رو از خودِ استوری برمی‌داره تا ویدیو توی Saved Messages
    عمودی و با مدتِ درست نشون داده بشه (بدون نیاز به hachoir)."""
    try:
        doc = getattr(media, "document", None)
        for attr in getattr(doc, "attributes", None) or []:
            if isinstance(attr, tl_types.DocumentAttributeVideo):
                return {
                    "attributes": [tl_types.DocumentAttributeVideo(
                        duration=attr.duration, w=attr.w, h=attr.h, supports_streaming=True)],
                    "supports_streaming": True,
                }
    except Exception:
        pass
    return {}


# ===================== SEEN STORE (دِدوپ) =====================

class _SeenStore:
    """آخرین استوری‌های ذخیره‌شده (کلید: peer_id:story_id). روی دیسک هم نگه داشته می‌شه
    تا بعد از ری‌استارت، ادیت/پینِ یه استوریِ قدیمی دوباره ذخیره‌ش نکنه."""

    def __init__(self, path: Path, limit: int):
        self._path  = path
        self._limit = limit
        self._keys  = {}                 # dict به‌جای set تا ترتیبِ ورود حفظ بشه
        self._lock  = asyncio.Lock()

    def _read(self) -> list:
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return [k for k in data if isinstance(k, str)] if isinstance(data, list) else []
        except Exception:
            return []

    def _write(self, keys: list) -> None:
        tmp = self._path.with_name(self._path.name + ".tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(keys, f)
            os.replace(tmp, self._path)
        except Exception as e:
            print(f"[story_saver] seen-file write error: {e!r}")

    async def load(self) -> None:
        self._keys = dict.fromkeys(await asyncio.to_thread(self._read))

    def __contains__(self, key) -> bool:
        return key in self._keys

    async def add(self, key: str) -> None:
        async with self._lock:
            self._keys[key] = None
            while len(self._keys) > self._limit:
                self._keys.pop(next(iter(self._keys)))
            await asyncio.to_thread(self._write, list(self._keys))


# ===================== STORY SAVER =====================

class _StorySaver:
    """یه نمونه برای هر اکانت (هر کلاینت) — state ها از اکانت‌های دیگه جدان."""

    def __init__(self, client):
        self.client     = client
        self.me_id      = None
        self._seen      = None                           # بعد از شناختنِ me_id ساخته می‌شه
        self._busy      = set()                          # استوری‌هایی که همین الان در حال پردازشن
        self._tasks     = set()                          # رفرنسِ تسک‌ها تا وسطِ کار garbage-collect نشن
        self._sem       = asyncio.Semaphore(MAX_PARALLEL)
        self._init_lock = asyncio.Lock()

    # ---------- ورودی از هندلر ----------

    def schedule(self, update) -> None:
        task = self.client.loop.create_task(self._run(update))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _run(self, update) -> None:
        try:
            await self._process(update.peer, update.story)
        except Exception as e:
            print(f"[story_saver] error: {e!r}")

    # ---------- آماده‌سازیِ تنبل (me_id + فایل seen) ----------

    async def _ensure_ready(self) -> None:
        if self._seen is not None:
            return
        async with self._init_lock:
            if self._seen is not None:
                return
            me = await self.client.get_me()
            store = _SeenStore(SEEN_DIR / f"story_saver_seen_{me.id}.json", SEEN_LIMIT)
            await store.load()
            self.me_id = me.id
            self._seen = store                           # آخر از همه؛ یعنی بقیه‌ی فیلدها آماده‌ان

    async def _enabled(self) -> bool:
        """تاگلِ پنل — فقط توی بخشِ همین اکانت خونده می‌شه"""
        try:
            data = await panel_state.load()
            return bool(data.get(str(self.me_id), {}).get(TOGGLE_KEY, False))
        except Exception:
            return False

    # ---------- منطقِ اصلی ----------

    async def _process(self, peer, story) -> None:
        story_id = getattr(story, "id", None)
        if story_id is None or isinstance(story, tl_types.StoryItemDeleted):
            return

        await self._ensure_ready()
        if not await self._enabled():
            return

        peer_id = utils.get_peer_id(peer)
        if peer_id == self.me_id or getattr(story, "out", False):   # استوریِ خودمون
            return

        key = f"{peer_id}:{story_id}"
        if key in self._seen or key in self._busy:       # ادیت/پین/آپدیتِ تکراریِ همون استوری
            return

        self._busy.add(key)
        try:
            if not isinstance(story, tl_types.StoryItem):    # StoryItemSkipped → نسخه‌ی کامل رو بگیر
                story = await self._fetch_full(peer, story_id)
                if story is None:
                    return

            media = getattr(story, "media", None)
            if media is None:
                return

            if getattr(story, "noforwards", False) and not SAVE_PROTECTED_STORIES:
                print(f"[story_saver] story {key} is protected (noforwards) - skipped")
                return

            name, username = await self._who(peer)
            caption = _build_caption(
                name, peer_id, username,
                _fmt_time(getattr(story, "date", None)),
                getattr(story, "caption", None),
            )
            stem = f"{self.me_id}_{peer_id}_{story_id}".replace("-", "c")

            if await self._download_and_send(media, stem, caption, key):
                await self._seen.add(key)
        finally:
            self._busy.discard(key)

    async def _fetch_full(self, peer, story_id):
        """StoryItemSkipped فقط id/date داره؛ نسخه‌ی کامل (با مدیا) رو جدا می‌گیریم"""
        try:
            input_peer = await self.client.get_input_entity(peer)
            res = await self.client(functions.stories.GetStoriesByIDRequest(peer=input_peer, id=[story_id]))
        except Exception as e:
            print(f"[story_saver] fetch story {story_id} failed: {e!r}")
            return None
        for s in getattr(res, "stories", None) or []:
            if isinstance(s, tl_types.StoryItem) and s.id == story_id:
                return s
        return None

    async def _who(self, peer):
        """(نام، یوزرنیم) صاحبِ استوری؛ اگه entity پیدا نشد، ذخیره‌ی استوری متوقف نمی‌شه"""
        try:
            entity = await self.client.get_entity(peer)
        except Exception:
            return "ناشناس", ""
        name = (utils.get_display_name(entity) or "").strip() or "ناشناس"
        return name, _pick_username(entity)

    async def _download_and_send(self, media, stem, caption, key) -> bool:
        """دانلود + ارسال به Saved Messages. اگه یه‌بار خطا بده (قطعیِ لحظه‌ای، فایل ناقص و ...)
        فقط یک‌بار دیگه تلاش می‌کنه؛ توی حالتِ عادی هیچ تأخیرِ اضافه‌ای نداره."""
        async with self._sem:
            for attempt in (1, 2):
                path = None
                try:
                    TMP_DIR.mkdir(parents=True, exist_ok=True)
                    path = await self.client.download_media(media, file=str(TMP_DIR / stem))
                    if not path or not os.path.exists(path):
                        raise RuntimeError("download returned no file")
                    await self._send(path, caption, media)
                    return True
                except FloodWaitError as e:              # _send خودش یک‌بار صبر کرده؛ تکرارش فایده‌ای نداره
                    print(f"[story_saver] saving {key} stopped by FloodWait ({e.seconds}s)")
                    return False
                except Exception as e:
                    print(f"[story_saver] saving {key} failed (attempt {attempt}/2): {e!r}")
                    if attempt == 2:
                        return False
                    await asyncio.sleep(RETRY_DELAY)
                finally:
                    if path:
                        try:
                            os.remove(path)
                        except Exception:
                            pass
        return False

    async def _send(self, path, caption, media) -> None:
        extra = _video_kwargs(media)
        for attempt in (1, 2):
            try:
                await self.client.send_file(SAVE_TARGET, path, caption=caption, parse_mode="html", **extra)
                return
            except FloodWaitError as e:
                if attempt == 2 or e.seconds > FLOOD_MAX_WAIT:
                    raise
                await asyncio.sleep(e.seconds + 1)


# ===================== SETUP =====================

def setup(client):
    update_cls = getattr(tl_types, "UpdateStory", None)
    if update_cls is None:
        print("[story_saver] this Telethon version has no stories support - pip install -U telethon")
        return

    saver = _StorySaver(client)

    @client.on(events.Raw(update_cls))
    async def story_auto_saver(update):
        saver.schedule(update)
