"""
=====================================================================
 text_to_voice.py — ماژول تبدیل متن به ویس (Telethon)
---------------------------------------------------------------------
روش کار (بدون هیچ توکن/API پولی) — منطق دقیقاً همون نسخه‌ی قبلیه،
فقط لایه‌ی ارتباط با تلگرام از Pyrogram به Telethon تغییر کرده:

  1) متن با edge-tts (سرویس رایگان Read Aloud خودِ مایکروسافت اج) به mp3
     تبدیل می‌شه. هیچ API key لازم نیست و هزینه‌ی هر درخواست صفره.
  2) خروجی mp3 با ffmpeg به ogg/opus تبدیل می‌شه، چون تلگرام فقط این
     فرمت رو به شکل «پیام صوتی» واقعی (با آیکون میکروفون و waveform)
     نشون می‌ده؛ در غیر این صورت به شکل فایل صوتی معمولی می‌فرسته.
  3) فایل ogg با voice_note=True به عنوان voice message ریپلای می‌شه.

پیش‌نیاز روی سرور:
  pip install telethon edge-tts cryptg --break-system-packages
  apt install ffmpeg        (یا معادلش روی توزیع لینوکس شما)
  # cryptg اختیاریه، فقط رمزنگاری تلتون رو سریع‌تر می‌کنه.

استفاده در بات (طبق الگوی خودت، بدون تغییر):
  import text_to_voice
  text_to_voice.setup(client)   # client باید یک TelegramClient تلتون باشه

دستور داخل تلگرام:
  /tts <متن>                     -> تبدیل مستقیم متن
  ریپلای روی پیام متنی + /tts     -> تبدیل همون پیام
  (پیشوندهای /  .  ! هر سه پشتیبانی می‌شن، بزرگی/کوچکی حروف مهم نیست)

نکته: چون edge-tts یک سرویس رسمی/عمومی نیست (ریورس‌شده از خودِ Edge)،
ممکنه مایکروسافت هر زمان بدون اطلاع قبلی تغییرش بده؛ برای مصرف شخصی
مشکلی نیست ولی برای فروش پایدار به کاربر، این ریسک رو در نظر بگیر.
=====================================================================
"""

import os
import asyncio
import uuid
import tempfile
import subprocess

import edge_tts
from telethon import events

# ---------------------------------------------------------------- تنظیمات
# صداهای فارسی edge-tts. لیست کامل و به‌روز رو خودت با این دستور ببین:
#   edge-tts --list-voices | grep fa-IR
VOICES = {
    "female": "fa-IR-DilaraNeural",
    "male": "fa-IR-FaridNeural",
}
DEFAULT_VOICE = VOICES["female"]

MAX_CHARS = 1000  # جلوگیری از سوءاستفاده با متن‌های خیلی طولانی/سنگین

# پیشوند دستور: /tts یا .tts یا !tts (و voice به‌جای tts)
COMMAND_PATTERN = r"(?i)^[/.!](?:tts|voice)(?:\s+([\s\S]+))?$"


async def _text_to_mp3(text: str, voice: str, mp3_path: str) -> None:
    """متن را با edge-tts به فایل mp3 تبدیل می‌کند (رایگان، بدون API key)."""
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(mp3_path)


async def _mp3_to_ogg(mp3_path: str, ogg_path: str) -> None:
    """mp3 را با ffmpeg به ogg/opus (فرمت استاندارد ویس تلگرام) تبدیل می‌کند.
    ✅ عملکرد: قبلاً subprocess.run سنکرون بود - یعنی هر /tts تا تمومِ
    ffmpeg، کل ربات (همه‌ی ماژول‌های دیگه‌ی self.py هم) رو فریز می‌کرد.
    الان از asyncio.create_subprocess_exec استفاده می‌کنه (دقیقاً همون
    الگویی که music.py برای ffmpeg استفاده می‌کنه) - غیرمسدودکننده.
    خطاها همون قبلی‌ان: نبودِ ffmpeg → FileNotFoundError، خروجِ غیرصفر →
    subprocess.CalledProcessError - همونی که پایین‌تر توی except گرفته می‌شه."""
    process = await asyncio.create_subprocess_exec(
        "ffmpeg", "-y", "-i", mp3_path,
        "-vn", "-acodec", "libopus", "-b:a", "48k",
        ogg_path,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    await process.wait()
    if process.returncode != 0:
        raise subprocess.CalledProcessError(process.returncode, "ffmpeg")


def setup(client):
    """
    خودِ بات این تابع را با text_to_voice.setup(client) صدا می‌زند
    و هندلر دستور /tts را روی همان TelegramClient (Telethon) رجیستر می‌کند.
    """

    @client.on(events.NewMessage(pattern=COMMAND_PATTERN))
    async def text_to_voice_handler(event: events.NewMessage.Event):
        # 1) پیدا کردن متن ورودی: از جلوی دستور یا از پیام ریپلای‌شده
        text = event.pattern_match.group(1)
        text = text.strip() if text else None

        if not text and event.is_reply:
            reply_msg = await event.get_reply_message()
            if reply_msg and reply_msg.text:
                text = reply_msg.text.strip()

        if not text:
            await event.reply(
                "یک متن جلوی دستور بنویس یا روی یک پیام متنی ریپلای کن.\n"
                "مثال: /tts سلام، حالت چطوره؟"
            )
            return

        if len(text) > MAX_CHARS:
            await event.reply(f"متن باید کمتر از {MAX_CHARS} کاراکتر باشه.")
            return

        status = await event.reply("🎙 در حال تبدیل متن به صدا...")

        uid = uuid.uuid4().hex
        mp3_path = os.path.join(tempfile.gettempdir(), f"tts_{uid}.mp3")
        ogg_path = os.path.join(tempfile.gettempdir(), f"tts_{uid}.ogg")

        try:
            await _text_to_mp3(text, DEFAULT_VOICE, mp3_path)
            await _mp3_to_ogg(mp3_path, ogg_path)
            await client.send_file(
                event.chat_id,
                ogg_path,
                voice_note=True,
                reply_to=event.message.id,
            )
            await status.delete()

        except FileNotFoundError:
            await status.edit(
                "ffmpeg روی سرور نصب نیست. با دستور «apt install ffmpeg» نصبش کن."
            )
        except Exception as e:
            await status.edit(f"خطا در تبدیل متن به صدا:\n{e}")
        finally:
            for p in (mp3_path, ogg_path):
                if os.path.exists(p):
                    os.remove(p)