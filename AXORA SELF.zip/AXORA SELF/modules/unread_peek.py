# -*- coding: utf-8 -*-
"""
unread_peek.py  -  دیدن پیام های خوانده نشده بدون "سین" شدن

دستور (فقط از طرف خودِ اکانت، توی هر چتی):

    /پیام های خوانده نشده          (انگلیسی: /unread)
        پیام های خوانده نشده ی همه ی چت های شخصی همین جا فوروارد می شن.
        ترتیب: چتی که اولین پیام خوانده نشده ش قدیمی تره اول میاد،
        و داخل هر چت از قدیمی به جدید.

    @username                      (یا آیدی عددی، یا لینک t.me/username)
    /پیام های خوانده نشده
        فقط پیام های خوانده نشده ی همون شخص.

سین نمی شه چون فقط getDialogs / getHistory / forwardMessages صدا زده می شه
و هیچ جا ReadHistory یا send_read_acknowledge صدا زده نمی شه.

اتصال به بات (یک خط، بعد از ساخته شدن client):
    import unread_peek
    unread_peek.register(client)

نکته: بهتره دستور رو توی Saved Messages بزنی. وقتی توی یه چت پیام می فرستی
ممکنه تلگرام همون چت رو خوانده حساب کنه، برای همین پیام های خودِ چتی که
دستور توش زده شده فوروارد نمی شن.
"""
import asyncio
import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional

from telethon import errors, events, utils
from telethon.tl import functions, types

log = logging.getLogger("unread_peek")

# ─────────────────────────── تنظیمات ───────────────────────────
INCLUDE_BOTS = False      # پیام های خوانده نشده ی بات ها هم بیاد؟ (حالت "همه")
INCLUDE_GROUPS = False    # گروه ها هم بیان؟ (حالت "همه")
INCLUDE_CHANNELS = False  # کانال ها هم بیان؟ (حالت "همه")
MAX_PER_CHAT = 300        # سقف پیام برای هر چت (جلوگیری از فلود)
CHUNK = 100               # سقف پیام در هر درخواست فوروارد (حد تلگرام: 100)
PAGE = 100                # سقف پیام در هر درخواست خوندن تاریخچه (حد تلگرام: 100)
DELAY = 0.4               # مکث (ثانیه) بین فوروارد چت ها
MAX_FLOOD_SLEEP = 60      # اگه FloodWait بیشتر از این بود صبر نمی کنه
MAX_TARGETS = 10          # حداکثر تعداد @username / آیدی توی یک دستور

MSG_WORKING = "⏳ در حال جمع کردن پیام های خوانده نشده ..."
MSG_BUSY = "⏳ هنوز دارم درخواست قبلی رو انجام می دم."

_SERVICE_NOTIFICATIONS_ID = 777000  # چت رسمی تلگرام (کد ورود و ...)

# ─────────────────────────── پارس دستور ───────────────────────────
# کاراکترهای کنترلی (نیم فاصله، RLM، LRM و ...) به فاصله تبدیل می شن
_CONTROL = {c: " " for c in (0x200C, 0x200D, 0x200E, 0x200F, 0x202A, 0x202B,
                              0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068,
                              0x2069, 0xFEFF)}
# ي ى ك ۀ ة عربی -> فارسی
_LETTERS = {0x064A: 0x06CC, 0x0649: 0x06CC, 0x0643: 0x06A9,
            0x06C0: 0x0647, 0x0629: 0x0647}
# ارقام فارسی و عربی -> انگلیسی
_DIGITS = {**{0x06F0 + i: 0x30 + i for i in range(10)},
           **{0x0660 + i: 0x30 + i for i in range(10)}}
_TRANSLATE = {**_CONTROL, **_LETTERS, **_DIGITS}

_SEP = r"[\s_-]*"
_CMD = (
    rf"(?:پیام{_SEP}(?:ها|های)?{_SEP}(?:خوانده|خونده){_SEP}نشده"
    rf"|پیام{_SEP}(?:ها|های)?{_SEP}نخوانده"
    rf"|(?:خوانده|خونده){_SEP}نشده(?:{_SEP}ها)?"
    rf"|نخوانده(?:{_SEP}ها)?"
    rf"|(?:unread|unseen)(?:{_SEP}(?:messages?|msgs?))?)"
)
_CMD_RE = re.compile("/" + _CMD + r"(?!\S)", re.IGNORECASE)

_AT_RE = re.compile(r"@([A-Za-z][A-Za-z0-9_]{3,31})")
_LINK_RE = re.compile(
    r"(?:https?://)?(?:t|telegram)\.me/@?([A-Za-z][A-Za-z0-9_]{3,31})/?", re.IGNORECASE)
_ID_RE = re.compile(r"-?\d{5,16}")


@dataclass(frozen=True)
class Target:
    raw: str
    username: Optional[str] = None   # حروف کوچک، بدون @
    peer_id: Optional[int] = None


@dataclass(frozen=True)
class Request:
    targets: tuple = ()              # خالی = همه ی چت ها


def parse_target(token: str) -> Optional[Target]:
    for rx in (_AT_RE, _LINK_RE):
        m = rx.fullmatch(token)
        if m:
            return Target(token, username=m.group(1).lower())
    if _ID_RE.fullmatch(token):
        return Target(token, peer_id=int(token))
    return None


def parse_command(text: Optional[str]) -> Optional[Request]:
    """None یعنی این پیام دستور ما نیست."""
    if not text or "/" not in text or len(text) > 200:
        return None
    t = text.translate(_TRANSLATE)
    m = _CMD_RE.search(t)
    if not m:
        return None
    rest = (t[:m.start()] + " " + t[m.end():]).strip()
    if not rest:
        return Request()
    tokens = [x for x in re.split(r"[\s,،;]+", rest) if x]
    if len(tokens) > MAX_TARGETS:
        return None
    targets = []
    for tok in tokens:
        tg = parse_target(tok)
        if tg is None:
            return None  # متن عادی که اتفاقی دستور توش بوده
        targets.append(tg)
    return Request(tuple(targets))


# ─────────────────────────── مدل داده ───────────────────────────
@dataclass
class Group:
    dialog: object
    messages: list                   # از قدیمی به جدید
    sent: int = 0
    failed: int = 0

    @property
    def name(self) -> str:
        return self.dialog.name or str(self.dialog.id)

    @property
    def sort_key(self):
        return (self.messages[0].date, self.dialog.id)

    @property
    def capped(self) -> bool:
        return len(self.messages) >= MAX_PER_CHAT and self.dialog.unread_count > len(self.messages)


@dataclass
class Result:
    targeted: bool = False
    groups: List[Group] = field(default_factory=list)
    missing: List[Target] = field(default_factory=list)  # هدف هایی که چتشون پیدا نشد
    empty: List[str] = field(default_factory=list)       # هدف هایی که پیام خوانده نشده نداشتن
    same_chat: bool = False                              # چتِ محل دستور رد شد
    flood: int = 0                                       # ثانیه ی FloodWait اگه فوروارد قطع شد

    @property
    def forwarded(self) -> int:
        return sum(g.sent for g in self.groups)

    @property
    def failed(self) -> int:
        return sum(g.failed for g in self.groups)


# ─────────────────────────── منطق اصلی ───────────────────────────
async def _sleep(seconds: float):
    await asyncio.sleep(seconds)


def _matches(entity, target: Target) -> bool:
    if target.username:
        names = {getattr(entity, "username", None)}
        names.update(getattr(u, "username", None) for u in (getattr(entity, "usernames", None) or []))
        return target.username in {n.lower() for n in names if n}
    return target.peer_id in (getattr(entity, "id", None), utils.get_peer_id(entity))


def _kind_allowed(d) -> bool:
    """فقط برای حالت "همه": کدوم نوع چت ها بررسی بشن."""
    ent = d.entity
    if d.is_user:
        if getattr(ent, "is_self", False) or ent.id == _SERVICE_NOTIFICATIONS_ID:
            return False
        return INCLUDE_BOTS if getattr(ent, "bot", False) else True
    if d.is_channel and not d.is_group:
        return INCLUDE_CHANNELS
    return INCLUDE_GROUPS


async def _collect(client, d) -> list:
    """پیام های دریافتیِ بعد از آخرین پیام خوانده شده، از قدیمی به جدید (حداکثر MAX_PER_CHAT).
    فقط getHistory صدا زده می شه، پس چیزی سین نمی شه.

    صفحه بندی عمداً دستیه: iter_messages ی Telethon توی حالت reverse، اگه سرور صفحه ی آخر
    رو با پیام های قدیمی پر کنه وسط کار قطع می شه و پیام های جدید رو گم می کنه."""
    last = getattr(d.dialog, "read_inbox_max_id", 0) or 0
    target = min(d.unread_count, MAX_PER_CHAT)
    out = []
    while len(out) < MAX_PER_CHAT:
        limit = min(PAGE, max(target - len(out), 0) + 10)  # +10 جا برای پیام های خودمون وسط ها
        r = await client(functions.messages.GetHistoryRequest(
            peer=d.input_entity, offset_id=last + 1, offset_date=None,
            add_offset=-limit, limit=limit, max_id=0, min_id=0, hash=0))
        newer = sorted((m for m in r.messages if m.id > last), key=lambda m: m.id)
        for m in newer:
            # types.Message یعنی نه سرویس مسیج و نه MessageEmpty؛ m.out یعنی پیام خودمون
            if isinstance(m, types.Message) and not m.out:
                out.append(m)
        if len(newer) < limit:
            break  # صفحه پر نشد = پیام جدیدتری نیست
        last = newer[-1].id
    return out[:MAX_PER_CHAT]


class _FloodAbort(Exception):
    """FloodWait خیلی طولانی؛ ادامه ی فوروارد بی فایده ست."""

    def __init__(self, seconds: int):
        super().__init__(seconds)
        self.seconds = seconds


async def _try_forward(client, to_peer, from_peer, ids) -> bool:
    for _ in range(3):
        try:
            await client.forward_messages(to_peer, ids, from_peer=from_peer, silent=True)
            return True
        except errors.FloodWaitError as e:
            if e.seconds > MAX_FLOOD_SLEEP:
                log.warning("FloodWait %ss too long, giving up", e.seconds)
                raise _FloodAbort(e.seconds)
            await _sleep(e.seconds + 1)
        except errors.RPCError as e:
            log.info("forward failed (%s) ids=%s", type(e).__name__, ids[:3])
            return False
    return False


async def _forward_group(client, to_peer, g: Group):
    """پیام های یک چت رو دسته ای فوروارد می کنه و g.sent / g.failed رو پر می کنه.
    اگه یک دسته خراب شد (مثلا یکی از پیام ها پاک شده یا فوروارد محدوده) تک به تک
    امتحان می کنه تا فقط همون یکی جا بمونه."""
    from_peer = g.dialog.input_entity
    ids = [m.id for m in g.messages]
    try:
        for i in range(0, len(ids), CHUNK):
            chunk = ids[i:i + CHUNK]
            if await _try_forward(client, to_peer, from_peer, chunk):
                g.sent += len(chunk)
            elif len(chunk) == 1:
                g.failed += 1
            else:
                for mid in chunk:
                    if await _try_forward(client, to_peer, from_peer, [mid]):
                        g.sent += 1
                    else:
                        g.failed += 1
    except _FloodAbort:
        g.failed = len(ids) - g.sent  # بقیه ی این چت فوروارد نشد
        raise


async def peek(client, to_peer, targets=(), exclude_id=None) -> Result:
    """پیام های خوانده نشده رو جمع و به ترتیب توی to_peer فوروارد می کنه.
    targets خالی = همه ی چت های شخصی. exclude_id = آیدی چتِ محل دستور."""
    res = Result(targeted=bool(targets))
    wanted = list(targets)
    found = set()
    groups = []

    async for d in client.iter_dialogs():
        if wanted:
            hit = [t for t in wanted if _matches(d.entity, t)]
            if not hit:
                continue
            found.update(hit)
        elif not d.unread_count or not _kind_allowed(d):
            continue

        if d.id == exclude_id:
            if d.unread_count:
                res.same_chat = True
        elif d.unread_count:
            msgs = await _collect(client, d)
            if msgs:
                groups.append(Group(d, msgs))
            elif wanted:
                res.empty.append(d.name)
        elif wanted:
            res.empty.append(d.name)

        if wanted and len(found) == len(wanted):
            break

    res.missing = [t for t in wanted if t not in found]
    groups.sort(key=lambda g: g.sort_key)  # به ترتیبِ اولین پیام خوانده نشده ی هر چت
    res.groups = groups
    for i, g in enumerate(groups):
        if res.flood:  # بعد از FloodWait بقیه رو نفرست
            g.failed = len(g.messages)
            continue
        if i:
            await _sleep(DELAY)
        try:
            await _forward_group(client, to_peer, g)
        except _FloodAbort as e:
            res.flood = e.seconds
    return res


def format_result(res: Result) -> str:
    lines = []
    sent = [g for g in res.groups if g.sent]
    if len(sent) == 1:
        lines.append(f"✅ {res.forwarded} پیام خوانده نشده از «{sent[0].name}» فوروارد شد (بدون سین).")
    elif sent:
        lines.append(f"✅ {res.forwarded} پیام خوانده نشده از {len(sent)} چت فوروارد شد (بدون سین).")
        lines += [f"• {g.name}: {g.sent}" for g in sent[:20]]
        if len(sent) > 20:
            lines.append(f"• و {len(sent) - 20} چت دیگه")
    for g in sent:
        if g.capped:
            lines.append(f"⚠️ از «{g.name}» فقط {len(g.messages)} پیام اول فوروارد شد (سقف {MAX_PER_CHAT}).")
    if res.flood:
        lines.append(f"⚠️ تلگرام محدودیت موقت داد؛ حدود {res.flood} ثانیه بعد دوباره بزن. "
                     f"{res.failed} پیام فوروارد نشد.")
    elif res.failed:
        lines.append(f"⚠️ {res.failed} پیام فوروارد نشد (محدودیت فوروارد یا پاک شده).")
    if res.empty:
        lines.append("📭 از " + "، ".join(f"«{n}»" for n in res.empty) + " پیام خوانده نشده ای نیست.")
    if res.missing:
        lines.append("❌ چتی با " + "، ".join(t.raw for t in res.missing) + " پیدا نشد.")
    if res.same_chat:
        lines.append("ℹ️ پیام های خودِ همین چت فوروارد نشد (همین جا هستن).")
    if not lines:
        lines.append("📭 پیام خوانده نشده ای نداری.")
    return "\n".join(lines)


# ─────────────────────────── اتصال به client ───────────────────────────
async def _edit(event, text: str):
    try:
        await event.edit(text, parse_mode=None)
    except errors.MessageNotModifiedError:
        pass
    except Exception:
        log.debug("edit failed", exc_info=True)


def _quick(event) -> bool:
    """فیلتر ارزان روی هر پیام خروجی؛ فقط متن های کوتاهِ دارای / رد می شن."""
    t = event.raw_text
    return bool(t) and "/" in t and len(t) <= 200


async def _run(client, event, req: Request, lock: asyncio.Lock):
    if lock.locked():
        await _edit(event, MSG_BUSY)
        return
    async with lock:
        try:
            await _edit(event, MSG_WORKING)
            to_peer = await event.get_input_chat()
            res = await peek(client, to_peer, req.targets, exclude_id=event.chat_id)
            await _edit(event, format_result(res))
        except Exception as e:
            log.exception("unread_peek failed")
            await _edit(event, f"❌ خطا: {type(e).__name__}")


def setup(client):
    """handler رو به client وصل می کنه و همون handler رو برمی گردونه."""
    lock = asyncio.Lock()
    tasks = set()

    async def handler(event):
        req = parse_command(event.raw_text)
        if req is None:
            return
        # توی تسک جدا اجرا می شه تا handler های دیگه ی همین پیام معطل نمونن
        task = asyncio.get_running_loop().create_task(_run(client, event, req, lock))
        tasks.add(task)
        task.add_done_callback(tasks.discard)

    client.add_event_handler(
        handler, events.NewMessage(outgoing=True, forwards=False, func=_quick))
    return handler
