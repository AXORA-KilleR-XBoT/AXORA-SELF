import asyncio
from config import client, settings
# from modules.POKER import POKER
from modules import (
    viewonce, downloader, profile_checker, anti_delete,
    love_mode, limited, animations, sik, id_back , online_mode, Dot, 
    panel, proxy_ping, voice_to_text, market, anti_log, panel_bot, POKER, unread_peek,
    GPT, auto_reply, bio_clock, forced_join, mass_message, GHOST_MODE, spam, music, QR, auto_join,
    secretary, media_toolkit, Super, Archive, rotating_name, movie, text_to_voice, Translation, CoRe_GROP,
)
async def main():
    viewonce.setup(client)
    downloader.setup(client)
    profile_checker.setup(client)
    love_mode.setup(client)
    auto_join.setup(client)
    online_mode.setup(client)
    Translation.setup(client)
    anti_delete.setup(client)
    POKER.setup(client)
    animations.setup(client)
    unread_peek.setup(client)
    GPT.setup(client)
    music.setup(client)
    CoRe_GROP.setup(client)
    movie.setup(client)
    rotating_name.setup(client)
    media_toolkit.setup(client)
    GHOST_MODE.setup(client)
    Archive.setup(client)
    secretary.setup(client)
    spam.setup(client)
    Super.setup(client)
    mass_message.setup(client)
    Dot.setup(client)
    QR.setup(client)
    auto_reply.setup(client)
    bio_clock.setup(client)
    # voice_to_text.setup(client)
    text_to_voice.setup(client)
    forced_join.setup(client)
    sik.setup(client)
    id_back.setup(client)
    market.setup(client)
    anti_log.setup(client)
    panel.setup(client)
    panel_bot.setup(client)
    proxy_ping.setup(client)
    limited.setup(client)
    auto_join.setup(client)
    await client.start(phone=settings.PHONE)
    print("\n LIFE DEVIL ON\n\n { 🧠 🫀 🫁 }\n\n IM fucking BDSM human 👁")
    asyncio.create_task(profile_checker.periodic_check(client))
    await client.run_until_disconnected()
if __name__ == "__main__":
    asyncio.run(main())